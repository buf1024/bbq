import threading
from functools import partial
import time
from datetime import datetime
import sys
from collections import OrderedDict
import copy
import log
from queue import Queue
from eventbus import *
from common import *


class Data(threading.Thread):
    def __init__(self, repo, **kwargs):
        super().__init__()
        self.log = log.get_logger(self.__class__.__name__)
        self.repo = repo
        self.quot = repo.quot
        self.db = repo.db
        self.running = False

        self.kwargs = kwargs
        self.log.info('kwargs={}'.format(self.kwargs))
        # 命令行参数
        self.start_date = None if 'start_date' not in self.kwargs else \
            datetime.strptime(self.kwargs['start_date'], '%Y%m%d')
        self.end_date = None if 'end_date' not in self.kwargs else \
            datetime.strptime(self.kwargs['end_date'], '%Y%m%d')
        self.func = self.kwargs['func'].split(',') if 'func' in self.kwargs \
            else 'code_k_data,code_daily_index,code_trans,index_k_data'.split(',')
        self.type = None if 'type' not in self.kwargs else self.kwargs['type']
        self.sync_basic = True if 'sync_basic' not in self.kwargs else self.kwargs['sync_basic'] == 'true'

        self.lock = threading.Lock()
        self.sync_db_stat = OrderedDict()
        self.sync_running = defaultdict(int)
        self.sync_queue_count = 25 if 'thread_count' not in self.kwargs else int(self.kwargs['thread_count'])
        self.sync_queue = {}

        self.proc_hook = None

        task_bind(cat='data', func=self._task_compensate, target=self)
        evt_bind(cat='data', func=self._sync_status, target=self)
        evt_bind(cat='data', func=self._async_db, target=self)
        evt_bind(cat='data', func=self._sync_sync_process, target=self)
        evt_bind(cat='data', func=self._sync_queue_poll, target=self)

    def set_proc_hook(self, func):
        self.proc_hook = func

    @on(cat='data', event='evt_sync_status')
    def _sync_status(self, payload):
        if self.proc_hook is not None:
            kwargs, status = payload['kwargs'], payload['status']
            kwargs['status'] = status
            self.proc_hook(kwargs)

    @on(cat='data', event='evt_sync_db', thread=True)
    def _async_db(self, payload):
        kwargs, func = payload['kwargs'], payload['func']
        self.log.info('异步数据库同步 -> {}'.format(kwargs))
        func()
        self.log.info('异步数据库同步完成 -> {}'.format(kwargs))

    def _sync_db(self, func, sync=False, **kwargs):
        emit(cat='data', event='evt_sync_status', payload=(kwargs, False))
        if not sync:
            emit(cat='data', event='evt_sync_db', payload={'func': func, 'kwargs': kwargs})
        else:
            self.log.info('同步数据库同步 -> {}'.format(kwargs))
            func()
            self.log.info('同步数据库同步 ->  {} 完成'.format(kwargs))

    def _get_sync_trad_cal(self):
        flter = {}
        if self.start_date is not None:
            flter['$gte'] = self.start_date
        if self.end_date is not None:
            flter['$lt'] = self.end_date
        if len(flter) == 0:
            now = datetime.now()
            now = datetime(year=now.year, month=now.month, day=now.day, hour=0, minute=0, second=0)
            flter = {'$lt': now}
        return self.db.load_trade_cal(filter={
            'cal_date': flter,
            'is_open': 1
        }, projection=['cal_date'], sort=[('cal_date', -1)])

    def _reset_sync_date(self):
        now = datetime.now()
        now = datetime(year=now.year, month=now.month, day=now.day, hour=0, minute=0, second=0)
        last_date = self.db.load_code_k_data(filter={
            'trade_date': {'$lt': now},
        }, projection=['trade_date'], sort=[('trade_date', -1)], limit=1)
        if last_date is None:
            return False
        self.start_date = last_date['cal_date'][0]
        self.end_date = now
        return True

    def sync_basic_data(self):
        if self.sync_basic:
            self.log.info('开始同步基础数据...')
            self.log.info('获取股票列表...')

            codes = self.quot.get_code_list()
            if codes is None:
                self.log.error('获取股票列表错误')
                return None, None, None

            self.log.info('保存股票列表, count = {} ...'.format(codes.shape[0]))
            self._sync_db(func=partial(self.db.save_code_list, codes=codes), sync=True, type='code_list')

            self.log.info('获取股票交易日...')
            trad_cals = self.quot.get_trade_cal()
            if trad_cals is None:
                self.log.error('获取交易日错误')
                return None, None, None

            self.log.info('保存股票交易日...')
            self._sync_db(func=partial(self.db.save_trade_cal, cals=trad_cals), sync=True, type='trade_cal')

            self.log.info('获取股票指数数据...')
            indexes = self.quot.get_index_list()
            if indexes is None:
                self.log.error('获取股票指数数据')
                return None, None, None

            self.log.info('保存股票指数数据...')
            self._sync_db(func=partial(self.db.save_index_list, indexes=indexes), sync=True, type='index_list')

            return codes, self._get_sync_trad_cal(), indexes

        self.log.info('开始获取数据库基础数据...')
        return self.db.load_code_list(), self._get_sync_trad_cal(), self.db.load_index_list()

    def _sync_data(self, trade_date, quot_func, db_load_func, db_save_func, key='code', flter=None, sync=False, **kwargs):
        typ = kwargs['type']
        kwargs['trade_date'] = trade_date
        self.log.info('获取行情数据: {}'.format(typ))
        data = quot_func()
        if data is None:
            self.log.error('{}获取行情数据异常'.format(typ))
            return False

        quot_codes = data['code'].drop_duplicates().tolist()
        db_codes = db_load_func(codes=quot_codes, filter={
            'trade_date': datetime.strptime(trade_date, '%Y%m%d')
        } if flter is None else flter, projection=[key])

        if db_codes is not None:
            db_codes = [v[key].tolist() for v in db_codes.values() if v is not None]
            db_codes = [it for lst in db_codes for it in lst]
            quot_codes = data[key].drop_duplicates().tolist()
            new_codes = set(quot_codes).difference(db_codes)
            if new_codes is None or len(new_codes) == 0:
                return True

            data = data[data[key].isin(new_codes)]

        if data is not None:
            self._sync_db(func=partial(db_save_func, data=data), sync=sync, **kwargs)

        return True

    @on(cat='data', event='evt_sync_process', thread=True)
    def _sync_sync_process(self, payload):
        name, func, kwargs = payload
        emit(cat='data', event='evt_sync_status', payload=(kwargs, False))
        self.log.info('{}, {}线程同步开始'.format(name, kwargs))
        func()
        self.log.info('{}, {}线程同步结束'.format(name, kwargs))
        emit(cat='data', event='evt_sync_status', payload=(kwargs, True))

        with self.lock:
            self.sync_running[name] -= 1

    @on(cat='data', event='evt_sync_queue_poll', thread=True)
    def _sync_queue_poll(self, payload):
        name, q = payload
        self.log.info('new poll: {}'.format(name))
        while self.running:
            try:
                func, kwargs = q.get()
                self.log.info('同步: {}'.format(kwargs))
                queue_count = self.sync_running[name]
                wait_count = 0
                while queue_count >= self.sync_queue_count and self.running:
                    self.log.info(
                        '{}当前线程数{}已经超过{}, 等待10s后再尝试, 已经等待{}次'.format(name, queue_count, self.sync_queue_count,
                                                                     wait_count))
                    time.sleep(10)
                    wait_count += 1
                    queue_count = self.sync_running[name]

                with self.lock:
                    self.sync_running[name] += 1

                emit(cat='data', event='evt_sync_process', payload=(name, func, kwargs))

            except Exception as e:
                self.log.error('_sync_queue_poll 异常: {}'.format(e))

    def _sync_call(self, func, name, is_seq, **kwargs):
        if not is_seq:
            if name not in self.sync_queue:
                self.sync_queue[name] = Queue()
                emit(cat='data', event='evt_sync_queue_poll', payload=(name, self.sync_queue[name]))
            self.sync_queue[name].put((func, kwargs), block=False)
        else:
            emit(cat='data', event='evt_sync_status', payload=(kwargs, False))
            self.log.info('同步调用: {}'.format(kwargs))
            func()
            self.log.info('同步调用完成: {}'.format(kwargs))
            emit(cat='data', event='evt_sync_status', payload=(kwargs, True))

    def sync_index_data(self, indexes):
        if 'index_k_data' in self.func:
            # 全量同步
            now = datetime.now()
            now = datetime(year=now.year, month=now.month, day=now.day, hour=0, minute=0, second=0)
            for index in indexes['code']:
                self.log.info('全量同步交易日{}指数成交数据...'.format(index))
                func = partial(self._sync_data, trade_date=now,
                               quot_func=partial(self.quot.get_index_kdata, end_date=now, code=index),
                               db_load_func=self.db.load_index_k_data,
                               db_save_func=self.db.save_index_k_data,
                               flter={'trade_date': {'$lt': now}},
                               type='index_k_data')
                self._sync_call(func, 'index_k_data', self.quot.is_sequence(self.quot.get_index_kdata),
                                type='index_k_data', end_date=now)

        return True

    def sync_code_data(self, codes, trade_cals):
        trade_cals = trade_cals.to_dict('records')
        self.log.info('交易日历size={}'.format(len(trade_cals)))
        for trade_cal in trade_cals:
            trade_date = trade_cal['cal_date'].strftime('%Y%m%d')
            # self.log.info('开始同步交易日{}数据...'.format(trade_date))

            if 'code_k_data' in self.func:
                self.log.info('开始同步交易日{}日k线数据...'.format(trade_date))

                func = partial(self._sync_data, trade_date=trade_date,
                               quot_func=partial(self.quot.get_code_kdata, trade_date=trade_date),
                               db_load_func=self.db.load_code_k_data,
                               db_save_func=self.db.save_code_k_data,
                               type='code_k_data')
                self._sync_call(func, 'code_k_data',
                                self.quot.is_sequence(self.quot.get_code_kdata),
                                trade_date=trade_date)

            if 'code_daily_index' in self.func:
                self.log.info('开始同步交易日{}每日指标数据...'.format(trade_date))

                func = partial(self._sync_data, trade_date=trade_date,
                               quot_func=partial(self.quot.get_code_daily_index, trade_date=trade_date),
                               db_load_func=self.db.load_code_daily_index,
                               db_save_func=self.db.save_code_daily_index,
                               type='code_daily_index')
                self._sync_call(func, 'code_daily_index',
                                self.quot.is_sequence(self.quot.get_code_daily_index),
                                trade_date=trade_date)

            if 'code_trans' in self.func:
                for code in codes['code']:
                    func = partial(self._sync_data, trade_date=trade_date,
                                   quot_func=partial(self.quot.get_code_trans, code=code, trade_date=trade_date),
                                   db_load_func=partial(self.db.load_code_trans, trade_dates=[trade_cal['cal_date']]),
                                   db_save_func=self.db.save_code_trans,
                                   key='time',
                                   sync=not self.quot.is_sequence(self.quot.get_code_trans),
                                   type='code_trans', code=code)
                    self._sync_call(func, 'get_code_trans',
                                    self.quot.is_sequence(self.quot.get_code_trans),
                                    code=code, trade_date=trade_date)

        return True

    def run(self):
        if self.type is None or self.type == 'sync':
            self._task_sync()
        else:
            self._task_compensate()

    def start(self):
        self.running = True
        super().start()

    def stop(self):
        bus_stop()
        self.running = False

    def _task_sync(self):
        is_incr = False
        while self.running:
            if is_incr:
                if not self._reset_sync_date():
                    self.log.info('增量同步状态异常')
                    self.running = False
                    return
            self.log.info('开始同步数据...')
            codes, trad_cals, indexes = self.sync_basic_data()
            if codes is None or trad_cals is None or indexes is None:
                self.log.error('获取基础数据异常, codes={}, trad_cal={}, indexes={}'.format(
                    codes.shape[0] if codes is not None else None,
                    trad_cals.shape[0] if trad_cals is not None else None,
                    indexes.shape[0] if indexes is not None else None))
                self.running = False
                return

            self.sync_code_data(codes, trad_cals)
            self.sync_index_data(indexes)

            if not is_incr:
                is_incr = True

    def _compensate(self, trade_date, codes, quot_func, db_load_func, db_save_func, **kwargs):
        db_codes = db_load_func(codes=codes, filter={
            'trade_date': trade_date
        }, projection=['code'])
        new_codes = set(codes).difference(db_codes)
        if new_codes is None or len(new_codes) == 0:
            return True
        for code in new_codes:
            self.log.info('{}补偿{}{}缺失数据'.format(code, kwargs, trade_date))
            data = quot_func(code=code, trade_date=datetime.strptime(trade_date, '%Y%m%d'))
            if data is not None:
                db_save_func(data)
        return True

    def _task_compensate(self):
        codes, trad_cals, indexes = self.sync_basic_data()
        if codes is None or trad_cals is None or indexes is None:
            self.log.error('获取基础数据异常, codes={}, trad_cal={}, indexes={}'.format(
                codes.shape[0] if codes is not None else None,
                trad_cals.shape[0] if trad_cals is not None else None,
                indexes.shape[0] if indexes is not None else None))

            return None

        for trade_cal in trad_cals.to_dict('records'):
            trade_date = trade_cal['cal_date'].strftime('%Y%m%d')
            if 'code_kdata' in self.func:
                self.log.info('开始补偿交易日{}K线数据'.format(trade_date))
                self._compensate(trade_date=trade_date, codes=codes,
                                 quot_func=self.quot.get_code_kdata,
                                 db_load_func=self.db.load_code_k_data,
                                 db_save_func=self.db.save_code_k_data,
                                 type='code_k_data')

            if 'code_index_data' in self.func:
                self.log.info('开始补偿交易日{}每日指标数据'.format(trade_date))
                self._compensate(trade_date=trade_date, codes=codes,
                                 quot_func=self.quot.get_code_daily_index,
                                 db_load_func=self.db.load_code_daily_index,
                                 db_save_func=self.db.save_code_daily_index,
                                 type='code_daily_index')

            if 'code_trans' in self.func:
                self.log.info('开始补偿交易日{}每日成交数据'.format(trade_date))
                for code in codes:
                    self.log.info('开始补偿交易日{}->{}每日成交数据'.format(trade_date, code))
                    quot_data = self.quot.get_code_trans(code=code, trade_date=trade_date.strptime('%Y%m%d'))
                    if quot_data is None:
                        continue

                    db_data = self.db.load_code_trans(codes=[code], trade_dates=[trade_cal['cal_date']], filter={
                        'trade_date': trade_date
                    })
                    if db_data is None or db_data.shape[0] != quot_data.shape[0]:
                        self.log.info('补偿{},{}成交数据'.format(code, trade_date))
                        self.db.save_code_trans(quot_data)

            if 'index_kdata' in self.func:
                self.log.info('开始补偿交易日{}指标数据'.format(trade_date))
                self._compensate(trade_date=trade_date, codes=indexes,
                                 quot_func=self.quot.get_index_kdata,
                                 db_load_func=self.db.load_index_k_data,
                                 db_save_func=self.db.save_index_k_data,
                                 type='index_k_data')


@singleton
class DataRepository(BaseRepository):
    def __init__(self, config_path):
        super().__init__(config_path)


def data_proc():
    config_path, opts = parse_arguments(
        opt_desc='start_date=yyyyMMdd end_date=yyyyMMdd type=sync|compensate sync_basic '
                 'thread_count=25 func=code_k_data,code_daily_index,code_trans,index_k_data')
    if config_path is None or opts is None:
        print('parse_arguments ailed')
        os._exit(-1)

    repo = DataRepository(config_path)
    if not repo.init('data'):
        print('req init failed')
        os._exit(-1)

    d = Data(repo, **opts)
    d.start()
    d.join()
    bus_stop()


if __name__ == '__main__':
    data_proc()
