from data.source_mongo import SourceMongo
from quot.quot_tushare import QuotTushare
from quot.quot_tencent import QuotTencent
from quot.quot_tdx import QuotTdx
from quot.quot_barbar import QuotBarbar
from functools import wraps
from eventbus import *
from threading import Thread
import log
import json
import argparse
import multiprocessing
import os
import importlib


def singleton(cls):
    insts = {}

    @wraps(cls)
    def wrapper(*args, **kwargs):
        if cls.__qualname__ not in insts:
            insts[cls.__qualname__] = cls(*args, **kwargs)
            cls.inst = insts[cls.__qualname__]
        return insts[cls.__qualname__]

    return wrapper


class BaseRepository:
    """
    外部保证数据正确性
    """

    def __init__(self, config_path):
        self.log = None
        self.config_path = config_path
        self._js = None

        self._db = {
            'list': {'mongo': SourceMongo},
            'inst': {}
        }
        self._quot = {
            'list': {'tushare': QuotTushare, 'pytdx': QuotTdx, 'tencent': QuotTencent},
            'inst': {}
        }
        self._barbar_quot = None
        self._barbar_db = None

        self._quot_thread = {}

    @property
    def db(self):
        return self._barbar_db

    @property
    def quot(self):
        return self._barbar_quot

    def quot_concurrent(self, name):
        return False if name not in self._quot_thread else self._quot_thread[name]

    def setup_quot(self):
        self._barbar_quot = QuotBarbar()
        for item in self._js['quot']['list']:
            name, enable, args = item['name'], item['enable'], item['args']
            if not enable:
                continue
            if name in self._quot['list'].keys():
                cls = self._quot['list'][name]
                inst = cls(args)
                if not inst.init():
                    self.log.error('初始化行情源 {} 失败'.format(name))
                    return False
                self._quot['inst'][name] = inst
            else:
                self.log.error('行情源 {} 不存在'.format(name))

        for func_name, inst_names in self._js['quot']['func'].items():
            inst_name, thread = inst_names['name'], inst_names['thread']
            inst = self._quot['inst'][inst_name] if inst_name in self._quot['inst'] else None
            if inst is None:
                self.log.error('无法找到行情源配置: func={}, quot={}'.format(func_name, inst_name))
                return False
            func = getattr(inst, func_name)
            if func is None:
                self.log.error('行情源配置错误: func={}, quot={}'.format(func_name, inst_name))
                return False
            self._barbar_quot[func_name] = func
            self._quot_thread[func_name] = thread

        return True

    def setup_db(self):
        source_name = self._js['db']['source']
        source_args = self._js['db']['args']
        inst = self._db['list'][source_name](source_args)
        if not inst.init():
            self.log.error('初始化数据源 {} 失败'.format(source_name))
            return False
        self._db['inst'][source_name] = inst
        self._barbar_db = self._db['inst'][source_name]

        return True

    def setup_log(self):
        if self.config_path is None:
            return False

        try:
            with open(self.config_path) as f:
                self._js = json.load(f)
        except Exception as e:
            print('加载配置文件异常: {}'.format(e))
            return False

        if not log.setup_logger(self._js['log']['path'], self._js['log']['file_name'],
                                self._js['log']['level']['console'],
                                self._js['log']['level']['file']):
            print('初始化日志错误: 日志路径不存在')
            return False

        self.log = log.get_logger(self.__class__.__name__)

        return True

    def init(self):
        if not self.setup_log():
            return False

        if not self.setup_db():
            return False

        return self.setup_quot()


class Runner(Thread):
    def __init__(self, qout, qin, qbroadcast, config_path, target_cls, repo_cls, **kwargs):
        super().__init__()

        self.qout = qout
        self.qin = qin
        self.qbroadcast = qbroadcast
        self.config_path = config_path
        self.kwargs = kwargs

        self.target_cls = target_cls
        self.repo_cls = repo_cls

        self.target = None
        self.repository = None
        self.log = None

        evt_bind('barbar', self.on_out, self)
        evt_bind('barbar', self.on_broadcast, self)

    def init(self):
        if self.config_path is None or self.target_cls is None or self.repo_cls is None:
            return False

        # js = None
        # try:
        #     with open(self.config_path) as f:
        #         js = json.load(f)
        # except Exception as e:
        #     print('加载配置文件异常: {}'.format(e))
        #     return False
        #
        # log_prefix = js['log']['file_prefix']
        # log_path = 'barbarian.log' if (self.kwargs is None or 'mod' not in self.kwargs) else self.kwargs['mod'] + '.log'
        # if len(log_prefix) != 0:
        #     log_path = log_prefix + '-' + log_path
        #
        # if not log.setup_logger(js['log']['path'], log_path,
        #                         js['log']['level']['console'],
        #                         js['log']['level']['file']):
        #     print('初始化日志错误: 日志路径不存在')
        #     return False
        #
        # self.log = log.get_logger(self.__class__.__name__)

        if self.repo_cls is not None:
            self.repository = self.repo_cls(self.config_path)
            if not self.repository.init():
                print('初始化repo错误')
                return False
            self.log = log.get_logger(self.__class__.__name__)
        if self.target_cls is not None:
            self.log.info('初始化target...')
            self.target = self.target_cls(self.repository, **self.kwargs)

        return True

    def run(self):
        if self.target is not None:
            self.target.start()

        if self.qin is not None:
            while True:
                event, payload = self.qin.get()
                emit('barbar', event=event, payload=payload)
                if event == 'evt_stop':
                    break
        if self.target is not None:
            self.target.join()

    @on(cat='barbar', event='evt_out')
    def on_out(self, payload):
        print('aaaacc')
        if self.qout is not None:
            print('bbb')
            self.qout.put(('evt_out', payload))

    @on(cat='barbar', event='evt_broadcast')
    def on_broadcast(self, payload):
        if self.qbroadcast is not None:
            self.qbroadcast.put(('evt_broadcast', payload))


def target_process(qout, qin, qbroadcast, config_path, target_cls, repo_cls, **kwargs):
    r = Runner(qout, qin, qbroadcast, config_path, target_cls, repo_cls, **kwargs)
    if not r.init():
        bus_stop()
        return False

    r.start()
    r.join()
    os._exit(0)


def run_process(qout, qin, qbroadcast, config_path, target_cls, repo_cls, ctx=None, **kwargs):
    if ctx is None:
        ctx = multiprocessing.get_context('spawn')
        qout, qin, qbroadcast = None, None, None
    proc = ctx.Process(target=target_process, args=(qout, qin, qbroadcast, config_path, target_cls, repo_cls),
                       kwargs=kwargs)
    bus_stop()
    proc.start()

    try:
        proc.join()
    except KeyboardInterrupt:
        print('KeyboardInterrupt')
        proc.kill()

    proc.join()


def parse_arguments(opt_desc=''):
    args = None
    try:
        parser = argparse.ArgumentParser(description='barbarian data module process')
        parser.add_argument('--config', required=False, help='path to config')
        parser.add_argument('opt', metavar='OPT', type=str, nargs='*',
                            help='an option args pass to data process' + opt_desc)
        args = parser.parse_args()
    except SystemExit as e:
        os._exit(0)

    if args is None:
        return None, None

    opts = {}
    if hasattr(args, 'opt') and args.opt is not None:
        for v in args.opt:

            idx = v.find('=')
            if idx == -1:
                opts[v] = idx
                continue

            k = v[:idx]
            v = v[idx + 1:]
            if len(k) == 0 or len(v) == 0:
                continue

            if v.find(';') == -1 and v.find('=') == -1:
                opts[k] = v
                continue

            opts[k] = {}
            kv = v.split(';')
            for v in kv:
                kv_s = v.split('=')
                if len(kv_s) != 2:
                    opts[k][kv_s] = True
                    continue
                opts[k][kv_s[0]] = kv_s[1]

    return args.config, opts


def load_strategy(dir_path, package):
    strategy = {}
    for root_path, dirs, files in os.walk(dir_path):
        if root_path.find('__') >= 0 or root_path.startswith('.'):
            continue

        package_suf = ''
        if dir_path != root_path:
            package_suf = '.' + root_path[len(dir_path) + 1:].replace(os.sep, '.')

        for file_name in files:
            if file_name.startswith('__') or file_name.startswith('.'):
                continue

            module = importlib.import_module('{}.{}'.format(package + package_suf, file_name[:-3]))

            file_names = file_name[:-3].split('_')
            name_list = [file_name.capitalize() for file_name in file_names]
            cls_name = ''.join(name_list)
            cls = module.__getattribute__(cls_name)
            if cls is not None:
                if len(package_suf) > 0:
                    package_suf = package_suf[1:] + '.'
                strategy[package_suf + cls_name] = cls
            else:
                print(
                    'warning: file {} not following strategy naming convention'.format(root_path + os.sep + file_name))

    return strategy


if __name__ == '__main__':
    # js = None
    # with open('/Users/luoguochun/Downloads/js.json') as f:
    #     js = json.load(f)
    #
    #
    # @singleton
    # class B(BaseRepository):
    #     def __init__(self, js=None):
    #         super().__init__(js)
    #
    #
    # a = B(js)
    # b = B(js)
    #
    # df = B().quot.get_code_list()
    # print(df)

    import selector

    print(selector.strategy)
