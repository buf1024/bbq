from data.source_mongo import SourceMongo
from quot.quot_tushare import QuotTushare
from quot.quot_tencent import QuotTencent
from quot.quot_tdx import QuotTdx
from quot.quot_barbar import QuotBarbar
from quot.quot_backtest import QuotBacktest

from functools import wraps
from eventbus import *
import log
import json
import argparse
import os
import importlib


def singleton(cls):
    insts = {}

    @wraps(cls)
    def wrapper(*args, **kwargs):
        if cls.__qualname__ not in insts:
            insts[cls.__qualname__] = cls(*args, **kwargs)
            cls.inst = insts[cls.__qualname__]
        return insts[cls.__qualname__]

    return wrapper


class BaseRepository:
    """
    外部保证数据正确性
    """

    def __init__(self, config_path):
        self.log = None
        self._config_path = config_path
        self._js = None

        self._db = {
            'list': {'mongo': SourceMongo},
            'inst': {}
        }
        self._quot = {
            'list': {'tushare': {'cls': QuotTushare, 'args': {}},
                     'pytdx': {'cls': QuotTdx, 'args': {}},
                     'tencent': {'cls': QuotTencent, 'args': {}},
                     'backtest': {'cls': QuotBacktest, 'args': {}}},
            'inst': {}
        }
        self._barbar_quot = None
        self._barbar_db = None

    @property
    def db(self):
        return self._barbar_db

    @property
    def quot(self):
        return self._barbar_quot

    @property
    def config(self):
        return self._js

    def setup_quot(self, mod):
        for item in self._js['quot']:
            name, args = item['name'], item['args']
            self._quot['list'][name]['args'] = args

        if 'quot' in self._js[mod]:
            self._barbar_quot = QuotBarbar()
            for func_name, inst_name in self._js[mod]['quot'].items():
                if inst_name not in self._quot['list']:
                    self.log.error('无法找到行情源配置: func={}, quot={}'.format(func_name, inst_name))
                    continue

                if inst_name not in self._quot['inst']:
                    quot_conf = self._quot['list'][inst_name]
                    cls, args = quot_conf['cls'], quot_conf['args']
                    inst = cls(self, **args)
                    if not inst.init():
                        self.log.error('初始化行情源 {} 失败'.format(inst_name))
                        return False
                    self._quot['inst'][inst_name] = inst

                inst = self._quot['inst'][inst_name] if inst_name in self._quot['inst'] else None
                if inst is None:
                    self.log.error('无法找到行情源配置: func={}, quot={}'.format(func_name, inst_name))
                    return False
                func = getattr(inst, func_name)
                if func is None:
                    self.log.error('行情源配置错误: func={}, quot={}'.format(func_name, inst_name))
                    return False
                self._barbar_quot[func_name] = func, inst.is_sequence()

        return True

    def setup_db(self, mod):
        source_name = self._js['db']['source']
        source_args = self._js['db']['args']
        inst = self._db['list'][source_name](source_args)
        if not inst.init():
            self.log.error('初始化数据源 {} 失败'.format(source_name))
            return False
        self._db['inst'][source_name] = inst
        self._barbar_db = self._db['inst'][source_name]

        return True

    def setup_log(self, mod):
        if self._config_path is None:
            return True

        try:
            with open(self._config_path) as f:
                self._js = json.load(f)
        except Exception as e:
            print('加载配置文件异常: {}'.format(e))
            return False

        path = self._js['log']['path']
        if not path.endswith(os.sep):
            path += os.sep
        filename = self._js['log']['name']
        if filename != '' and not filename.endswith('-'):
            filename += '-'
        filename = path + filename + mod + '.log'
        level = self._js['log']['level']
        log.setup_logger(filename=filename, level=level)

        self.log = log.get_logger(self.__class__.__name__)
        return True

    def init(self, mod):
        if not self.setup_log(mod):
            return False

        if not self.setup_db(mod):
            return False

        return self.setup_quot(mod)


def parse_arguments(opt_desc=''):
    args = None
    try:
        parser = argparse.ArgumentParser(description='barbarian process')
        parser.add_argument('--config', required=True, help='path to config')
        parser.add_argument('opt', metavar='options', type=str, nargs='*',
                            help='options: ' + opt_desc)
        args = parser.parse_args()
    except SystemExit as e:
        os._exit(0)

    if args is None:
        return None, None

    opts = {}
    if hasattr(args, 'opt') and args.opt is not None:
        for v in args.opt:
            idx = v.find('=')
            if idx == -1:
                opts[v] = True
                continue

            k = v[:idx]
            v = v[idx + 1:]
            if len(k) == 0 or len(v) == 0:
                continue

            if v.find(';') == -1 and v.find('=') == -1:
                opts[k] = v
                continue

            opts[k] = {}
            kv = v.split(';')
            for i, v in enumerate(kv):
                if i == 0:
                    opts[k][k] = v
                    continue
                kv_s = v.split('=')
                if len(kv_s) != 2:
                    opts[k][kv_s] = True
                    continue
                opts[k][kv_s[0]] = kv_s[1]

    return args.config, opts


def load_strategy(dir_path, package, exclude=()):
    strategy = {}
    for root_path, dirs, files in os.walk(dir_path):
        if root_path.find('__') >= 0 or root_path.startswith('.'):
            continue

        package_suf = ''
        if dir_path != root_path:
            package_suf = '.' + root_path[len(dir_path) + 1:].replace(os.sep, '.')

        for file_name in files:
            if not file_name.endswith('.py'):
                continue

            if file_name.startswith('__') or file_name.startswith('.') or file_name in exclude:
                continue

            module = importlib.import_module('{}.{}'.format(package + package_suf, file_name[:-3]))

            file_names = file_name[:-3].split('_')
            name_list = [file_name.capitalize() for file_name in file_names]
            cls_name = ''.join(name_list)
            cls = module.__getattribute__(cls_name)
            if cls is not None:
                if len(package_suf) > 0:
                    package_suf = package_suf[1:] + '.'
                strategy[package_suf + cls_name] = cls
            else:
                print(
                    'warning: file {} not following strategy naming convention'.format(root_path + os.sep + file_name))

    return strategy


if __name__ == '__main__':
    # js = None
    # with open('/Users/luoguochun/Downloads/js.json') as f:
    #     js = json.load(f)
    #
    #
    # @singleton
    # class B(BaseRepository):
    #     def __init__(self, js=None):
    #         super().__init__(js)
    #
    #
    # a = B(js)
    # b = B(js)
    #
    # df = B().quot.get_code_list()
    # print(df)

    import selector

    print(selector.strategy)
