import logging
from logging.handlers import TimedRotatingFileHandler
import os.path

_log_dict = {
    'level': logging.INFO,
    'filename': None,
    'logs': []
}

_log_level = {
    'CRITICAL': logging.CRITICAL,
    'FATAL': logging.FATAL,
    'ERROR': logging.ERROR,
    'WARN': logging.WARNING,
    'WARNING': logging.WARNING,
    'INFO': logging.INFO,
    'DEBUG': logging.DEBUG,
    'NOTSET': logging.NOTSET,
}


def setup_logger(filename=None, level='info'):
    _log_dict['filename'] = filename

    level = level.upper()
    level = _log_level[level] if level in _log_level else logging.INFO
    _log_dict['level'] = level


def get_logger(name='BARBAR'):
    log = logging.getLogger(name)
    if name not in _log_dict['logs']:
        log.setLevel(_log_dict['level'])
        ch = logging.StreamHandler()
        ch.setLevel(_log_dict['level'])
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        log.addHandler(ch)
        if _log_dict['filename'] is not None:
            # ch = logging.FileHandler(_log_dict['filename'])
            ch = TimedRotatingFileHandler(_log_dict['filename'], 'D', 1)
            ch.setLevel(_log_dict['level'])
            ch.setFormatter(formatter)
            log.addHandler(ch)
    return log
