
class Robot:
    def __init__(self, trader):
        self.trader = trader

    def init(self, **kwargs):
        pass

    def start(self):
        pass

    def stop(self):
        pass