import argparse
import json
import sys
import time
import log
from eventbus import task, on, emit, evt_bind, task_bind
import tornado.tcpserver
import tornado.httpserver
import tornado.web
import tornado.ioloop
from tornado.iostream import StreamClosedError


class BarbarTCPServer(tornado.tcpserver.TCPServer):
    def __init__(self):
        super().__init__()
        self.log = log.get_logger(self.__class__.__name__)

    async def handle_stream(self, stream, address):
        stream.set_nodelay(True)
        while True:
            try:
                size_str = await stream.read_until(b"\n")
                size_str = size_str[:-1]
                size = int(size_str)
                pack = stream.read_bytes(size, True)
                emit(cat='barbar', event='evt_request', payload=(stream, address, pack))
            except StreamClosedError:
                break
            except ValueError:
                stream.close()


class BarbarReqHandler(tornado.web.RequestHandler):
    def get(self, *args, **kwargs):
        self.write("Hello, world")

    def post(self, *args, **kwargs):
        param = self.request.body.decode('utf-8')
        try:
            js = json.loads(param, encoding='utf-8')
        except:
            self.write('h2->{}'.format(param))


class Barbar404Handler(tornado.web.RequestHandler):
    def get(self, *args, **kwargs):
        js = {
            'code': -1,
            'msg': 'request not support!'
        }
        self.write(json.dumps(js, ensure_ascii=False))


class BarbarianServer:
    def __init__(self, config_path):
        self.log = log.get_logger(self.__class__.__name__)

        self.config_path = config_path
        self.js = None

        self.tcpservers = []
        self.httpservers = []

        self.req_queue = {}

        evt_bind(cat='barbar', func=self.on_request)
        evt_bind(cat='barbar', func=self.on_out)
        evt_bind(cat='barbar', func=self.on_broadcast)
        task_bind(cat='barbar', func=self.on_clear_idle)

    def init(self):
        with open(self.config_path) as f:
            js = json.load(f)
            self.js = js

        if not log.setup_logger(js['log']['path'], 'barbarian.log', js['log']['level']):
            raise Exception('初始化日志错误: 日志路径不存在')

    def _init_tcpserver(self):
        enable = self.js['barbar']['listen']['socket']['enable']
        if not enable:
            return True
        servers = self.js['barbar']['listen']['socket']['address'].split(',')
        for server in servers:
            pass

    def _init_httpserver(self):
        pass

    def start(self):
        pass

    @on(cat='barbar', event='evt_request')
    async def on_request(self, payload):
        stream, address, packet = payload
        self.log.info('接收数据: 地址 -> {}, 报文 -> {}'.format(address, packet))
        try:
            js = json.loads(packet)
            sid = js['sid']
            if sid in self.req_queue:
                await stream.write(b'')
                return

            self.req_queue[sid] = stream

        except Exception as e:
            self.log.error('')

    @on(cat='barbar', event='evt_out')
    async def on_out(self, payload):
        pass

    @on(cat='barbar', event='evt_broadcast')
    def on_broadcast(self, payload):
        pass

    @task(cat='barbar', every='1m')
    def on_clear_idle(self):
        print('on idle{}'.format(time.time))


def main():
    parser = argparse.ArgumentParser(description='barbarian main control process')
    parser.add_argument('--config', required=True, help='path to config')
    args = parser.parse_args()

    barbar = BarbarianServer(args.config)

    try:
        barbar.init()
    except Exception as e:
        print('barbarian 初始化异常: {}'.format(e))
        sys.exit(-1)

    try:
        barbar.start()
    except InterruptedError:
        sys.exit(0)


if __name__ == '__main__':
    # main()
    # application = tornado.web.Application([
    #     (r'/', BarbarReqHandler),
    #     (r'(.*)', Barbar404Handler)
    # ])
    # srv = tornado.httpserver.HTTPServer(application)
    # srv.listen(8888)
    # tornado.ioloop.IOLoop.instance().start()

    config = {
        'log': {
            'path': './logs/a.log',
            'level': {
                'console': 'info',
                'file': 'info'
            },
        },
        'db': {
            'source': 'mongo',
            'args': {
                'uri': 'mongodb://localhost:37017/',
                'pool': 5
            },
        },
        'quot': {
            'list': [
                {'name': 'tushare', 'enable': True, 'args': {'token': '408481e156da6a5facd695e58add4d0bf705649fe0f460d03d4d6908'}},
                {'name': 'pytdx', 'enable': False, 'args': {}},
                {'name': 'tencent', 'enable': True, 'args': {}}
            ],
            'func': {
                'get_trade_cal': {'name': 'tushare', 'thread': False},
                'get_code_list': {'name': 'tushare', 'thread': False},
                'get_code_kdata': {'name': 'tushare', 'thread': False},
                'get_code_adj_factor': {'name': 'tushare', 'thread': False},
                'get_code_daily_index': {'name': 'tushare', 'thread': False},
                'get_code_trans': {'name': 'tencent', 'thread': True},
                'get_index_list': {'name': 'tushare', 'thread': False},
                'get_index_kdata': {'name': 'tushare', 'thread': False}
            }
        },
        'barbar': {
            'listen': {
                'socket': {
                    'enable': True,
                    'address': '127.0.0.1:8900,127.0.0.1:8901'
                },
                'http': {
                    'enable': False,
                    'address': '127.0.0.1:9900,127.0.0.1:9901'
                }
            },
            'module': {
                'data': {
                    'enable': True,
                    'keep_alive': True,
                    'launch_now': True
                },
                'selector': {
                    'enable': False,
                    'keep_alive': False,
                    'launch_now': False
                },
                'backtest': {
                    'enable': False,
                    'keep_alive': False,
                    'launch_now': False
                },
                'trader': {
                    'enable': False,
                    'keep_alive': True,
                    'launch_now': False
                },
                'risk': {
                    'enable': False,
                    'keep_alive': True,
                    'launch_now': False
                }
            },
        },
    }
    with open('test/config.json', 'w+') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

    with open('test/config.json') as f:
        js = json.load(f)
    print(js)
    print(js['quot']['list'])
