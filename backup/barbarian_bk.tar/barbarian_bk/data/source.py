from abc import ABC, abstractmethod


class Source(ABC):
    def init(self):
        return False

    @abstractmethod
    def source(self):
        pass

    @abstractmethod
    def load_codes(self, **kwargs):
        """
        获取股票信息
        :param kwargs: codes=[]
        :return: None 或 DataFrame
        """
        pass

    @abstractmethod
    def save_codes(self, **kwargs):
        """
        保存股票信息
        :param kwargs: stocks=[DataFrame]
        :return: None / insert ids
        """
        pass

    @abstractmethod
    def load_trade_days(self, **kwargs):
        """

        :param kwargs: start=yyyymmdd, end=yyyymmdd
        :return:
        """
        pass

    @abstractmethod
    def save_trade_days(self, **kwargs):
        """

        :param kwargs:
        :return:
        """
        pass

    @abstractmethod
    def load_code_bar(self, **kwargs):
        """
        返回日k线数据
        :param kwargs: start=yyyymmdd, end=yyyymmdd, codes=[],
            codes == None或空，则返回所有股票
        :return: None 或 pandas DataFrame，DataFrame字段：
            code 股票代码
            trade_date 交易日期
            open 开盘价
            high 最高价
            low 最低价
            close 收盘价
            volume 成交量（手）
            amount	成交额（元）
        """
        pass

    @abstractmethod
    def save_code_bar(self, **kwargs):
        """
        保存日k数据
        :param kwargs: stocks=[(code, DataFrame)]
        :return:
        """
        pass

    @abstractmethod
    def load_transaction(self, **kwargs):
        """
        返回成交笔数
        :param kwargs: start=yyyymmdd, end=yyyymmdd, codes=[]
        :return: None 或 pandas DataFrame 字典，DataFrame字段：
            code 股票代码
            time 成交时间
            price 成交价格
            volume	成交量(手)
            amount 成交额(元)
            type 性质(-1 卖盘 0 中性盘 1 买盘)
        """
        pass

    @abstractmethod
    def save_transaction(self, **kwargs):
        """
        保存成交笔数数据
        :param kwargs: stocks[(code, DataFrame)]
        :return:
        """
        pass
