import threading
from functools import partial
import time
from datetime import datetime
import sys
from collections import OrderedDict
import copy
import log
from queue import Queue
from eventbus import *
from common import *
import errno
import pandas as pd


class Data(threading.Thread):
    funcs = 'code_kdata,code_index,code_trans,index_kdata,build_index'.split(',')

    def __init__(self, repo, **kwargs):
        super().__init__()
        self.log = log.get_logger(self.__class__.__name__)
        self.repo = repo
        self.quot = repo.quot
        self.db = repo.db
        self.running = False

        self.cache_path = None

        self.kwargs = kwargs
        self.log.info('kwargs={}'.format(self.kwargs))

        # 命令行参数
        self.start_date = None if 'start_date' not in self.kwargs else \
            datetime.strptime(self.kwargs['start_date'], '%Y%m%d')
        self.end_date = None if 'end_date' not in self.kwargs else \
            datetime.strptime(self.kwargs['end_date'], '%Y%m%d')
        self.func = self.kwargs['func'].split(',') if 'func' in self.kwargs else self.funcs
        self.type = 'sync' if 'type' not in self.kwargs else self.kwargs['type']
        self.sync_basic = True if 'sync_basic' not in self.kwargs else self.kwargs['sync_basic'] == 'true'

        self.sync_quot_lock = threading.Lock()
        self.sync_quot_running = defaultdict(int)
        self.sync_quot_queue_count = 25 if 'quot_thread_count' not in self.kwargs else int(
            self.kwargs['quot_thread_count'])
        self.sync_quot_queue = {}

        self.sync_db_lock = threading.Lock()
        self.sync_db_running = defaultdict(int)
        self.sync_db_queue_count = 25 if 'db_thread_count' not in self.kwargs else int(self.kwargs['db_thread_count'])
        self.sync_db_queue = {}

        self.proc_hook = None

        evt_bind(cat='data', func=self._sync_status, target=self)
        evt_bind(cat='data', func=self._sync_sync_process, target=self)
        evt_bind(cat='data', func=self._sync_queue_poll, target=self)

        self._setup_cache_path()

    def set_proc_hook(self, func):
        self.proc_hook = func

    @on(cat='data', event='evt_sync_status')
    def _sync_status(self, payload):
        if self.proc_hook is not None:
            self.proc_hook(payload)

    def _get_sync_trad_cal(self, typ=None, filter=None, sync_status=False):
        now = datetime.now()
        now = datetime(year=now.year, month=now.month, day=now.day, hour=0, minute=0, second=0)

        flter = {}
        if self.start_date is not None:
            flter['$gte'] = self.start_date
        if self.end_date is not None:
            flter['$lt'] = self.end_date
        if len(flter) == 0:
            flter = {'$lt': now}
        trade_dates = self.db.load_trade_cal(filter={
            'cal_date': flter,
            'is_open': 1
        }, projection=['cal_date'], sort=[('cal_date', -1)])

        trade_dates = trade_dates['cal_date'].tolist()
        if sync_status:
            db_trade_dates = self.db.load_sync_status(typ, filter=filter, projection=['trade_date'])
            if db_trade_dates is not None:
                db_trade_dates = db_trade_dates['trade_date'].tolist()
                trade_dates = set(trade_dates).difference(db_trade_dates)
                trade_dates = list(trade_dates)

        trade_dates.sort(reverse=True)
        return trade_dates

    def _sync_basic_data(self):
        if self.sync_basic:
            self.log.info('开始同步基础数据...')
            self.log.info('获取股票列表...')

            codes = self.quot.get_code_list()
            if codes is None:
                self.log.error('获取股票列表错误')
                return None, None, None

            self.log.info('保存股票列表, count = {} ...'.format(codes.shape[0]))
            self.db.save_code_list(codes=codes)

            self.log.info('获取股票交易日...')
            trad_cals = self.quot.get_trade_cal()
            if trad_cals is None:
                self.log.error('获取交易日错误')
                return None, None, None

            self.log.info('保存股票交易日...')
            self.db.save_trade_cal(cals=trad_cals)

            self.log.info('获取股票指数数据...')
            indexes = self.quot.get_index_list()
            if indexes is None:
                self.log.error('获取股票指数数据')
                return None, None, None

            self.log.info('保存股票指数数据...')
            self.db.save_index_list(indexes=indexes)

            return codes, indexes

        self.log.info('开始获取数据库基础数据...')
        return self.db.load_code_list(projection=['code'], sort=[('code', 1)]), self.db.load_index_list(
            projection=['code'], sort=[('code', 1)])

    def _setup_cache_path(self):
        self.cache_path = self.repo.config['data']['cache']['path']
        if self.cache_path is None or len(self.cache_path) == 0:
            self.log.warn('cache path 为空')
            self.cache_path = None
        else:
            try:
                if not self.cache_path.endswith(os.sep):
                    self.cache_path = self.cache_path + os.sep
                os.makedirs(self.cache_path, exist_ok=True)
            except OSError as e:
                if e.errno == errno.EEXIST and os.path.isdir(self.cache_path):
                    pass
                else:
                    self.log.warn('创建 cache path={} 异常', self.cache_path)
                    self.cache_path = None

    def _get_cache_path(self, typ, quot_args):
        filename = ''
        keys = list(quot_args.keys())
        keys.sort()

        for k in keys:
            v = quot_args[k]
            if len(filename) == 0:
                filename = k + '=' + v
            else:
                filename = filename + '-' + k + '=' + v
        filename = filename + '.pickle'
        dir_path = self.cache_path + typ + os.sep
        return dir_path, filename

    def _get_cache(self, typ, quot_args):
        dir_path, filename = self._get_cache_path(typ, quot_args)
        if dir_path is None or filename is None:
            return None

        if not os.path.exists(dir_path + filename):
            return None
        try:
            df = pd.read_pickle(dir_path + filename, compression='gzip')
            return df
        except Exception as e:
            self.log.error('加载缓存数据异常: path={}'.format(dir_path + filename))
            return None

    def _save_cache(self, typ, quot_args, data):
        dir_path, filename = self._get_cache_path(typ, quot_args)
        if not os.path.exists(dir_path):
            try:
                os.makedirs(dir_path)
            except Exception as e:
                self.log.error('创建缓存目录异常: path={}'.format(dir_path))
                return False
        file_path = dir_path + filename
        try:
            data.to_pickle(file_path, compression='gzip')
            return True
        except Exception as e:
            self.log.error('保存缓存异常: path={}, e={}'.format(file_path, e))
            return False

    def _get_quot(self, typ, quot_func, quot_args):
        data = self._get_cache(typ, quot_args)
        if data is None:
            self.log.info('获取行情数据: {}'.format(typ))
            data = quot_func(**quot_args)
            if data is None:
                self.log.error('{}获取行情数据异常'.format(typ))
                return None
            self._save_cache(typ, quot_args, data)

        return data

    def _sync_db_quot(self, payload):
        role, typ, quot_func, quot_args, db_save_func, data = payload['role'], payload['typ'], payload['quot_func'], \
                                                              payload['quot_args'], payload['db_save_func'], payload[
                                                                  'data']
        data = quot_func(quot_args=quot_args)
        if data is not None:
            if typ not in self.sync_db_queue:
                self.sync_db_queue[typ] = Queue()
                emit(cat='data', event='evt_sync_queue_poll', payload=(typ, self.sync_db_queue[typ], 'db'))

            self.sync_db_queue[typ].put(
                dict(quot_func=quot_func, quot_args=quot_args, db_save_func=db_save_func, data=data),
                block=False)

    @on(cat='data', event='evt_sync_process', thread=True)
    def _sync_sync_process(self, payload):
        role, typ, quot_func, quot_args, db_save_func, data = payload['role'], payload['typ'], payload['quot_func'], \
                                                              payload['quot_args'], payload['db_save_func'], payload[
                                                                  'data']

        emit(cat='data', event='evt_sync_status', payload=dict(role=role, typ=typ, quot_args=quot_args, status=False))
        self.log.info('{}, {}线程同步开始'.format(role, typ, quot_args))
        if role == 'quot':
            self._sync_db_quot(payload=payload)
        else:
            db_save_func(data=data)

        locker = self.sync_quot_lock if role == 'quot' else self.sync_db_lock
        with locker:
            if role == 'quot':
                self.sync_quot_running[typ] -= 1
            else:
                self.sync_db_running[typ] -= 1

        emit(cat='data', event='evt_sync_status', payload=dict(role=role, typ=typ, quot_args=quot_args, status=True))

    @on(cat='data', event='evt_sync_queue_poll', thread=True)
    def _sync_queue_poll(self, payload):
        typ, q, role = payload
        self.log.info('new poll: {} {}'.format(role, typ))
        while self.running:
            try:
                q_dict = q.get()
                quot_func, quot_args, db_save_func, data = q_dict['quot_func'], q_dict['quot_args'], q_dict[
                    'db_save_func'], q_dict['data']
                self.log.info('{} 同步: {} {}'.format(role, typ, quot_args))
                queue_count = self.sync_quot_running[typ] if role == 'quot' else self.sync_db_running[typ]
                max_count = self.sync_quot_queue_count if role == 'quot' else self.sync_db_queue_count
                wait_count = 0
                while queue_count > max_count and self.running:
                    self.log.info(
                        '{} {}当前线程数{}已经超过{}, 等待10s后再尝试, 已经等待{}次'.format(role, typ, queue_count, max_count,
                                                                        wait_count))
                    time.sleep(10)
                    wait_count += 1
                    queue_count = self.sync_quot_running[typ] if role == 'quot' else self.sync_db_running[typ]

                locker = self.sync_quot_lock if role == 'quot' else self.sync_db_lock

                with locker:
                    if role == 'quot':
                        self.sync_quot_running[typ] += 1
                    else:
                        self.sync_db_running[typ] += 1

                emit(cat='data', event='evt_sync_process',
                     payload=dict(role=role, typ=typ, quot_func=quot_func, quot_args=quot_args,
                                  db_save_func=db_save_func, data=data))

            except Exception as e:
                self.log.error('_sync_queue_poll 异常: {}'.format(e))

    def _sync_call(self, typ, quot_func, quot_args, db_save_func, is_seq):
        if not is_seq:
            if typ not in self.sync_quot_queue:
                self.sync_quot_queue[typ] = Queue()
                emit(cat='data', event='evt_sync_queue_poll', payload=(typ, self.sync_quot_queue[typ], 'quot'))

            self.sync_quot_queue[typ].put(
                dict(quot_func=quot_func, quot_args=quot_args, db_save_func=db_save_func, data=None),
                block=False)
        else:
            emit(cat='data', event='evt_sync_status',
                 payload=dict(role='quot', typ=typ, quot_args=quot_args, status=False))

            self._sync_db_quot(
                payload=dict(role='db', typ=typ, quot_func=quot_func, quot_args=quot_args, db_save_func=db_save_func,
                             data=None))

            emit(cat='data', event='evt_sync_status',
                 payload=dict(role='quot', typ=typ, quot_args=quot_args, status=True))

    def sync_index_data(self, indexes):
        if 'index_kdata' in self.func:
            # 全量同步
            now = datetime.now()
            end_date = now.strftime('%Y%m%d')
            for index in indexes['code']:
                self.log.info('全量同步交易日{}指数成交数据...'.format(index))
                quot_func = partial(self._get_quot, typ='index_kdata',
                                    quot_func=self.quot.get_index_kdata)

                self._sync_call(typ='index_kdata', quot_func=quot_func,
                                quot_args=dict(end_date=end_date, code=index),
                                db_save_func=self.db.save_index_kdata,
                                is_seq=self.quot.is_sequence(self.quot.get_index_kdata))

    def _sync_code_kdata(self):
        if 'code_kdata' in self.func:
            trade_cals = self._get_sync_trad_cal(typ='code_kdata')
            self.log.info('code_kdata 交易日历size={}'.format(len(trade_cals)))
            for trade_cal in trade_cals:
                trade_date = trade_cal.strftime('%Y%m%d')

                self.log.info('开始同步交易日{}日k线数据...'.format(trade_date))
                quot_func = partial(self._get_quot, typ='code_kdata',
                                    quot_func=self.quot.get_code_kdata)

                self._sync_call(typ='code_kdata', quot_func=quot_func,
                                quot_args=dict(trade_date=trade_date),
                                db_save_func=self.db.save_code_kdata,
                                is_seq=self.quot.is_sequence(self.quot.get_code_kdata))

    def _sync_code_index(self):
        if 'code_index' in self.func:
            trade_cals = self._get_sync_trad_cal(typ='code_index')
            self.log.info('code_index 交易日历size={}'.format(len(trade_cals)))
            for trade_cal in trade_cals:
                trade_date = trade_cal.strftime('%Y%m%d')
                self.log.info('开始同步交易日{}每日指标数据...'.format(trade_date))
                quot_func = partial(self._get_quot, typ='code_index',
                                    quot_func=self.quot.get_code_daily_index)

                self._sync_call(typ='code_index', quot_func=quot_func,
                                quot_args=dict(trade_date=trade_date),
                                db_save_func=self.db.save_code_daily_index,
                                is_seq=self.quot.is_sequence(self.quot.get_code_daily_index))

    def _sync_code_trans(self, codes):
        if 'code_trans' in self.func:
            now = datetime.now()
            now = datetime(year=now.year, month=now.month, day=now.day, hour=0, minute=0, second=0)
            trade_cals = self._get_sync_trad_cal()

            for trade_cal in trade_cals:
                self.log.info('code_trans 交易日历size={}'.format(len(trade_cals)))
                trade_date = trade_cal.strftime('%Y%m%d')
                for code in codes['code']:
                    trade_cals = self._get_sync_trad_cal(typ='code_trans',
                                                         filter={'code': code, 'trade_date': {'$lt': now}})

                    quot_func = partial(self._get_quot, typ='code_trans',
                                        quot_func=self.quot.get_code_trans)

                    self._sync_call(typ='code_trans', quot_func=quot_func,
                                    quot_args=dict(code=code, trade_date=trade_date),
                                    db_save_func=self.db.save_code_trans,
                                    is_seq=self.quot.is_sequence(self.quot.get_code_trans))

    def sync_code_data(self, codes):
        self._sync_code_kdata()
        self._sync_code_index()
        self._sync_code_trans(codes=codes)

    def start(self):
        if self.cache_path is None:
            self.log.error('cache_path 为空')
            return False

        for func in self.func:
            if func not in self.funcs:
                self.log.error('无效 func {}'.format(func))
                return False

        self.running = True
        super().start()

        return True

    def stop(self):
        bus_stop()
        self.running = False

    def _is_syncing(self):
        for k, v in self.sync_quot_running.items():
            if v > 0:
                return True

        for k, v in self.sync_db_running.items():
            if v > 0:
                return True

        return False

    def run(self):
        if 'build_index' == self.type:
            return self.db.build_index()

        while self.running:
            codes, indexes = self._sync_basic_data()
            if codes is None or indexes is None:
                self.log.error('获取基础数据异常, codes={}, indexes={}'.format(
                    codes.shape[0] if codes is not None else None,
                    indexes.shape[0] if indexes is not None else None))
                self.running = False
                return

            self.sync_code_data(codes)
            self.sync_index_data(indexes)

            self.db.build_index()

            self.log.info('循环结束，等待线程同步完成')
            while self.running:
                if self._is_syncing():
                    self.log.info('{} 线程未结束, 等待30s')
                    time.sleep(30)
                    continue
                break
            self.log.info('循环完成')


@singleton
class DataRepository(BaseRepository):
    def __init__(self, config_path):
        super().__init__(config_path)


def data_proc():
    config_path, opts = parse_arguments(
        opt_desc='start_date=yyyyMMdd end_date=yyyyMMdd type=sync|compensate sync_basic '
                 'quot_thread_count=25 db_thread_count func=code_kdata,code_index,code_trans,index_kdata,build_index')
    if config_path is None or opts is None:
        print('parse_arguments ailed')
        os._exit(-1)

    repo = DataRepository(config_path)
    if not repo.init('data'):
        print('req init failed')
        os._exit(-1)

    d = Data(repo, **opts)
    if d.start():
        d.join()
    bus_stop()


if __name__ == '__main__':
    data_proc()
