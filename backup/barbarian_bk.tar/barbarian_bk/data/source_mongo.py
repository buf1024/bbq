from functools import wraps
from collections import namedtuple
from threading import Lock
import pymongo
from pymongo.errors import ConnectionFailure
import time
import traceback
import pandas as pd
from collections import OrderedDict
import log


class SourceMongo:
    _MongoStat = namedtuple('_MongoStat', ['client', 'count', 'last'])

    _common_db = 'common_db'  # 通用数据库
    _code_info_col = 'code_info_col'  # 股票信息
    _index_info_col = 'index_info_col'  # 指数信息
    _trade_cal_col = 'trade_cal_col'  # 交日日历

    _code_kdata_db = 'code_kdata_db'  # 股票日K数据库
    _code_index_db = 'code_index_db'  # 股票日指标数据库
    _code_trans_db = 'code_trans_db'  # 股票日成交数据库

    _index_kdata_db = 'index_kdata_db'  # 指数日K数据库

    _sync_status_db = 'sync_status_db'  # 同步状态数据库
    _sync_code_kdata_col = 'code_kdata_col'
    _sync_code_index_col = 'code_index_col'
    _sync_code_trans_col = 'code_trans_col'
    _sync_index_kdata_col = 'index_kdata_col'

    _status_dict = {
        'code_kdata': _sync_code_kdata_col,
        'code_trans': _sync_code_trans_col,
        'code_index': _sync_code_index_col,
        'index_kdata': _sync_index_kdata_col
    }

    _trader_db = 'trader_db'
    _deal_col = 'deal_col'
    _entrust_col = 'entrust_col'
    _account_col = 'account_col'

    _trader_dict = {
        'deal': _deal_col,
        'entrust': _entrust_col,
        'account': _account_col
    }

    _strategy_db = 'strategy_db'
    _strategy_col = 'strategy_col'
    _strategy_his_col = '_strategy_his_col'

    def __init__(self, args):
        self.log = log.get_logger(self.__class__.__name__)
        self.lock = Lock()
        self.clients = []
        self.uri, self.pool = args['uri'], args['pool']

    def _best_client(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            stat_client = None
            with self.lock:
                self.clients = sorted(self.clients, key=lambda stat: (stat.count, -stat.last))
                stat_client = self.clients[0]
                self.clients[0] = stat_client._replace(count=stat_client.count + 1, last=time.time())

            kwargs['__client'] = stat_client.client
            return func(self, *args, **kwargs)

        return wrapper

    @property
    def common_db(self):
        return self._common_db

    @property
    def code_kdata_db(self):
        return self._code_kdata_db

    @property
    def code_index_db(self):
        return self._code_index_db

    @property
    def code_trans_db(self):
        return self._code_trans_db

    @property
    def index_kdata_db(self):
        return self._index_kdata_db

    @property
    def code_info_col(self):
        return self._code_info_col

    @property
    def index_info_col(self):
        return self._index_info_col

    @property
    def trade_cal_col(self):
        return self._trade_cal_col

    def get_coll(self, db, col):
        client = self._get_client()
        return client[db][col]

    def init(self):
        self.pool = self.pool if self.pool > 0 else 1
        try:
            for _ in range(self.pool):
                client = pymongo.MongoClient(self.uri, connect=False)
                client.admin.command('ismaster')
                self.clients.append(self._MongoStat(client=client, count=0, last=time.time()))
        except ConnectionFailure as e:
            self.log.error('mongo db 无法连接: uri={}, ex={}'.format(self.uri, e))
            return False

        return True

    def source(self):
        return 'mongo'

    def load_sync_status(self, typ, **kwargs):
        self.log.info('加载保存状态信息: typ={}, kwargs={}'.format(typ, kwargs))

        if typ not in self._status_dict:
            self.log.error('类型 {} 不合法'.format(typ))
            return None
        col = self.get_coll(self._sync_status_db, self._status_dict[typ])
        return self._do_load(col, **kwargs)

    def build_index(self):
        self.log.info('创建索引: db={}, col={}'.format(self._common_db, self._trade_cal_col))
        self._build_index(self._common_db, self._trade_cal_col, index=[('cal_date', -1)])

        self.log.info('创建索引: db={}, col={}'.format(self._common_db, self._code_info_col))
        self._build_index(self._common_db, self._code_info_col, index=[('code', 1)])

        self.log.info('创建索引: db={}, col={}'.format(self._common_db, self._index_info_col))
        self._build_index(self._common_db, self._index_info_col, index=[('code', -1)])

        indexes = self.load_index_list(projection=['code'])
        if indexes is None:
            self.log.warn('指数列表为空，无法对指数索引')
        else:
            for index in indexes.to_dict('records'):
                self.log.info('创建索引: db={}, col={}'.format(self._code_index_db, index['code']))
                self._build_index(self._code_index_db, index['code'], index=[('trade_date', -1)])

        codes = self.load_code_list(projection=['code'])
        if codes is None:
            self.log.warn('股票列表为空，无法对指数索引')
        else:
            for code in codes.to_dict('records'):
                self.log.info('创建索引: db={}, col={}'.format(self._code_index_db, code['code']))
                self._build_index(self._code_trans_db, code['code'], index=[('time', -1), ('trade_date', -1)],
                                  index_uniq=False)
                self.log.info('创建索引: db={}, col={}'.format(self._code_index_db, code['code']))
                self._build_index(self._index_kdata_db, code['code'], index=[('trade_date', -1)])

        self.log.info('创建索引完成')

    def _build_index(self, db, col, index, index_uniq=True):
        try:
            client = self._get_client()
            if client is None:
                raise Exception('数据库未连接')

            client[db][col].create_index(index, unique=index_uniq)
        except Exception as e:
            self.log.error('创建index异常{}\n db={} col={} call stack: {}'.format(e, db, col, traceback.format_exc()))

    def _save_sync_status(self, typ, filter, data, index, index_uniq=True):
        coll = self.get_coll(self._sync_status_db, self._status_dict[typ])
        self._do_update(coll=coll, filter=filter, update=data)
        try:
            coll.create_index(index, unique=index_uniq)
        except Exception as e:
            self.log.error(
                '创建index异常{}\n db={} col={} call stack: {}'.format(e, self._sync_status_db, self._status_dict[typ],
                                                                   traceback.format_exc()))

    @_best_client
    def _get_client(self, **kwargs):
        return kwargs['__client'] if '__client' in kwargs else None

    def _do_load(self, coll, filter=None, projection=None, skip=0, limit=0, sort=None, to_frame=True):
        try:
            cursor = coll.find(filter=filter, projection=projection, skip=skip, limit=limit, sort=sort)
            if cursor is not None:
                data = [item for item in cursor]
                cursor.close()
                if to_frame:
                    df = pd.DataFrame(data=data, columns=projection)
                    return None if df.empty else df
                else:
                    return data
            return None
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self._do_load.__name__, traceback.format_exc())

    def _do_batch_load(self, codes, col_func, **kwargs):
        codes = [code.upper() for code in codes]
        d = OrderedDict()
        for code in codes:
            coll = col_func(self._get_client(), code)
            df = self._do_load(coll, **kwargs)
            d[code] = df
        return None if len(d) == 0 else d

    def _do_update(self, coll, filter=None, update=None):
        try:
            if update is None:
                return None
            res = coll.update_one(filter, {'$set': update}, upsert=True)
            return res.upserted_id
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self._do_update.__name__, traceback.format_exc())

    def _do_delete(self, coll, filter=None, just_one=True):
        try:
            res = coll.remove(filter, {'justOne': just_one})
            return res.upserted_id
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self._do_delete.__name__, traceback.format_exc())


    def _do_batch_update(self, coll_func, data_frames, filter_func=None, index=None, index_uniq=True):
        id_list = []
        for item in data_frames.to_dict('records'):
            coll = coll_func(self._get_client(), item['code'].upper() if 'code' in item else None)
            # if index is not None:
            #     try:
            #         coll.create_index(index, unique=index_uniq)
            #     except Exception as e:
            #         self.log.error('创建index异常{}\n item={} call stack: {}'.format(e, item, traceback.format_exc()))

            filter = None if filter_func is None else filter_func(item)
            ids = self._do_update(coll, filter=filter, update=item)
            if ids is None:
                continue
            if isinstance(ids, list):
                id_list = id_list + ids
            else:
                id_list.append(ids)
        return id_list if len(id_list) > 0 else None

    def load_code_list(self, **kwargs):
        """
        :param kwargs: filter=None, projection=None, skip=0, limit=0, sort=None
        :return: DataFrame[_id, code name area industry market exchange]
        """
        self.log.info('加载股票列表, kwargs={}'.format(kwargs))
        client = self._get_client()
        coll = client[self._common_db][self._code_info_col]
        return self._do_load(coll, **kwargs)

    def save_code_list(self, codes):
        """
        :param codes: DataFrame[_id, code name area industry market exchange]
        :return: None/list[_id]
        """
        self.log.info('保存股票列表, count = {}'.format(codes.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._code_info_col],
                                     data_frames=codes, filter_func=lambda item: {'code': item['code']},
                                     index=[('code', 1)])

    def load_trade_cal(self, **kwargs):
        """
        :param kwargs:  filter=None, projection=None, skip=0, limit=0, sort=None
        :return: DataFrame[_id, cal_date,is_open]
        """
        self.log.info('加载交易日历, kwargs={}'.format(kwargs))
        client = self._get_client()
        coll = client[self._common_db][self._trade_cal_col]
        return self._do_load(coll, **kwargs)

    def save_trade_cal(self, cals):
        """
        :param cals: DataFrame[cal_date,is_open]
        :return: None/list[_id]
        """
        self.log.info('保存交易日历, count = {} ...'.format(cals.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._trade_cal_col],
                                     data_frames=cals, filter_func=lambda item: item,
                                     index=[('cal_date', -1)])

    def load_code_adj_kdata(self, codes=None, **kwargs):
        self.log.info('加载复权因子, kwargs={}'.format(kwargs))
        filter = None if 'filter' not in kwargs else kwargs['filter']
        factors = self.load_code_kdata(codes=codes, filter=filter, projection=['adj_factor'],
                                       sort=[('trade_date', -1)])
        if factors is None:
            return None

        data = self.load_code_kdata(codes=codes, **kwargs)
        if data is None:
            return None

        for code, kdata in data.items():
            if kdata is None or factors['code'] is None:
                continue
            factor = factors['code']['adj_factor'][0]

            kdata['open'] = kdata['open'] * kdata['adj_factor'] / factor
            kdata['high'] = kdata['high'] * kdata['adj_factor'] / factor
            kdata['low'] = kdata['low'] * kdata['adj_factor'] / factor
            kdata['close'] = kdata['close'] * kdata['adj_factor'] / factor
            kdata['vol'] = kdata['vol'] * kdata['adj_factor'] / factor

        return data

    def load_code_kdata(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None/DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('加载日K数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])
        return self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._code_kdata_db][code],
                                   **kwargs)

    def save_code_kdata(self, data):
        """

        :param code:
        :param data: DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        :return: None/list[_id]
        """
        self.log.info('保存日K数据, count = {} ...'.format(data.shape[0]))
        rst = self._do_batch_update(coll_func=lambda client, code: client[self._code_kdata_db][code],
                                    data_frames=data,
                                    filter_func=lambda item: {'trade_date': item['trade_date']},
                                    index=[('trade_date', -1)])
        trade_date = data['trade_date'].drop_duplicates().tolist()[0]
        self.log.info('设置日K线数据保存状态, trade_date={}, count={} ...'.format(trade_date, data.shape[0]))
        self._save_sync_status(typ='code_kdata', filter={'trade_date': trade_date},
                               data={'trade_date': trade_date, 'count': data.shape[0]},
                               index=[('trade_date', -1)])

        return rst

    def load_code_daily_index(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None,DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （）
            total_amt	float	总市值 （元）
            circ_mv float	流通市值（元）])
        """
        self.log.info('加载股票每日指标, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])
        return self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._code_index_db][code],
                                   **kwargs)

    def save_code_daily_index(self, data):
        """

        :param data:
        :param kdata: DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （）
            total_amt	float	总市值 （元）
            circ_mv float	流通市值（元）])
        :return:
        """
        self.log.info('保存股票每日指标, count={}...'.format(data.shape[0]))
        rst = self._do_batch_update(coll_func=lambda client, code: client[self._code_index_db][code],
                                    data_frames=data,
                                    filter_func=lambda item: {'trade_date': item['trade_date']},
                                    index=[('trade_date', -1)])

        trade_date = data['trade_date'].drop_duplicates().tolist()[0]
        self.log.info('保存股票每日指标, trade_date={}, count={}...'.format(trade_date, data.shape[0]))
        self._save_sync_status(typ='code_index', filter={'trade_date': trade_date},
                               data={'trade_date': trade_date, 'count': data.shape[0]},
                               index=[('trade_date', -1)])

        return rst

    def load_code_adj_trans(self, codes=None, **kwargs):

        filter = None if 'filter' not in kwargs else kwargs['filter']
        factors = self.load_code_kdata(codes=codes, filter=filter, projection=['trade_date', 'adj_factor'],
                                       sort=[('trade_date', -1)])
        if factors is None:
            return None

        data = self.load_code_trans(codes=codes, **kwargs)
        if data is None:
            return None

        for code, trans in data.items():
            if trans is None or factors['code'] is None:
                continue
            trade_dates = trans['trade'].drop_duplicates().tolist()
            factor = factors['code']['adj_factor'][0]
            for trade_date in trade_dates:
                factor_df = factors['code']
                filter_factors = factor_df[factor_df['trade_date'] == trade_date]
                trans[trans['trade_date'] == trade_date]['adj_factor'] = filter_factors['adj_factor'][0]

                trans['price'] = trans['price'] * trans['adj_factor'] / factor
                trans['vol'] = trans['vol'] * trans['adj_factor'] / factor

        return data

    def load_code_trans(self, codes=None, **kwargs):
        """


        :return [{code: DataFrame}] / None

        DataFrame, DataFrame字段：
            code 股票代码
            trade_date 交易日
            time 成交时间
            price 成交价格
            vol	成交量(手)
            amount 成交额(元)
            type 性质(-1 卖盘 0 中性盘 1 买盘)
        """
        self.log.info('加载股票成交数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])

        return self._do_batch_load(codes=codes,
                                   col_func=lambda client, code: client[self._code_trans_db][code],
                                   **kwargs)

    def save_code_trans(self, data):
        """

        :param data: DataFrame, DataFrame字段：
            code 股票代码
            trade_date 交易日
            time 成交时间
            price 成交价格
            volume	成交量(手)
            amount 成交额(元)
            type 性质(-1 卖盘 0 中性盘 1 买盘)
        """
        self.log.info('保存股票成交数据, count = {} ...'.format(data.shape[0]))
        rst = self._do_batch_update(
            coll_func=lambda client, code: client[self._code_trans_db][code],
            data_frames=data,
            filter_func=lambda item: {'time': item['time'], 'trade_date': item['trade_date']},
            index=[('time', -1), ('trade_date', -1)], index_uniq=False)

        trade_date = data['trade_date'].drop_duplicates().tolist()[0]
        code = data['code'].drop_duplicates().tolist()[0]
        self.log.info('设置股票成交数据保存状态, trade_date={}, code={}, count={} ...'.format(trade_date, code, data.shape[0]))
        self._save_sync_status(typ='code_trans', filter={'trade_date': trade_date, 'code': code},
                               data={'trade_date': trade_date, 'code': code, 'count': data.shape[0]},
                               index=[('time', -1), ('trade_date', -1), ('code', 1)], index_uniq=False)

        return rst

    def load_index_list(self, **kwargs):
        """
        指数基本信息
        :return: None/DataFrame([code,name,market,category,index_type,exp_date])
        """
        self.log.info('加载大盘指数列表, kwargs={}'.format(kwargs))
        client = self._get_client()
        coll = client[self._common_db][self._index_info_col]
        return self._do_load(coll, **kwargs)

    def save_index_list(self, indexes):
        """
        :param indexes: DataFrame([code,name,market,category,index_type,exp_date])
        :return: None/list[_id]
        """
        self.log.info('保存大盘指数列表, count = {}...'.format(indexes.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._index_info_col],
                                     data_frames=indexes, filter_func=lambda item: {'code': item['code']},
                                     index=[('code', -1)])

    def load_index_k_data(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None/DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('加载大盘日k数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])
        return self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._index_kdata_db][code],
                                   **kwargs)

    def save_index_kdata(self, data):
        """

        :param data:
        :param index:  DataFrame([code,trade_date,open,high,low,close,vol,amt])
        :return:
        """
        self.log.info('保存大盘日K线数据, count = {} ...'.format(data.shape[0]))
        rst = self._do_batch_update(coll_func=lambda client, code: client[self._index_kdata_db][code],
                                    data_frames=data,
                                    filter_func=lambda item: {'trade_date': item['trade_date']},
                                    index=[('trade_date', -1)])

        # trade_date = data['trade_date'].drop_duplicates().tolist()[0]
        # self.log.info('设置大盘日K线数据保存状态, trade_date={}, count={} ...'.format(trade_date, data.shape[0]))
        # self._save_sync_status(typ='index_kdata', data={'trade_date': trade_date, 'count': data.shape[0]},
        #                        index=[('trade_date', -1)])

        return rst

    def load_trader_info(self, typ, **kwargs):
        self.log.info('加载trader数据, kwargs={}'.format(kwargs))
        if typ not in self._trader_dict:
            self.log.error('unexpect: typ={}, expect typ={}'.format(typ, self._trader_dict))
            return None
        client = self._get_client()
        coll = client[self._trader_db][self._trader_dict[typ]]
        return self._do_load(coll, **kwargs)

    def save_trader_info(self, typ, filter, data):
        self.log.info('保存trader数据, filter={}, data={}'.format(filter, data))
        if typ not in self._trader_dict:
            self.log.error('unexpect: typ={}, expect typ={}'.format(typ, self._trader_dict))
            return None
        client = self._get_client()
        coll = client[self._trader_db][self._trader_dict[typ]]
        return self._do_update(coll=coll, filter=filter, update=data)

    def load_strategy_info(self, **kwargs):
        self.log.info('加载strategy数据, kwargs={}'.format(kwargs))
        client = self._get_client()
        coll = client[self._strategy_db][self._strategy_col]
        return self._do_load(coll, **kwargs)

    def save_strategy_info(self, filter, data):
        self.log.info('保存strategy数据, filter={}, data={}'.format(filter, data))
        client = self._get_client()
        if data['status'] == 'running':
            coll = client[self._strategy_db][self._strategy_col]
            return self._do_update(coll=coll, filter=filter, update=data)

        coll = client[self._strategy_db][self._strategy_his_col]
        self._do_update(coll=coll, filter=filter, update=data)

        coll = client[self._strategy_db][self._strategy_col]
        return self._do_delete(coll=coll, filter=filter)


if __name__ == '__main__':
    from quot.quot_tushare import QuotTushare
    from quot.quot_tencent import QuotTencent
    import datetime

    tu = QuotTushare('408481e156da6a5facd695e58add4d0bf705649fe0f460d03d4d6908')
    ten = QuotTencent(None)
    mongo = SourceMongo({'uri': 'mongodb://localhost:37017/', 'pool': 5})
    mongo.init()

    # cals = tu.get_trade_cal()
    # print('tu cal:\n')
    # print(cals.head())
    # mongo.save_trade_cal(cals=cals)
    # cals = mongo.load_trade_cal(sort=[('cal_date', -1)])
    # print('mongo cal:\n')
    # print(cals.head())

    # codes = tu.get_code_list()
    # print('tu codes:\n')
    # print(codes.head())
    # mongo.save_code_list(codes=codes)
    # codes = mongo.load_code_list()
    # print('codes:\n')
    # print(codes.head())

    # kdata = tu.get_code_kdata(trade_date='20191127')
    # print('tu kdata:\n')
    # print(kdata.head())
    # mongo.save_code_kdata(kdata)
    # kdata = mongo.load_code_kdata(codes=['603116.sh'])
    # print('mongo kdata:\n')
    # for k, frame in kdata.items():
    #     print('code:%s\n', k)
    #     print(frame.head())

    # indexes = tu.get_code_daily_index(code='601099.sh', trade_date='20191127')
    # print('tu code_indexes:\n')
    # print(indexes.head())
    # mongo.save_code_daily_index(indexes)
    # indexes = mongo.load_code_daily_index(codes=['601099.sh'])
    # print('mongo index:\n')
    # for k, frame in indexes.items():
    #     print('code:%s\n', k)
    #     print(frame.head())

    trans = ten.get_code_trans(code='601099.SH', trade_date='20191127')
    print('ten trans data:\n')
    print(trans.head())
    mongo.save_code_trans(data=trans)

    trans = ten.get_code_trans(code='601099.SH', trade_date='20191224')
    print('ten trans data:\n')
    print(trans.head())
    mongo.save_code_trans(data=trans)

    trans = mongo.load_code_trans(codes=['601099.SH'],
                                  trade_dates=[datetime.datetime.strptime('20191127', '%Y%m%d'),
                                               datetime.datetime.strptime('20191224', '%Y%m%d')])
    print('mongo trans data:\n')
    for code, frame in trans.items():
        print('code:{}\n'.format(code))
        print(frame.head())

    # indexes = tu.get_index_list()
    # print('tu code_index:\n')
    # print(indexes.head())
    # mongo.save_index_list(indexes=indexes)
    # indexes = mongo.load_index_list()
    # print('indexes:\n')
    # print(indexes.head())

    # kdata = tu.get_index_kdata(code='000001.SH', trade_date='20191127')
    # print('tu index kdata:\n')
    # print(kdata.head())
    # mongo.save_index_kdata(kdata=kdata)
    # kdata = mongo.load_index_k_data(codes=['000001.SH'])
    # print('mongo index kdata:\n')
    # for k, frame in kdata.items():
    #     print('code:\n', k)
    #     print(frame.head())

    # now = datetime.now()
    # trad_date = datetime(year=now.year, month=now.month, day=now.day)
    # df = mongo.load_trade_cal(
    #     filter={
    #         'cal_date': {'$in': [trad_date, trad_date]},
    #         'is_open': 1
    #     },
    #     projection=['cal_date'],
    #     sort=[('cal_date', -1)],
    #     limit=1
    # )
    # print(df)
