from common import load_strategy
from os.path import dirname

__file_path = dirname(__file__)

quotes = load_strategy(__file_path, 'quot', ('quot.py', 'quot_barbar.py'))
