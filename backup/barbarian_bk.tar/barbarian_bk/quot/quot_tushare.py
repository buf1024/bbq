from .quot import Quot
from functools import wraps
import pandas as pd
import time
import tushare as ts
import traceback


class QuotTushare(Quot):
    def __init__(self, repo, **kwargs):
        super().__init__(repo, **kwargs)
        self.token = None if 'token' not in kwargs else kwargs['token']
        self.api = ts.pro_api(self.token)

    def _retry_client(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            for i in range(3):
                try:
                    res = func(self, *args, **kwargs)
                    return res
                except Exception as e:
                    msg = traceback.format_exc()
                    self.log.error('request %s tushare pro exception: \n%s', func.__name__, msg)
                    self.log.debug('request %s tushare pro retry 1s later.', func.__name__)
                    time.sleep(1)
            self.api = ts.pro_api(self.token)
            return None

        return wrapper

    def init(self):
        """
        初始
        :return:
        """
        return True

    def stop(self):
        return True

    def source(self):
        return 'tushare pro'

    def is_sequence(self):
        return True

    @_retry_client
    def get_trade_cal(self, **kwargs):
        """
        交易日历
        :param kwargs: start='yyyymmdd', end='yyyymmdd'
        :return: None / DataFrame[cal_date,is_open]
        """
        self.log.info('get_trade_cal请求, kwargs={}'.format(kwargs))

        start = kwargs['start'] if 'start' in kwargs else None
        end = kwargs['end'] if 'end' in kwargs else None

        df = self.api.trade_cal(exchange='', start_date=start, end_date=end, fields='cal_date,is_open')
        df['cal_date'] = pd.to_datetime(df['cal_date'], format='%Y%m%d')
        self.log.info('get_trade_cal应答 size={}'.format(df.shape[0]))
        return df

    @_retry_client
    def get_code_list(self):
        """
        股票列表
        :return: None / DataFrame[code name area industry market] market->市场类型 （主板/中小板/创业板/科创板）
        """
        self.log.info('get_code_list请求')
        df = self.api.stock_basic(list_status='L', exchange='', fields='ts_code,name,area,industry,market')
        if df is not None:
            df.rename(columns={'ts_code': 'code'}, inplace=True)
        self.log.info('get_code_list应答 size={}'.format(df.shape[0] if df is not None else 0))
        return df

    @_retry_client
    def get_code_kdata(self, **kwargs):
        """
        日K线行情
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('get_trade_cal请求, kwargs={}'.format(kwargs))

        code = kwargs['code'].upper() if ('code' in kwargs and kwargs['code'] is not None) else None
        trade_date = kwargs['trade_date'] if 'trade_date' in kwargs else None

        if code is None and trade_date is None:
            return None

        df = self.api.daily(ts_code=code, trade_date=trade_date,
                            fields='ts_code,trade_date,open,high,low,close,vol,amount')
        if df is not None:
            adjdf = self.get_code_adj_factor(code=code, trade_date=trade_date)
            if adjdf is None:
                return None
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            df['amount'] = df['amount'] * 1000
            df.rename(columns={'ts_code': 'code', 'amount': 'amt'}, inplace=True)
            df = df.merge(adjdf, left_on=['code', 'trade_date'], right_on=['code', 'trade_date'])

        self.log.info('get_code_kdata应答 size={}'.format(df.shape[0] if df is not None else 0))
        return df

    @_retry_client
    def get_code_adj_factor(self, **kwargs):
        """
        复权因子
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code, trade_date, adj_factor])
        """
        self.log.info('get_code_adj_factor请求, kwargs={}'.format(kwargs))

        code = kwargs['code'].upper() if ('code' in kwargs and kwargs['code'] is not None) else None
        trade_date = kwargs['trade_date'] if 'trade_date' in kwargs else None

        if code is None and trade_date is None:
            return None

        df = self.api.adj_factor(ts_code=code, trade_date=trade_date, fields='ts_code,trade_date,adj_factor')
        if df is not None:
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            df.rename(columns={'ts_code': 'code'}, inplace=True)

        self.log.info('get_code_adj_factor应答 size={}'.format(df.shape[0] if df is not None else 0))

        return df

    @_retry_client
    def get_code_daily_index(self, **kwargs):
        """
        每日指标
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （）
            total_amt	float	总市值 （元）
            circ_mv float	流通市值（元）])
        """
        self.log.info('get_code_daily_index请求, kwargs={}'.format(kwargs))

        code = kwargs['code'].upper() if ('code' in kwargs and kwargs['code'] is not None) else None
        trade_date = kwargs['trade_date'] if 'trade_date' in kwargs else None

        if code is None and trade_date is None:
            return None

        df = self.api.daily_basic(ts_code=code, trade_date=trade_date,
                                  fields='ts_code,trade_date,turnover_rate,volume_ratio,pe,pb,total_share,'
                                         'float_share,free_share,total_mv,circ_mv')
        if df is not None:
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            df['total_share'] = df['total_share'] * 10000
            df['float_share'] = df['float_share'] * 10000
            df['free_share'] = df['free_share'] * 10000
            df['total_mv'] = df['total_mv'] * 10000
            df['circ_mv'] = df['circ_mv'] * 10000
            df.rename(
                columns={'ts_code': 'code', 'volume_ratio': 'vol_ratio', 'total_mv': 'total_amt',
                         'circ_mv': 'circ_amt'},
                inplace=True)

        self.log.info('get_code_daily_index应答 size={}'.format(df.shape[0] if df is not None else 0))

        return df

    @_retry_client
    def get_index_list(self):
        """
        指数基本信息
        :return: None/DataFrame([code,name,market,category,index_type,exp_date])
        """
        self.log.info('get_index_list请求')

        frames = []
        markets = ['SSE', 'SZSE']
        for market in markets:
            df = self.api.index_basic(market=market, fields='ts_code,name,market,category,index_type,exp_date')
            if df is not None:
                df = df[df['exp_date'].isnull()]
                df['market'] = df['market'].str.replace('SSE', 'SH')
                df['market'] = df['market'].str.replace('SZSE', 'SZ')
                del df['exp_date']
                df.rename(columns={'ts_code': 'code'}, inplace=True)
                frames.append(df)

        df = None if len(frames) == 0 else pd.concat(frames)

        self.log.info('get_code_daily_index应答 size={}'.format(df.shape[0] if df is not None else 0))

        return df

    @_retry_client
    def get_index_kdata(self, **kwargs):
        """
        指数日线行情
        :param kwargs: code=xxx.sh end_date=xxxx
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt])
        """
        self.log.info('get_index_kdata请求, kwargs={}'.format(kwargs))

        code = kwargs['code'].upper() if ('code' in kwargs and kwargs['code'] is not None) else None
        end_date = kwargs['end_date'] if 'end_date' in kwargs else None

        if code is None or end_date is None:
            self.log.error('get_index_kdata请求, code or end_date is None')
            return None

        df = self.api.index_daily(ts_code=code, end_date=end_date,
                                  fields='ts_code,trade_date,open,high,low,close,vol,amount')
        if df is not None:
            df.dropna(inplace=True)
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            df['amount'] = df['amount'] * 1000
            df.rename(columns={'ts_code': 'code', 'amount': 'amt'}, inplace=True)

        self.log.info('get_index_kdata应答 size={}'.format(df.shape[0] if df is not None else 0))

        return df


if __name__ == '__main__':
    tu = QuotTushare('408481e156da6a5facd695e58add4d0bf705649fe0f460d03d4d6908')
    # df = tu.get_trade_cal(start='20191126', end='20191126')
    # print(df)
    df1 = tu.get_code_kdata(code='601099.sh', trade_date='20191126')
    print(df1)
    # df = tu.get_code_daily_index(code='601099.sh', trade_date='20191126')
    # print(df)
    df = tu.get_code_adj_factor(code='601099.sh', trade_date='20191126')
    print(df)
    # df = tu.get_index_list()
    # print(df.tail())
    # df = tu.get_index_k_data(code='000001.sh', trade_date='20191126')
    # print(df)
    # print(df)
