from .quot import Quot
from collections import OrderedDict
import threading


class QuotBacktest(Quot):
    def __init__(self, repo, **kwargs):
        super().__init__(repo, **kwargs)
        self.quot = OrderedDict()  # {code : [quot]}
        self.iter = {}
        self.kwargs = kwargs

        self.lock = threading.Lock()

    def source(self):
        return 'backtest'

    def setup_quot(self, codes, start_date, end_date):
        if start_date is None or end_date is None or codes is None:
            return False

        with self.lock:
            if len(self.quot) == 0:
                pre_trade_date = self.repo.db.load_trade_cal(filter={'cal_date': {'$lt': start_date}, 'is_open': 1},
                                                             projection=['cal_date'], sort=[('cal_date', -1)], limit=1)
                if pre_trade_date is None:
                    self.log.error(
                        '回测数据不全，无法做回测: pre_trade_date={} {}~{}不全'.format(pre_trade_date, start_date, end_date))
                    return False
                pre_trade_date = pre_trade_date['cal_date'].tolist()[0]
                quots = self.repo.db.load_code_trans(codes=codes,
                                                     filter={'trade_date': {'$gte': pre_trade_date, '$lte': end_date}},
                                                     projection=['price', 'vol', 'amt', 'trade_date', 'time'],
                                                     sort=[('time', 1)])

                for code, quot in quots.items():
                    if quot is None:
                        self.log.error('回测数据不全，无法做回测: code={} {}~{}不全'.format(code, start_date, end_date))
                        return False
                    if code not in self.quot:
                        self.quot[code] = []

                    name = self.repo.db.load_code_list(filter={'code': code}, projection=['name'], limit=1)
                    if name is not None:
                        name = name.loc[0, 'name']
                    quot['name'] = name

                    trade_dates = quot['trade_date'].drop_duplicates().tolist()
                    for i, trade_date in enumerate(trade_dates):
                        if i == 0:
                            continue

                        pre_close = quot[quot['trade_date'] == trade_dates[i - 1]]['price'].iloc[-1]
                        quot_trade_date = quot[quot['trade_date'] == trade_date][:]
                        quot_trade_date = quot_trade_date.reset_index(drop=True)
                        quot_trade_date['pre_close'] = pre_close
                        quot_trade_date['open'] = quot_trade_date.iloc[0]['price']

                        self.quot[code].append(quot_trade_date)
                        if code not in self.iter:
                            self.iter[code] = [0, 0]

        return True

    def get_rt_quot(self, codes=None, **kwargs):
        if codes is None:
            return None

        if len(self.quot) == 0:
            start_date = None if 'start_date' not in kwargs else kwargs['start_date']
            end_date = None if 'end_date' not in kwargs else kwargs['end_date']
            if not self.setup_quot(codes, start_date, end_date):
                return None

        quot_dict = OrderedDict()
        for code in codes:
            if code not in self.quot:
                return None

            date_index, row_index = self.iter[code][0], self.iter[code][1]
            quot_trade_date = self.quot[code][date_index]
            if row_index >= quot_trade_date.shape[0]:
                continue

            d = {}
            d['code'] = code
            d['name'] = quot_trade_date.iloc[row_index]['name']
            d['open'] = quot_trade_date.iloc[row_index]['open']
            d['pre_close'] = quot_trade_date.iloc[row_index]['pre_close']
            d['now'] = quot_trade_date.iloc[row_index]['price']
            d['buy'] = quot_trade_date.iloc[row_index]['price']
            d['sell'] = quot_trade_date.iloc[row_index]['price']
            if row_index == 0:
                quot_trade_date['high'] = 0.0
                quot_trade_date['low'] = 999999.00
                quot_trade_date['total_vol'] = 0.0
                quot_trade_date['total_amt'] = 0.0

                quot_trade_date.loc[row_index, 'high'] = quot_trade_date.iloc[row_index]['price']
                quot_trade_date.loc[row_index, 'low'] = quot_trade_date.iloc[row_index]['price']
                quot_trade_date.loc[row_index, 'total_vol'] = quot_trade_date.iloc[row_index]['vol']
                quot_trade_date.loc[row_index, 'total_amt'] = quot_trade_date.iloc[row_index]['amt']
            else:
                quot_trade_date.loc[row_index, 'high'] = max(quot_trade_date.iloc[row_index]['price'],
                                                             quot_trade_date.iloc[row_index - 1]['high'])
                quot_trade_date.loc[row_index, 'low'] = min(quot_trade_date.iloc[row_index]['price'],
                                                            quot_trade_date.iloc[row_index - 1]['low'])
                quot_trade_date.loc[row_index, 'total_amt'] = quot_trade_date.iloc[row_index - 1]['total_amt'] + \
                                                              quot_trade_date.iloc[row_index]['amt']
                quot_trade_date.loc[row_index, 'total_vol'] = quot_trade_date.iloc[row_index - 1]['total_vol'] + \
                                                              quot_trade_date.iloc[row_index - 1]['vol']

            d['high'] = quot_trade_date.loc[row_index]['high']
            d['low'] = quot_trade_date.loc[row_index]['low']
            d['amt'] = quot_trade_date.loc[row_index]['total_amt']
            d['vol'] = quot_trade_date.loc[row_index]['total_vol']

            d['bid'] = []
            d['ask'] = []
            for i in range(5, 0, -1):
                d['bid'].append(
                    (quot_trade_date.loc[row_index]['vol'], quot_trade_date.loc[row_index]['price'] - 0.01 * (i - 5)))
                d['ask'].append(
                    (quot_trade_date.loc[row_index]['vol'], quot_trade_date.loc[row_index]['price'] + 0.01 * (i - 5)))

            d['date'] = quot_trade_date.loc[row_index]['trade_date']
            d['time'] = quot_trade_date.loc[row_index]['time']

            self.iter[code][1] = row_index + 1

            quot_dict[code] = d

        return None if len(quot_dict) == 0 else quot_dict


class repos():
    def __init__(self, db):
        self.db = db


if __name__ == '__main__':
    from data.source_mongo import SourceMongo
    from datetime import datetime

    mongo = SourceMongo({'uri': 'mongodb://localhost:37017/', 'pool': 5})
    mongo.init()
    repo = repos(mongo)
    q = QuotBacktest(repo)
    quots = q.get_rt_quot(['000681.SZ'], start_date=datetime.strptime('20191225', '%Y%m%d'),
                          end_date=datetime.strptime('20191225', '%Y%m%d'))
    quots = q.get_rt_quot(['000681.SZ'], start_date=datetime.strptime('20191225', '%Y%m%d'),
                          end_date=datetime.strptime('20191225', '%Y%m%d'))

    print(quots['000001.SZ'])
