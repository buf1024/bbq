
class QuotBarbar:

    def __init__(self):
        self.attr = {}
        self.seq = {}

    def _get_item(self, item):
        if item in self.attr:
            return self.attr[item]
        return None

    def is_sequence(self, func):
        if type(func) != type(str):
            func = func.__name__
        if func not in self.seq:
            return False
        return self.seq[func]

    def __setitem__(self, key, value):
        func, seq = value
        self.attr[key] = func
        self.seq[key] = seq

    def __getitem__(self, item):
        return self._get_item(item)

    def __getattr__(self, item):
        return self._get_item(item)


if __name__ == '__main__':
    def f():
        print('function')

    def fuc(**kwargs):
        print(kwargs)

    def fuc2(**kwargs):
        print(kwargs)
        fuc(**kwargs)

    quot = QuotBarbar()

    quot['hello'] = f
    quot.hello()
    quot['hello']()

    fuc2(a='abc')

