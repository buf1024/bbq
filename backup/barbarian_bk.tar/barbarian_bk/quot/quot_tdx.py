from .quot import Quot
from pytdx.hq import TdxHq_API
from pytdx.errors import TdxFunctionCallError
from functools import wraps
from datetime import datetime
import threading
import queue
import time
import uuid
import pandas as pd


class QuotTdx(Quot, threading.Thread):
    hq_hosts = [
        # ("长城国瑞电信1", "218.85.139.19", 7709),
        # ("长城国瑞电信2", "218.85.139.20", 7709),
        ("长城国瑞网通", "58.23.131.163", 7709),
        ("上证云成都电信一", "218.6.170.47", 7709),
        ("上证云北京联通一", "123.125.108.14", 7709),
        ("上海电信主站Z1", "180.153.18.170", 7709),
        ("上海电信主站Z2", "180.153.18.171", 7709),
        ("上海电信主站Z80", "180.153.18.172", 80),
        ("北京联通主站Z1", "202.108.253.130", 7709),
        ("北京联通主站Z2", "202.108.253.131", 7709),
        ("北京联通主站Z80", "202.108.253.139", 80),
        ("杭州电信主站J1", "60.191.117.167", 7709),
        ("杭州电信主站J2", "115.238.56.198", 7709),
        ("杭州电信主站J3", "218.75.126.9", 7709),
        ("杭州电信主站J4", "115.238.90.165", 7709),
        ("杭州联通主站J1", "124.160.88.183", 7709),
        ("杭州联通主站J2", "60.12.136.250", 7709),
        ("杭州华数主站J1", "218.108.98.244", 7709),
        ("杭州华数主站J2", "218.108.47.69", 7709),
        # ("义乌移动主站J1", "223.94.89.115", 7709),
        # ("青岛联通主站W1", "218.57.11.101", 7709),
        # ("青岛电信主站W1", "58.58.33.123", 7709),
        # ("深圳电信主站Z1", "14.17.75.71", 7709),
        ("云行情上海电信Z1", "114.80.63.12", 7709),
        ("云行情上海电信Z2", "114.80.63.35", 7709),
        ("上海电信主站Z3", "180.153.39.51", 7709),
        ('招商证券深圳行情', '119.147.212.81', 7709),
        # ('华泰证券(南京电信)', '221.231.141.60', 7709),
        # ('华泰证券(上海电信)', '101.227.73.20', 7709),
        # ('华泰证券(上海电信二)', '101.227.77.254', 7709),
        ('华泰证券(深圳电信)', '14.215.128.18', 7709),
        ('华泰证券(武汉电信)', '59.173.18.140', 7709),
        # ('华泰证券(天津联通)', '60.28.23.80', 7709),
        # ('华泰证券(沈阳联通)', '218.60.29.136', 7709),
        # ('华泰证券(南京联通)', '122.192.35.44', 7709),
        # ('华泰证券(南京联通)', '122.192.35.44', 7709),
        ('安信', '112.95.140.74', 7709),
        ('安信', '112.95.140.92', 7709),
        ('安信', '112.95.140.93', 7709),
        ('安信', '114.80.149.19', 7709),
        ('安信', '114.80.149.21', 7709),
        ('安信', '114.80.149.22', 7709),
        ('安信', '114.80.149.91', 7709),
        ('安信', '114.80.149.92', 7709),
        ('安信', '121.14.104.60', 7709),
        ('安信', '121.14.104.66', 7709),
        # ('安信', '123.126.133.13', 7709),
        # ('安信', '123.126.133.14', 7709),
        # ('安信', '123.126.133.21', 7709),
        ('安信', '211.139.150.61', 7709),
        ('安信', '59.36.5.11', 7709),
        ('广发', '119.29.19.242', 7709),
        ('广发', '123.138.29.107', 7709),
        ('广发', '123.138.29.108', 7709),
        # ('广发', '124.232.142.29', 7709),
        ('广发', '183.57.72.11', 7709),
        # ('广发', '183.57.72.12', 7709),
        ('广发', '183.57.72.13', 7709),
        ('广发', '183.57.72.15', 7709),
        # ('广发', '183.57.72.21', 7709),
        ('广发', '183.57.72.22', 7709),
        ('广发', '183.57.72.23', 7709),
        ('广发', '183.57.72.24', 7709),
        ('广发', '183.60.224.177', 7709),
        ('广发', '183.60.224.178', 7709),
        # ('国泰君安', '113.105.92.100', 7709),
        # ('国泰君安', '113.105.92.101', 7709),
        # ('国泰君安', '113.105.92.102', 7709),
        # ('国泰君安', '113.105.92.103', 7709),
        # ('国泰君安', '113.105.92.104', 7709),
        # ('国泰君安', '113.105.92.99', 7709),
        ('国泰君安', '117.34.114.13', 7709),
        ('国泰君安', '117.34.114.14', 7709),
        ('国泰君安', '117.34.114.15', 7709),
        ('国泰君安', '117.34.114.16', 7709),
        ('国泰君安', '117.34.114.17', 7709),
        ('国泰君安', '117.34.114.18', 7709),
        ('国泰君安', '117.34.114.20', 7709),
        ('国泰君安', '117.34.114.27', 7709),
        ('国泰君安', '117.34.114.30', 7709),
        ('国泰君安', '117.34.114.31', 7709),
        ('国信', '182.131.3.252', 7709),
        # ('国信', '183.60.224.11', 7709),
        # ('国信', '58.210.106.91', 7709),
        ('国信', '58.63.254.216', 7709),
        ('国信', '58.63.254.219', 7709),
        ('国信', '58.63.254.247', 7709),
        ('海通', '123.125.108.90', 7709),
        ('海通', '175.6.5.153', 7709),
        ('海通', '182.118.47.151', 7709),
        ('海通', '182.131.3.245', 7709),
        ('海通', '202.100.166.27', 7709),
        ('海通', '222.161.249.156', 7709),
        # ('海通', '42.123.69.62', 7709),
        ('海通', '58.63.254.191', 7709),
        ('海通', '58.63.254.217', 7709),
        # ('华林', '120.55.172.97', 7709),
        ('华林', '139.217.20.27', 7709),
        ('华林', '202.100.166.21', 7709),
        ('华林', '202.96.138.90', 7709),
        ('华林', '218.106.92.182', 7709),
        ('华林', '218.106.92.183', 7709),
        ('华林', '220.178.55.71', 7709),
        ('华林', '220.178.55.86', 7709),
    ]

    def __init__(self, repo, **kwargs):
        threading.Thread.__init__(self)
        Quot.__init__(repo, **kwargs)

        self.queue = queue.Queue()
        self.lock = threading.Lock()
        self.init_queue = queue.Queue()

        self.clients = []

        self.hosts = [(h, p, 0) for _, h, p in self.hq_hosts]

    def run(self):
        while True:
            try:
                hosts = self.queue.get(timeout=1)
                if hosts is None:
                    return
                for host in hosts:
                    api = TdxHq_API(raise_exception=True, multithread=True, heartbeat=True)
                    try:
                        self.log.debug('connecting %s:%d', host[0], host[1])
                        retry = host[2]
                        if retry > 3:
                            self.log.debug('discard %s:%d after 3 retries', host[0], host[1])
                            continue
                        api.connect(host[0], host[1])

                        s = time.time()
                        api.get_security_count(0)
                        e = time.time()

                        with self.lock:
                            self.clients.append({'id': uuid.uuid4(), 'client': api, 'time': int(e - s),
                                                 'last': e, 'count': 1, 'host': host[0], 'port': host[1],
                                                 'retry': host[2]})
                            self.clients = sorted(self.clients, key=lambda x: (x['time'], x['last'], x['count']))
                            if self.init_queue is not None:
                                self.init_queue.put(self.clients)

                    except Exception as e:
                        try:
                            api.disconnect()
                        except:
                            pass
                        self.log.debug('connecting %s:%d timeout', host[0], host[1])
            except:
                pass

    def _best_client(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            stat_client = None
            with self.lock:
                stat_client = self.clients[0] if len(self.clients) > 0 else None

            if stat_client is None:
                return None
            try:
                kwargs['__client'] = stat_client['client'] if stat_client is not None else None
                s = time.time()
                res = func(self, *args, **kwargs)
                e = time.time()
                if stat_client is not None:
                    stat_client['time'] = int(e - s)
                    stat_client['last'] = e
                    stat_client['count'] = stat_client['count'] + 1
                    with self.lock:
                        self.clients = sorted(self.clients, key=lambda x: (x['time'], x['last'], x['count']))
                return res
            except TdxFunctionCallError as e:
                with self.lock:
                    for i, v in enumerate(self.clients):
                        if v['id'] == stat_client['id']:
                            self.queue.put([(v['host'], v['port'], v['retry'] + 1)])
                            del self.clients[i]
                            break
                raise e

        return wrapper

    def init(self):
        self.queue.put(self.hosts)
        self.start()

        try:
            clients = self.init_queue.get(timeout=60)
            with self.lock:
                self.init_queue = None

            return len(clients) > 0
        except:
            return False

    def stop(self):
        with self.lock:
            for client in self.clients:
                client['client'].disconnect()
        self.queue.put(None)

    def source(self):
        return 'tdx'

    @staticmethod
    def _market_code(code):
        market = 0 if code[-2:].upper() == 'SZ' else 1
        code = code[:-3]
        return market, code

    @_best_client
    def get_code_list(self, **kwargs):
        """
        股票列表
        :return: None / DataFrame[code name area industry market] market->市场类型 （主板/中小板/创业板/科创板）
        """
        api = kwargs['__client']
        if api is None:
            return None

        df = None
        for i in range(2):
            offset = 0
            while True:
                df2 = api.to_df(api.get_security_list(i, offset))
                if df2 is None or df2.empty:
                    break
                offset = offset + df2.shape[0]
                df2 = df2[
                    df2['code'].str.startswith('30') |
                    df2['code'].str.startswith('00') |
                    df2['code'].str.startswith('60') |
                    df2['code'].str.startswith('68')]

                if df is None:
                    df = df2
                else:
                    if df2 is not None:
                        df2['code'] = df2['code'] + '.SZ' if i == 0 else '.SH'
                        df2['area'] = ''
                        df2['industry'] = ''
                        df2['market'] = ''
                        df2 = df2[['code', 'name', 'area', 'industry', 'market']]
                        df = pd.concat([df, df2])
        return df

    @_best_client
    def get_code_kdata(self, **kwargs):
        """
        日K线行情
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        api = kwargs['__client']
        if api is None:
            return None

        code = kwargs['code'].upper() if ('code' in kwargs and kwargs['code'] is not None) else None
        trade_date = kwargs['trade_date'] if 'trade_date' in kwargs else None

        if code is None:
            return None

        df = None
        market, code = self._market_code(code)
        offset = 0
        while True:
            df2 = api.to_df(api.get_security_bars(9, market, code, offset, 800))
            if df2 is None or df2.empty:
                break

            df2['code'] = code.upper()
            df2_time = df2['year'].map(str) + '-' + df2['month'].map(str) + '-' + df2['day'].map(str)
            df2['trade_date'] = df2_time.apply(pd.to_datetime, format='%Y-%m-%d')
            df2['adj_factor'] = ''
            df2['amt'] = df2['amount']

            df2 = df2[['code', 'trade_date', 'open', 'high', 'low', 'close', 'vol', 'amt', 'adj_factor']]
            offset = offset + df2.shape[0]

            if df is None:
                df = df2
            else:
                df = pd.concat([df, df2])
        if trade_date is not None:
            df = df[df['trade_date'] == datetime.strptime(trade_date, '%Y%m%d')]
        return df

    @_best_client
    def get_code_trans(self, **kwargs):
        """
        每日成交数据
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code, trade_date,
            time	成交时间
            price	成交价格
            vol 	成交量(手)
            amt  成交额(元)
            type    性质 -> 买盘 卖盘 中性盘
        """
        api = kwargs['__client']
        if api is None:
            return None

        code = kwargs['code'].upper() if ('code' in kwargs and kwargs['code'] is not None) else None
        trade_date = kwargs['trade_date'] if 'trade_date' in kwargs else None
        if code is None or trade_date is None:
            return None

        df = None
        market, code = self._market_code(code)
        offset = 0
        while True:
            # 0 买 1 卖 2 中性
            df2 = api.to_df(api.get_history_transaction_data(market, code, offset, 800, int(trade_date)))
            if df2 is None or df2.empty:
                break

            df2['code'] = code.upper()
            df2['trade_date'] = datetime.strptime(trade_date, '%Y%m%d')
            df2['time'] = pd.to_datetime(trade_date + df2['time'], format='%Y%m%d%H:%M')
            df2['amt'] = df2['vol'] * df2['price'] * 100
            df2['type'] = df2['buyorsell'].apply(lambda x: '买盘' if x == 0 else ('卖盘' if x == 1 else '中性盘'))

            df2 = df2[['code', 'trade_date', 'time', 'price', 'vol', 'amt', 'type']]
            offset = offset + df2.shape[0]

            if df is None:
                df = df2
            else:
                df = pd.concat([df, df2])
        return df

    @_best_client
    def get_index_kdata(self, **kwargs):
        """
        指数日线行情
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt])
        """
        api = kwargs['__client']
        if api is None:
            return None

        code = kwargs['code'].upper() if ('code' in kwargs and kwargs['code'] is not None) else None
        trade_date = kwargs['trade_date'] if 'trade_date' in kwargs else None

        if code is None:
            return None

        df = None
        market, code = self._market_code(code)
        offset = 0
        while True:
            df2 = api.to_df(api.get_index_bars(9, market, code, offset, 800))
            if df2 is None or df2.empty:
                break
            df2['code'] = code.upper()
            df2_time = df2['year'].map(str) + '-' + df2['month'].map(str) + '-' + df2['day'].map(str)
            df2['trade_date'] = df2_time.apply(pd.to_datetime, format='%Y-%m-%d')
            df2['amt'] = df2['amount']

            df2 = df2[['code', 'trade_date', 'open', 'high', 'low', 'close', 'vol', 'amt']]
            offset = offset + df2.shape[0]

            if df is None:
                df = df2
            else:
                df = pd.concat([df, df2])
        if trade_date is not None:
            df = df[df['trade_date'] == datetime.strptime(trade_date, '%Y%m%d')]
        return df


if __name__ == '__main__':
    tdx = QuotTdx()
    tdx.init()
    # df = tdx.get_code_list()
    # print(df)

    # df = tdx.get_code_kdata(code='000001.sz', trade_date='20191206')
    # print(df)

    # df = tdx.get_index_kdata(code='399001.sz')
    # print(df)

    df = tdx.get_code_adj_factor(code='000001.sz', trade_date='20191129')
    print(df)
