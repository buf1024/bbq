from setuptools import find_packages, setup

print('f:{}'.format(find_packages()))

setup(
    name='barbar',
    version='1.0.0',
    packages=find_packages(include=['barbar']),
    include_package_data=True,
    zip_safe=False,
    platform="any",
    # packages=['package1', 'package2', 'package3'],
    # package_dir={
    #     'package2': 'package1',
    #     'package3': 'package1',
    # },
    install_requires=[
        'numpy',
        'pandas',
        'baostock',
        'tushare',
        'TA-Lib'
    ],
)
