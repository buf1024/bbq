from functools import wraps, partial
from collections import namedtuple
import xml.etree.ElementTree as ET
import re
import sqlparse


class SqlMapperException(Exception):
    def __init__(self, error='SqlMapperException'):
        super().__init__()
        self.error = error

    def __str__(self):
        return 'SqlMapperException: %s'.format(self.error)


class SqlMapper:
    Connection = namedtuple('Connection', ['conn', 'last', 'count', 'time', 'timeout'])

    sql_dict = dict()
    mapper = dict(default=[])

    @staticmethod
    def do_sql_mapper(op, func=None, *, sql, source='default', target):
        if func is None:
            return partial(SqlMapper.do_sql_mapper, op=op, sql=sql, source=source, target=target)
        SqlMapper.sql_dict[func.__qualname__] = sql

        @wraps(func)
        def wrapper(*args, **kwargs):
            args, kwargs = SqlMapper.format_argument(args, kwargs)

            raw_sql = SqlMapper.sql_dict[func.__qualname__]
            if raw_sql.find(r'<script>') == -1:
                obj = SqlMapper.execute_sql(op, func, source, target, *args, **kwargs)
                func(*args, **kwargs)
                return obj

            raw_sql = SqlMapper.replace_cdata(raw_sql)
            root = ET.fromstring(raw_sql)

            sql_statement, sql_args = SqlMapper.convert_element(root, *args, **kwargs)
            statement = sqlparse.format(sql_statement)

        return wrapper

    @staticmethod
    def format_argument(*args, **kwargs):
        return args, kwargs

    @staticmethod
    def execute_sql(func, source, target, *args, **kwargs):
        return 123

    @staticmethod
    def convert_element(elem, sql_arg, *args, **kwargs):
        if elem.tag == 'script':
            sql_text = SqlMapper.replace_argument(elem.text, *args, **kwargs)
            for child in list(elem):
                sql_text += SqlMapper.convert_element(child, sql_arg, *args, **kwargs)
            return sql_text

        if elem.tag == 'if':
            if 'test' not in elem.attrib:
                raise SqlMapperException('missing test attribute in test tag')
            cond = elem.attrib['test']


    @staticmethod
    def replace_argument(text, sql_arg, *args, **kwargs):
        return text

    @staticmethod
    def replace_cdata(text):
        cdata_regex = r'(<!\[CDATA\[)([\s\S]*?)(\]\]>)'
        pattern = re.compile(cdata_regex)
        match = pattern.search(text)
        if match:
            cdata_text = match.group(2)
            cdata_text = SqlMapper.convert_cdata(cdata_text, reverse=True)
            text = text.replace(match.group(), cdata_text)
        return text

    @staticmethod
    def convert_cdata(string, reverse=False):
        if reverse:
            string = string.replace('&', '&amp;')
            string = string.replace('<', '&lt;')
            string = string.replace('>', '&gt;')
            string = string.replace('"', '&quot;')

            return string

        string = string.replace('&amp;', '&')
        string = string.replace('&lt;', '<')
        string = string.replace('&gt;', '>', )
        string = string.replace('&quot;', '"')

        return string


def create_engine(uri, pool_size=5, pool_timeout=30, source='default', **kwargs):
    """dialect[+driver]://user:password@host/dbname[?key=value..]"""

    # conn,
    # SqlMapper.conn_pool[source] = name select_xx
    pass


def select(func=None, *, sql, source='default', target=dict):
    return SqlMapper.do_sql_mapper(op='select', func=func, sql=sql, source=source, target=target)


def insert(func=None, *, sql, source='default', target=int):
    return SqlMapper.do_sql_mapper(op='insert', func=func, sql=sql, source=source, target=target)


def update(func=None, *, sql, source='default', target=int):
    return SqlMapper.do_sql_mapper(op='update', func=func, sql=sql, source=source, target=target)


def delete(func=None, *, sql, source='default', target=int):
    return SqlMapper.do_sql_mapper(op='delete', func=func, sql=sql, source=source, target=target)


def transaction(func=None, *, source='default'):
    return SqlMapper.do_sql_mapper(op='transaction', func=func, sql=None, source=source, target=None)


@insert(sql=r"<script>"
            r"select * from abc "
            r'where 1=1'
            r' <if "name is not null and a.value == ">and x = ?</if> '
            r'</script>')
def select_xx(a, **kw):
    pass


class Dao:
    @staticmethod
    @select(sql="<script>select * from </script>")
    def select_yy():
        print('select_yy')


class Service:
    @staticmethod
    @transaction
    def save_xx():
        Dao.select_yy()
        print('transaction')
        select_xx(a=2, b=3)


if __name__ == '__main__':
    select_xx(a=1, b=2)
    Dao.select_yy()

    Service.save_xx()
