from barbarian.fund.strategy import Strategy
from collections import defaultdict


class FollowRise(Strategy):
    name = '通用属性'
    desc = '通用属性'

    def __init__(self, db):
        super().__init__(db)
        self.cond = dict(days=15, up_ratio=0.6, down_min=-0.01, down_max=-4, up_min=0.5, up_max=10)

        self.filter = None

    async def init(self, **kwargs):
        """
        days: 10
        up_ratio: 0.7
        down_min = -0.01
        down_max = -2
        up_min = 1.5
        up_max = 10
        :param kwargs:
        :return:
        """

        if 'days' in kwargs:
            self.cond['days'] = kwargs['days']
        if 'up_ratio' in kwargs:
            self.cond['up_ratio'] = kwargs['up_ratio']
        if 'down_max' in kwargs:
            self.cond['down_max'] = kwargs['down_max']
        if 'up_max' in kwargs:
            self.cond['up_max'] = kwargs['up_max']
        if 'down_min' in kwargs:
            self.cond['down_min'] = kwargs['down_min']
        if 'up_min' in kwargs:
            self.cond['up_min'] = kwargs['up_min']

        codes = await self.db.load_fund_list(projection=['code'], limit=1)
        if codes is None:
            return False

        code = codes['code'][0]

        dates = await self.db.load_fund_net(codes=[code], projection=['date'], sort=[('date', -1)],
                                            limit=self.cond['days'])
        dates = dates[code]
        date_min = dates.iloc[-1]['date']

        self.filter = {'date': {'$gte': date_min}}

        self.log.debug('cond={}, filter={}'.format(self.cond, self.filter))

        return True

    async def run(self):
        def apply_func(v, **kwargs):
            d = kwargs['coll']
            d['up'] += 0 if v <= 0 else 1
            d['down'] += 1 if v <= 0 else 0

            if v > d['up_max']:
                d['up_max'] = v

            if v < d['down_max']:
                d['down_max'] = v

            if v > 0:
                if d['up_min'] == 0:
                    d['up_min'] = v
                else:
                    if v < d['up_min']:
                        d['up_min'] = v

            if v <= 0:
                if d['down_min'] == 0:
                    d['down_min'] = v
                else:
                    if v > d['down_min']:
                        d['down_min'] = v

        results = {}

        fund_nets = await self.db.load_fund_net(filter=self.filter)
        self.log.debug('开始计算：{}个基金'.format(len(fund_nets)))
        for code, net in fund_nets.items():
            if net is None:
                continue

            coll = defaultdict(int)
            net['day_grow_rate'].apply(apply_func, coll=coll)

            if coll['up_max'] > self.cond['up_max']:
                continue

            if coll['up_min'] < self.cond['up_min']:
                continue

            if coll['down_max'] < self.cond['down_max']:
                continue

            if coll['down_min'] > self.cond['down_min']:
                continue

            if coll['up'] / (coll['up'] + coll['down']) < self.cond['up_ratio']:
                continue

            coll['code'] = net['code'][0]
            coll['short_name'] = net['short_name'][0]
            result = {'context': coll, 'net': net}
            results[code] = result

            self.log.debug('发现符合条件基金：{}({})'.format(coll['short_name'], code))

        return results


if __name__ == '__main__':
    from barbarian.util import run_until_complete
    from barbarian.fund import FundDB
    import sys

    mongo = FundDB()
    js = {'uri': 'mongodb://localhost:47017/', 'pool': 5}
    if not mongo.init(js):
        print('连接数据库失败: js={}'.format(js))
        sys.exit(-1)


    async def run():
        s = FollowRise(mongo)
        if not await s.init():
            return False
        results = await s.run()
        print(results)


    run_until_complete(run())
