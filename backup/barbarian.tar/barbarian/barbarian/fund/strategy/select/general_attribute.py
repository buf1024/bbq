from barbarian.fund.strategy import Strategy
from collections import OrderedDict
from functools import partial


class GeneralAttribute(Strategy):
    name = '通用属性'
    desc = '通用属性'

    def __init__(self, db):
        super().__init__(db)
        self.cond = OrderedDict(
            plate=dict(cond=None, func=None),
            info=dict(cond={'scale': {'$gte': 10}, 'rise_1m': {'$gte': 10}}, func=None),
            net=dict(cond=None, func=None))

    async def init(self, **kwargs):
        """
        plate: cond: ''
               func: None
        info: cond: ''
              func: None
        net: cond: ''
             func : [(avg ) ()] => (属性名 函数参数)
              函数: avg （最小值 最大值）
                   ratio (最小值 最大值 涨比率)
        :param kwargs:
        :return:
        """

        def extract_args(key):
            if key in kwargs:
                if 'cond' in kwargs[key]:
                    self.cond[key]['cond'] = kwargs[key]['cond']
                if 'func' in kwargs[key]:
                    self.cond[key]['func'] = kwargs[key]['func']

        extract_args('plate')
        extract_args('info')
        extract_args('net')

        return True

    async def run(self):
        frame_dict = dict(plate=None, info=None, net=None)
        func_dict = dict(plate=self.db.load_plate_list, info=self.db.load_fund_list,
                         net=partial(self.db.load_fund_net, codes=None))
        fund_codes = set([])
        for key, val in self.cond.items():
            fr, cond, func = None, val['cond'], val['func']
            if cond is not None:
                fr = await func_dict[key](filter=cond)
            if func is not None and fr is not None:
                fr = self.apply(fr, func)
            frame_dict[key] = fr
            codes = None
            if fr is not None:
                if key == 'plate':
                    codes = fr['codes'].tolist()
                    if len(codes) > 0:
                        codes = codes[0].split(',')
                if key == 'info' or key == 'net':
                    codes = fr['code'].tolist()
            if codes is not None:
                if len(fund_codes) == 0:
                    fund_codes = set(codes)
                else:
                    fund_codes = fund_codes.intersection(set(codes))

        if len(fund_codes) > 0:
            return await self.db.load_fund_list(filter={'code': {'$in': list(fund_codes)}},
                                                sort=[('rise_1m', -1)], limit=50)

        return None

    def apply(self, frame, func):
        return frame


if __name__ == '__main__':
    from barbarian.util import run_until_complete
    from barbarian.fund import FundDB
    import sys

    mongo = FundDB()
    js = {'uri': 'mongodb://localhost:47017/', 'pool': 5}
    if not mongo.init(js):
        print('连接数据库失败: js={}'.format(js))
        sys.exit(-1)

    async def run():
        s = GeneralAttribute(mongo)
        if not await s.init():
            return False
        results = await s.run()
        print(results)

    run_until_complete(run())
