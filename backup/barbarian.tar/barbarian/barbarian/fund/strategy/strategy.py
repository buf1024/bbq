from barbarian import log


class Strategy:
    name = None
    desc = None

    def __init__(self, db):
        self.log = log.get_logger(self.__class__.__name__)
        self.db = db

    async def init(self, **kwargs):
        return True

    async def run(self):
        pass

