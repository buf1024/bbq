from collections import OrderedDict
from barbarian.mongodb import MongoDB


class FundDB(MongoDB):
    _fund_db = 'fund_db'  # 通用数据库
    _fund_info_col = 'fund_info_col'  # 基金信息
    _fund_plate_col = 'fund_plate_col'  # 基金板块信息

    _fund_net_db = 'fund_net_db'  # 基金净值数据库

    def __init__(self, uri='mongodb://localhost:27017/', pool=5):
        super().__init__(uri, pool)

    @property
    def fund_db(self):
        return self._fund_db

    @property
    def fund_info_col(self):
        return self._fund_info_col

    @property
    def fund_plate_col(self):
        return self._fund_plate_col

    @property
    def fund_net_db(self):
        return self._fund_net_db

    async def build_fund_index(self):
        self.log.info('创建索引: db={}, col={}'.format(self._fund_db, self._fund_info_col))
        await self.build_index(self._fund_db, self._fund_info_col, index=[('code', -1)])

        self.log.info('创建索引: db={}, col={}'.format(self._fund_db, self._fund_info_col))
        await self.build_index(self._fund_db, self._fund_plate_col, index=[('plate', -1), ('name', -1)])

        codes = await self.load_fund_list(projection=['code'])
        if codes is None:
            self.log.warning('基金列表为空，无法创建索引')
        else:
            for _, code in codes.iterrows():
                self.log.info('创建索引: db={}, col={}'.format(self._fund_net_db, code['code']))
                await self.build_index(self._fund_net_db, code['code'], index=[('date', -1)],
                                       index_uniq=False)

        self.log.info('创建索引完成')

    async def _do_batch_load(self, codes, col_func, **kwargs):
        d = OrderedDict()
        for code in codes:
            coll = col_func(self.get_client(), code)
            df = await self.do_load(coll, **kwargs)
            d[code] = df
        return None if len(d) == 0 else d

    async def _do_batch_update(self, coll_func, data_frames, filter_func=None):
        upsert_list = []
        for item in data_frames.to_dict('records'):
            coll = coll_func(self.get_client(), item['code'].upper() if 'code' in item else None)
            filter = None if filter_func is None else filter_func(item)
            upsert = await self.do_update(coll, filter=filter, update=item)
            if upsert is None:
                continue
            if isinstance(upsert, list):
                upsert_list = upsert_list + upsert
            else:
                upsert_list.append(upsert)
        return upsert_list if len(upsert_list) > 0 else None

    async def load_plate_list(self, **kwargs):
        self.log.info('加载基金板块列表, kwargs={}'.format(kwargs))
        client = self.get_client()
        coll = client[self._fund_db][self._fund_plate_col]
        return await self.do_load(coll, **kwargs)

    async def save_plate_list(self, funds):
        self.log.info('保存基金板块列表, count = {}'.format(funds.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, _: client[self._fund_db][self._fund_plate_col],
                                           data_frames=funds, filter_func=lambda item: {'plate': item['plate'],
                                                                                        'name': item['name']})

    async def load_fund_list(self, **kwargs):
        self.log.info('加载基金列表, kwargs={}'.format(kwargs))
        client = self.get_client()
        coll = client[self._fund_db][self._fund_info_col]
        return await self.do_load(coll, **kwargs)

    async def save_fund_list(self, funds):
        self.log.info('保存基金列表, count = {}'.format(funds.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, _: client[self._fund_db][self._fund_info_col],
                                           data_frames=funds, filter_func=lambda item: {'code': item['code']})

    async def load_fund_net(self, codes=None, **kwargs):
        self.log.info('加载基金净值数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = await self.load_fund_list(projection=['code'])
            codes = codes['code']
        return await self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._fund_net_db][code],
                                         **kwargs)

    async def save_fund_net(self, data):
        self.log.info('保存基金净值数据, count = {} ...'.format(data.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, code: client[self._fund_net_db][code],
                                           data_frames=data,
                                           filter_func=lambda item: {'date': item['date']})


if __name__ == '__main__':
    from barbarian.fund.fund_eastmoney import FundEastmoney
    from barbarian.util import run_until_complete


    async def test_fund_info(db, east):
        df = await east.get_fund_info(code='160220')
        if df is not None:
            print('test_fund_info web:\n', df)
            await db.save_fund_list(df)

            df = await db.load_fund_list(filter={'code': '160220'})
            print('test_fund_info db:\n', df)


    async def test_fund_net(db, east):
        df = await east.get_fund_net(code='160220')
        if df is not None:
            print('test_fund_net web:\n')
            print(df.head())
            await db.save_fund_net(df)

            df = await db.load_fund_net(codes=['160220'])
            print('test_fund_net db:\n')
            print(df['160220'].head())


    async def test_fund_net2(db, east):
        df = await db.load_fund_net(codes=['160220'])
        print(df)


    async def test_build_index(db, east):
        await db.build_index()
        print('done')


    mongo = FundDB()
    mongo.init({'uri': 'mongodb://localhost:47017/'})

    fund = FundEastmoney()

    run_until_complete(
        # test_fund_info(mongo, fund),
        # test_fund_net(mongo, fund),
        test_fund_net2(mongo, fund),
        # test_build_index(mongo, fund)
    )
