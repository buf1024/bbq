from barbarian import log
import asyncio
from datetime import datetime, timedelta
import traceback


class FundSync:
    concurrent_count = 80

    def __init__(self, db, fund):
        self.log = log.get_logger(FundSync.__name__)
        self.db = db
        self.fund = fund

    def filter_type(self, typ):
        # "ETF-场内",
        # "QDII",
        # "QDII-ETF",
        # "QDII-指数",
        # "债券型",
        # "债券指数",
        # "分级杠杆",
        # "固定收益",
        # "定开债券",
        # "混合-FOF",
        # "混合型",
        # "理财型",
        # "联接基金",
        # "股票型",
        # "股票指数",
        # "货币型"
        # return False if typ in ['QDII', 'QDII-ETF', 'QDII-指数', '债券型', '债券指数', '固定收益', '定开债券',
        #                         '理财型', '货币型'] else True
        return False if typ in ['QDII', 'QDII-ETF', 'QDII-指数', '债券型', '债券指数', '定开债券',
                                 '理财型', '货币型'] else True

    async def sync_task_full(self, code, queue):
        try:
            self.log.debug('全量同步基金信息: {}'.format(code))

            fund_info = await self.fund.get_fund_info(code=code)
            await self.db.save_fund_list(fund_info)

            net_info = await self.fund.get_fund_net(code=code)
            if net_info is not None:
                net_info['short_name'] = fund_info['short_name'][0]
                await self.db.save_fund_net(net_info)

        except Exception as e:
            self.log.error('同步基金信息失败: code={} ex={} stack={}'.format(code, e, traceback.format_exc()))
        finally:
            await queue.get()
            queue.task_done()

    async def sync_task_increment(self, code, queue):
        try:
            self.log.debug('增量同步基金信息: {}'.format(code))
            # fund_info = await self.db.load_fund_list(filter={'code': code})
            # if fund_info is None:
            #     fund_info = await self.fund.get_fund_info(code=code)
            #     await self.db.save_fund_list(fund_info)
            fund_info = await self.fund.get_fund_info(code=code)
            await self.db.save_fund_list(fund_info)

            net_info = await self.db.load_fund_net(codes=[code], projection=['code', 'date'], sort=[('date', -1)],
                                                   limit=1)
            net_info = net_info[code]
            if net_info is None:
                net_info = await self.fund.get_fund_net(code=code)
                if net_info is not None:
                    net_info['short_name'] = fund_info['short_name'][0]
                    await self.db.save_fund_net(net_info)
            else:
                last = net_info.loc[0, 'date']
                now = datetime.now()

                delta = now - last
                if delta.days > 1:
                    start_date = datetime.strptime(last.strftime('%Y%m%d'), '%Y%m%d') + timedelta(days=1)
                    end_date = datetime.strptime(now.strftime('%Y%m%d'), '%Y%m%d')
                    net_info = await self.fund.get_fund_net(code=code, start_date=start_date, end_date=end_date)
                    if net_info is not None:
                        net_info['short_name'] = fund_info['short_name'][0]
                        await self.db.save_fund_net(net_info)
        except Exception as e:
            self.log.error('同步基金信息失败: code={} ex={} stack={}'.format(code, e, traceback.format_exc()))
        finally:
            await queue.get()
            queue.task_done()

    async def sync(self, is_full=False, plate_full=False):
        try:
            self.log.info('获取基金列表...')
            funds = await self.fund.get_fund_list(fields='code,type')

            queue = asyncio.Queue(self.concurrent_count)
            loop = asyncio.get_event_loop()
            for _, fund in funds.iterrows():
                code, typ = fund['code'], fund['type']
                if not self.filter_type(typ):
                    self.log.debug('忽略基金类型: {}, {}'.format(code, typ))
                    continue
                await queue.put(code)
                coro = self.sync_task_full(code=fund['code'], queue=queue) if is_full else \
                    self.sync_task_increment(code=fund['code'], queue=queue)
                loop.create_task(coro)
            await queue.join()

            self.log.info('同步板块列表...')
            funds = await self.fund.get_plate_list(sync_fund=plate_full)
            await self.db.save_plate_list(funds)

            # await self.db.build_fund_index()
            self.log.info('基金信息同步完成')
        except Exception as e:
            self.log.error('同步基金失败: ex={}, stack={}'.format(e, traceback.format_exc()))


if __name__ == '__main__':
    from barbarian.util import run_until_complete
    from barbarian.fund.fund_db import FundDB
    from barbarian.fund.fund_eastmoney import FundEastmoney
    import sys
    import os
    import argparse

    args = None
    try:
        parser = argparse.ArgumentParser(description='barbarian fund data sync process')
        parser.add_argument('-u', '--uri', type=str, nargs='?', default='mongodb://localhost:47017/',
                            help='mongodb uri address')
        parser.add_argument('-p', '--pool', type=int, default=5, help='mongodb pool size')
        parser.add_argument('-f', '--sync_full', type=bool, nargs='?', const=True, default=False, help='full sync tag')
        parser.add_argument('-l', '--sync_plate', type=bool, nargs='?', const=True, default=False,
                            help='plate sync tag')
        args = parser.parse_args()
    except SystemExit as e:
        os._exit(0)

    mongo = FundDB()
    js = {'uri': args.uri, 'pool': args.pool}
    if not mongo.init(js):
        print('连接数据库失败: js={}'.format(js))
        sys.exit(-1)

    fund = FundEastmoney()

    fund_sync = FundSync(mongo, fund)
    run_until_complete(fund_sync.sync(is_full=args.sync_full, plate_full=args.sync_plate))
