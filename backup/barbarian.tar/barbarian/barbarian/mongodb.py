from functools import wraps
from collections import namedtuple
import motor.motor_asyncio
import time
import traceback
import pandas as pd
from barbarian import log
from abc import ABC


class MongoDB(ABC):
    _MongoStat = namedtuple('_MongoStat', ['client', 'count', 'last'])

    def __init__(self, uri='mongodb://localhost:27017/', pool=5):
        self.log = log.get_logger(self.__class__.__name__)
        self.clients = []

        self.uri = uri
        self.pool = pool

    def _best_client(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            self.clients = sorted(self.clients, key=lambda stat: (stat.count, -stat.last))
            stat_client = self.clients[0]
            self.clients[0] = stat_client._replace(count=stat_client.count + 1, last=time.time())

            kwargs['__client'] = stat_client.client
            return func(self, *args, **kwargs)

        return wrapper

    def init(self, js=None):
        try:
            self.uri = js['uri'] if (js is not None and 'uri' in js) else self.uri
            pool = js['pool'] if js is not None and 'pool' in js else self.pool
            self.pool = pool if pool > 0 else 1
            for _ in range(self.pool):
                client = motor.motor_asyncio.AsyncIOMotorClient(self.uri)
                self.clients.append(self._MongoStat(client=client, count=0, last=time.time()))
        except Exception as e:
            self.log.error('连接mongodb失败: uri={}, ex={}'.format(self.uri, e))
            return False

        return True

    async def build_index(self, db, col, index, index_uniq=True):
        try:
            client = self.get_client()
            if client is None:
                raise Exception('mongodb未连接')

            await client[db][col].create_index(index, unique=index_uniq)
        except Exception as e:
            self.log.error('创建index异常{}\n db={} col={} call stack: {}'.format(e, db, col, traceback.format_exc()))

    @_best_client
    def get_client(self, **kwargs):
        return kwargs['__client'] if '__client' in kwargs else None

    async def do_load(self, coll, filter=None, projection=None, skip=0, limit=0, sort=None, to_frame=True):
        try:
            cursor = coll.find(filter=filter, projection=projection, skip=skip, limit=limit, sort=sort)
            if cursor is not None:
                # data = [await item async for item in cursor]
                data = await cursor.to_list(None)
                cursor.close()
                if to_frame:
                    df = pd.DataFrame(data=data, columns=projection)
                    return None if df.empty else df
                else:
                    return data
            return None
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self.do_load.__name__, traceback.format_exc())

    async def do_update(self, coll, filter=None, update=None):
        try:
            if update is None:
                return None
            res = await coll.update_one(filter, {'$set': update}, upsert=True)
            return res.upserted_id
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self.do_update.__name__, traceback.format_exc())

    async def _do_delete(self, coll, filter=None, just_one=True):
        try:
            res = await coll.remove(filter, {'justOne': just_one})
            return res.upserted_id
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self._do_delete.__name__, traceback.format_exc())
