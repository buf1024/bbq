import uuid
from datetime import datetime


class DealHis:
    def __init__(self, db):
        self.db = db
        self.id = uuid.uuid4()
        self.entrust_id = None
        self.broker_id = None
        self.type = None  # buy, sell
        self.name = None
        self.code = None

        self.time = datetime.now()

        self.price = None
        self.volume = None

    def from_json(self, js):
        pass

    def to_json(self):
        pass
