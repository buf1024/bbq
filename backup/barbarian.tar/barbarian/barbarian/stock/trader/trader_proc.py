import sys
import json
import traceback
import uuid
from unused import proto
from unused.async_nats import AsyncNats

from barbarian.stock import SourceMongo

from barbarian.stock import brokers


class Trader(AsyncNats):
    def __init__(self, topic, options):
        super().__init__()
        self.status = 'created'
        self.topic = topic
        self.options = json.loads(options)
        self.db = None

        self.broker = None
        self.strategy = None
        self.account = None
        self.risk = None

        self.handlers = {
            'status_query': self.on_status_query,
            'quot': self.on_quot,
            'open': self.on_open,
            'close': self.on_close,
            'done': self.on_done,
        }

    def init_trader(self):
        self.db = SourceMongo()
        if not self.db.init(self.options['db']):
            return False

        try:
            broker_js = self.options['broker']
            broker = brokers[broker_js['name']](self.db)
            if not broker.from_json(broker_js):
                self.log.error('init broker from_json failed')
                return False

            self.broker = broker
            self.risk = broker.risk
            self.strategy = broker.strategy
            self.account = broker.account

            if self.strategy is None or self.account is None:
                self.log.error('init broker strategy or account is null')
                return False

            self.status = 'inited'
        except Exception as e:
            self.log.error('init_trader exception: exception={}, call_stack={}'.format(e, traceback.format_exc()))
            return False
        return True

    async def do_update_codes(self):
        payload = {
            'id': str(uuid.uuid4()),
            'cat': 'trade',
            'cmd': 'update_codes',
            'options': {
                'codes': self.strategy.codes,
                'quot': self.options['quot']
            }
        }
        payload = json.dumps(payload)
        self.log.info('publish subject={}, payload={}'.format(self.topic, payload))
        await self.nc.publish(self.topic, payload.encode())
        await self.nc.flush()

    async def do_status_report(self):
        payload = {
            'id': str(uuid.uuid4()),
            'cat': 'trade',
            'cmd': 'status_report',
            'options': {
                'status': self.status
            }
        }
        payload = json.dumps(payload)
        self.log.info('publish subject={}, payload={}'.format(self.topic, payload))
        await self.nc.publish(self.topic, payload.encode())
        await self.nc.flush()

    async def on_nats_connected(self):
        self.log.info('nats connected, listen subject: {}'.format(self.topic))

        await self.do_status_report()
        if not self.init_trader():
            self.status = 'died'
            await self.do_status_report()
            self.on_signal()
            return
        await self.do_status_report()
        await self.subscribe(self.topic)
        if self.strategy is not None and len(self.strategy.codes) > 0:
            await self.do_update_codes()

    async def on_nats_message(self, msg):
        subject, reply, data = msg.subject, msg.reply, msg.data.decode()
        self.log.info("Received a message on '{subject}': {data}".format(
            subject=subject, reply=reply, data=data))

        if subject == self.topic:
            await self.on_command(subject=subject, reply=reply, data=data)

    async def on_command(self, subject, reply, data):
        resp = proto.response(sid='', cmd='', cat='', status='ERR', msg='')
        try:
            data_dict = json.loads(data)
            sid, cmd, cat, options = data_dict['id'], data_dict['cmd'], data_dict['cat'], data_dict[
                'options'] if 'options' in data_dict else None
            status, msg, options = await self.handlers[cmd](options)
            resp = proto.response(sid, cat, cmd, status, msg, options)
        except Exception as e:
            self.log.error('execute command failed: subject={}, data={} call_stack={}'.format(subject, data,
                                                                                              traceback.format_exc()))
            resp['msg'] = 'exception: {}'.format(e)
        finally:
            if reply != '':
                js_resp = json.dumps(resp)
                self.log.info("Response a message: '{data}'".format(data=js_resp))
                await self.nc.publish(subject=reply, payload=js_resp.encode())

    async def on_status_query(self, options):
        return 'OK', '', {'status': self.status}

    async def on_quot(self, options):
        self.log.info('on_quot: {}'.format(options))
        if self.broker.on_quot(payload=options['quot']):
            return 'OK', 'SUCCESS', None

        return 'ERR', 'FAILED', None

    async def on_open(self, options):
        self.log.info('on_open: {}'.format(options))
        if self.broker.on_open(payload=dict(period=options['period'], trade_date=options['trade_date'])):
            return 'OK', 'SUCCESS', None

        return 'ERR', 'FAILED', None

    async def on_close(self, options):
        self.log.info('on_close: {}'.format(options))
        if self.broker.on_close(payload=dict(period=options['period'], trade_date=options['trade_date'])):
            return 'OK', 'SUCCESS', None

        return 'ERR', 'FAILED', None

    async def on_done(self, options):
        self.log.info('on done')
        self.broker.on_done()
        self.status = 'died'
        await self.do_status_report()
        self.on_signal()
        return 'ERR', 'FAILED', None


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print('usage: python trade_proc.py subject options')
        sys.exit(-1)
    subject, opts = sys.argv[1], sys.argv[2]

    trader = Trader(subject, opts)
    trader.start()
