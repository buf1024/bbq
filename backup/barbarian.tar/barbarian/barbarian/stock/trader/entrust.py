import uuid
import json
from datetime import datetime


class Entrust:
    def __init__(self, db):
        self.db = db
        self.id = str(uuid.uuid4())
        self.broker_id = None
        self.action = None  # buy, sell
        self.status = 'commit'  # commit half_deal, deal cancel
        self.name = None
        self.code = None

        self.time = None

        self.price = None
        self.volume = None
        self.volume_deal = 0
        self.volume_cancel = 0

    def from_json(self, js):
        self.id = js['id'] if 'id' in js else str(uuid.uuid4())
        self.broker_id = js['broker_id'] if 'broker_id' in js else ''
        self.action, self.status = js['action'], js['status']

        self.name, self.code, self.price, self.time = js['name'], js['code'], js['price'], js['time']
        self.volume, self.volume_deal, self.volume_cancel = js['volume'], js['volume_deal'], js['volume_cancel']

        return True

    def to_json(self):
        js_dict = dict(id=self.id, broker_id=self.broker_id, action=self.action, status=self.status,
                       name=self.name, code=self.code, time=self.time,price=self.price,
                       volume=self.volume, volume_deal=self.volume_deal, volume_cancel=self.volume_cancel)
        return json.dumps(js_dict)

    def __str__(self):
        return self.to_json()




