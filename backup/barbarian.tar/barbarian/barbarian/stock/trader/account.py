from barbarian import log
from barbarian.stock import Position
from barbarian.stock import Entrust
from barbarian.stock import DealHis


class Account:
    def __init__(self, db, broker):
        self.log = log.get_logger(self.__class__.__name__)
        self.db = db
        self.broker = broker
        self.cash_init = 0
        self.cash_available = 0
        self.cash_freeze = 0

        self.broker_fee = 0.0003

        self.cost = 0
        self.profit = 0
        self.profit_rate = 0

        self.position = {}
        self.entrust = []
        self.deal_his = []

    def from_json(self, js):
        self.cash_init = js['cash_init'] if 'cash_init' in js else 0
        self.cash_available = js['cash_available'] if 'cash_available' in js else 0
        self.cash_freeze = js['cash_freeze'] if 'cash_freeze' in js else 0
        self.broker_fee = js['broker_fee'] if 'broker_fee' in js else 0.0003
        self.cost = js['cost'] if 'cost' in js else 0
        self.profit = js['profit'] if 'profit' in js else 0
        self.profit_rate = js['profit_rate'] if 'profit_rate' in js else 0

        poss_js = js['position'] if 'position' in js else None
        if poss_js is not None and isinstance(poss_js, list):
            for pos_js in poss_js:
                pos = Position(self.db)
                if not pos.from_json(pos_js):
                    self.log.error('position from json failed: js={}'.format(pos_js))
                    return False

                if len(pos.code) > 0:
                    self.position[pos.code] = pos

        entrusts_js = js['entrust'] if 'entrust' in js else None
        if entrusts_js is not None and isinstance(entrusts_js, list):
            for entrust_js in entrusts_js:
                entrust = Entrust(self.db)
                if not entrust.from_json(entrust_js):
                    self.log.error('entrust from json failed: js={}'.format(entrust_js))
                    return False

                if len(entrust.code) > 0:
                    self.entrust.append(entrust)

        deals_js = js['deal_his'] if 'deal_his' in js else None
        if deals_js is not None and isinstance(deals_js, list):
            for deal_js in deals_js:
                deal = DealHis(self.db)
                if not deal.from_json(deal_js):
                    self.log.error('deal from json failed: js={}'.format(deal_js))
                    return False

                if len(deal.code) > 0:
                    self.deal_his.append(deal)

        return True

    def to_json(self):
        pass

    def _update_position_quot(self, code, quot):
        self.position[code].on_quot(quot)
        self.profit += self.position[code].profit
        self.cost += (self.position[code].cost * self.position[code].volume)

    def _update_position_openclose(self):
        for pos in self.position.values():
            pos.volume_available = pos.volume

        for entrust in self.entrust:
            entrust.status = 'cancel'
            entrust.volume_cancel = entrust.volume - entrust.volume_deal

        self.cash_available += self.cash_freeze

    def on_entrust_done(self, entrust, broker_id=None, volume=None):
        # if entrust.action == 'cancel':
        #     vol = entrust.volume - entrust.volume_deal
        #     # 中间费用不退了
        #     cost = vol * entrust.price
        #
        #     self.cash_freeze -= cost
        #     self.cash_available += cost
        #     return True
        volume = volume if volume is not None else entrust.volume

        deal = DealHis(self.db)
        deal.entrust_id = entrust.id
        deal.broker_id = broker_id
        deal.type = entrust.action
        deal.name = entrust.name
        deal.code = entrust.code
        deal.price = entrust.price
        deal.volume = volume

        stock_fee = round(volume * entrust.price, 2)
        broker_fee = self.broker_fee * stock_fee
        broker_fee = round(broker_fee, 2)
        if broker_fee <= 5.0:
            broker_fee = 5.0
        transfer_fee = int(volume / 1000)
        transfer_fee = round(transfer_fee, 2)
        if transfer_fee <= 0.0:
            transfer_fee = 1.0

        if entrust.action == 'buy':
            total = broker_fee + transfer_fee + stock_fee
            self.log.debug(
                '买入成交费用: total={}, stock={}, broker={}, transfer={}'.format(total, stock_fee, broker_fee,
                                                                            transfer_fee))

            entrust.volume_deal = volume
            entrust.status = 'deal' if entrust.volume == entrust.volume_deal else 'half_deal'

            position = None
            if entrust.code in self.position:
                position = self.position[entrust.code]

            if position is None:
                position = Position(self.db)
                position.name = entrust.name
                position.code = entrust.code

            position.add_position(total, entrust.price, volume)
            self.cash_freeze -= total
            self.deal_his.append(deal)
            self.position[position.code] = position
            return True

        if entrust.action == 'sell':
            tax_fee = stock_fee * 0.001
            cost = broker_fee + transfer_fee + tax_fee
            total = stock_fee - cost
            self.log.debug('卖出成交费用: total={}, stock={}, broker={}, transfer={}, tax={}'.format(total,
                                                                                               stock_fee, broker_fee,
                                                                                               transfer_fee,
                                                                                               tax_fee))
            position = None
            if entrust.code in self.position:
                position = self.position[entrust.code]
            if position is None:
                self.log.error('系统错误: 卖出成交异常，无持仓数据: position={}, entrust={}'.format(position, entrust))
                return False
            position.reduce_position(total, entrust.price, volume)
            self.deal_his.append(deal)
            self.cash_available += total
            return True

        return False

    def _handle_entrust(self, entrust, position):
        if entrust.action == 'buy':
            stock_fee = entrust.volume * entrust.price
            stock_fee = round(stock_fee, 2)
            broker_fee = self.broker_fee * stock_fee
            broker_fee = round(broker_fee, 2)
            if broker_fee <= 5.0:
                broker_fee = 5.0
            transfer_fee = int(entrust.volume / 1000)
            transfer_fee = round(transfer_fee, 2)
            if transfer_fee <= 0.0:
                transfer_fee = 1.0

            cost = broker_fee + transfer_fee + stock_fee
            cost = round(cost, 2)
            self.log.debug(
                '买入费用: total={}, stock={}, broker={}, transfer={}'.format(cost, stock_fee, broker_fee,
                                                                          transfer_fee))
            if self.cash_available < cost:
                self.log.error('余额不足: cash_available={}, cost={}'.format(self.cash_available, cost))
                return False
            self.cash_available -= cost
            self.cash_freeze += cost
            return True

        if entrust.action == 'sell':
            if position.volume_available < entrust.volume:
                return False
            position.volume_available -= entrust.volume
            return True

        return False

    def on_open(self, payload):
        if payload['period'] == 'morning':
            self._update_position_openclose()
        return True

    def on_close(self, payload):
        if payload['period'] == 'noon':
            self._update_position_openclose()
        return True

    def on_quot(self, payload):
        for code in self.position.keys():
            if code in payload:
                self._update_position_quot(code, payload[code])
        if self.cost > 0:
            self.profit_rate = self.profit / self.cost

        return True

    def on_entrust(self, payload):
        action = payload['action']
        if action == 'buy' or action == 'sell':
            entrust = Entrust(self.db)
            entrust.action = action
            entrust.name = payload['name']
            entrust.code = payload['code']
            entrust.time = payload['time']
            entrust.price = payload['price']
            entrust.volume = payload['vol']
            if action == 'buy':
                if not self._handle_entrust(entrust, None):
                    self.log.error('买委托失败: {}'.format(entrust))
                    return None
                self.entrust.append(entrust)
                return entrust

            if action == 'sell':
                code, vol = payload['code'], payload['vol']
                if code not in self.position:
                    self.log.error('卖委托失败, 无持仓数据: {}'.format(payload))
                    return None
                position = self.position[code]

                if not self._handle_entrust(entrust, position):
                    self.log.error('卖委托失败, 无足够持仓数据: payload={}, position={}'.format(payload, position))
                    return None
                self.entrust.append(entrust)
                return entrust

            return None

        # if action == 'cancel':
        #     entrust_id = payload['id']
        #     for entrust in self.entrust:
        #         if entrust.id == entrust_id and entrust.status == 'commit':
        #             entrust.status = 'cancel'
        #             entrust.volume_cancel = entrust.volume
        #             return entrust
        #     self.log.error('委托单无法找到: id={}'.format(entrust_id))
        return None
