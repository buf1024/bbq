from .broker import Broker
import uuid


class BrokerBacktest(Broker):
    def __init__(self, db):
        super().__init__(db)
        self._strategy_signal = []

    def from_json(self, js):
        return super().from_json(js)

    def on_done(self):
        if not super().on_done():
            return False
        # report
        self.log.info('backtest on done')
        return True

    def on_risk(self, payload):
        self.log.debug('backtest on_risk payload={}', payload)
        return True

    def on_strategy(self, payload):
        self._strategy_signal.append(payload)
        self.log.debug('backtest on_strategy payload={}'.format(payload))
        entrust = super().on_strategy(payload)
        if not entrust:
            return None
        self.log.debug('backtest 策略委托 entrust: {}'.format(entrust))
        broker_id = str(uuid.uuid4())
        if not self.account.on_entrust_done(entrust, broker_id, entrust.volume):
            self.log.error('backtest 成交异常')
            return False
        self.log.debug('委托成交: entrust={}'.format(entrust))
        return True
