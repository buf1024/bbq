from barbarian import log
from barbarian.stock import Account
from barbarian.stock.trader.strategy import strategies as trade_strategies
from barbarian.stock import risks


class Broker:
    """
    券商交易接口

    提供 buy(买), sell(卖), cancel(撤销) 委托接口
    buy(买), sell(卖), canecel(撤销)委托成功或失败均产生委托结果事件
    buy(买), sell(卖), cancel(撤销)成交或撤销均产生事件

    产生的事件:
    1. 委托(买,卖,撤销)提交事件
    2. 委托(买,卖,撤销)成交事件
    3. 资金同步事件
    4. 持仓同步事件
    """

    name = None
    desc = None

    def __init__(self, db):
        self.log = log.get_logger(self.__class__.__name__)

        self.db = db
        self.account = None
        self.risk = None
        self.strategy = None

    def from_json(self, js):
        self.account = Account(self.db, self)
        if not self.account.from_json(js['account']):
            self.log.error('broker account from json failed')
            return False

        self.risk = risks[js['risk']['name']](self.db, self)
        if not self.risk.from_json(js['risk']):
            self.log.error('broker risk from json failed')
            return False

        self.strategy = trade_strategies[js['strategy']['name']](self.db, self)
        if not self.strategy.from_json(js['strategy']):
            self.log.error('broker strategy from json failed')
            return False

        return True

    def on_open(self, payload):
        self.log.debug('on_open')
        if self.account.on_open(payload=payload) and self.risk.on_open(payload=payload) and self.strategy.on_open(
                payload=payload):
            return True
        return False

    def on_close(self, payload):
        self.log.debug('on_close')
        if self.risk.on_close(payload=payload) and \
                self.strategy.on_close(payload=payload) and \
                self.account.on_close(payload=payload):
            return True
        return False

    def on_done(self):
        self.log.debug('on_done')
        if self.risk.on_done() and self.strategy.on_done():
            return True
        return False

    def on_quot(self, payload):
        self.log.debug('on_quot')
        if self.account.on_quot(payload=payload) and \
                self.risk.on_quot(payload=payload) and \
                self.strategy.on_quot(payload=payload):
            return True
        return False

    def on_risk(self, payload):
        pass

    def on_strategy(self, payload):
        # 风控拦截
        self.log.debug('on_strategy')
        if not self.risk.on_entrust(payload):
            self.log.debug('entrust intercept by risk: payload={}'.format(payload))
            return None

        entrust = self.account.on_entrust(payload)
        if not entrust:
            self.log.error('entrust failed')
            return None

        return entrust
