from .broker import Broker


class BrokerSimulate(Broker):

    def __init__(self, db):
        super().__init__(db)

    def from_json(self, js):
        return super().from_json(js)

    def on_quot(self, payload):
        super().on_quot(payload)
