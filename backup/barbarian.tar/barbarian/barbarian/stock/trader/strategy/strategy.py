from barbarian import log
from datetime import datetime


class Strategy:
    name = None
    desc = None

    def __init__(self, db, broker):
        self.log = log.get_logger(self.__class__.__name__)
        self.db = db
        self.broker = broker
        self.codes = []

        self.select = None
        self._create_time = datetime.now()

    def from_json(self, js):
        return True

    def start(self):
        return True

    def stop(self):
        pass

    def on_open(self, payload):
        return True

    def on_close(self, payload):
        return True

    def on_done(self):
        return True

    def on_quot(self, payload):
        return True

