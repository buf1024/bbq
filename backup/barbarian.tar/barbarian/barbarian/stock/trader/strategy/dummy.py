from .strategy import Strategy


class Dummy(Strategy):
    """
    选择股票：前3个交易日 连续上涨
    高于昨日最高价: 卖出
    低于昨日最低价: 买入
    """
    name = '随机测试策略'
    desc = '随机测试策略'

    def __init__(self, db, broker):
        super().__init__(db, broker)
        self.account = broker.account

    def from_json(self, js):
        if not super().from_json(js):
            return False
        self.codes = ['000001.SZ']
        return True

    def on_quot(self, payload):
        name, code, price, time = payload['000001.SZ']['name'], payload['000001.SZ']['code'], payload['000001.SZ'][
            'now'], payload['000001.SZ']['time']
        self.log.debug('strategy on_quot: name={}, code={}, price={}'.format(name, code, price))
        if len(self.account.position) == 0 and self.account.cash_available > 0:
            if '000001.SZ' in payload:
                # 空仓则现价买入半仓
                vol = int(int(self.account.cash_available / (2 * price)) / 100)
                if vol > 0:
                    vol *= 100
                    self.log.debug('vol:{}, cash:{}'.format(vol, self.account.cash_available))
                    payload = {'code': code, 'name': name, 'action': 'buy', 'vol': vol, 'price': price, 'time': time}
                    self.log.info('signal strategy buy action: {}'.format(payload))
                    self.broker.on_strategy(payload=payload)

        if '000001.SZ' in payload and '000001.SZ' in self.account.position:
            pos = self.account.position['000001.SZ']
            if pos.volume_available > 0:
                # 满仓则现价清仓
                payload = {'code': code, 'name': name, 'action': 'sell', 'vol': pos.volume_available, 'price': price,
                           'time': time}
                self.log.info('signal strategy sell action: {}'.format(payload))
                self.broker.on_strategy(payload=payload)
        return True
