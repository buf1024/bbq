from barbarian.stock import Risk


class Dummy(Risk):
    name = 'Dummy'
    desc = 'dummy risk strategy'

    def __init__(self, db, broker):
        super().__init__(db, broker)

    def on_quot(self, payload):
        print('dummy risk on_quot: {}'.format(payload))
