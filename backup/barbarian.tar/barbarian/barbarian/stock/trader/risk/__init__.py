from barbarian.util import load_file
from os.path import dirname

__file_path = dirname(__file__)

risks = load_file(__file_path, 'trader.risk', ('risk.py',))
