from .risk import Risk
from datetime import datetime, timedelta


class SimpleStop(Risk):
    name = 'simple_stop'
    desc = 'simple stop'

    def __init__(self, db, broker):
        super().__init__(db, broker)

        self._stop_profit = 0
        self._stop_profit_rate = 0

        self._stop_lost = 0
        self._stop_lost_rate = 0

        self._stop_time = 0

    def from_json(self, js):
        if not super().from_json(js):
            return False

        self._stop_profit = 0 if 'stop_profit' not in js else js['stop_profit']
        self._stop_lost_rate = 0 if 'stop_lost_rate' not in js else js['stop_lost_rate']

        self._stop_lost = 0 if 'stop_lost' not in js else js['stop_lost']
        self._stop_lost_rate = 0 if 'stop_lost_rate' not in js else js['stop_lost_rate']

        self._stop_time = 0 if 'stop_time' not in js else js['stop_time']

        return True

    def on_quot(self, payload):
        self.log.debug('simple risk on_quot: {}'.format(payload))
        # for postion in self.account.position.values():
        #     if postion.volume_available <= 0:
        #         continue
        #
        #     is_lost = False if postion.profit > 0 else True
        #
        #     profit_rate = abs(postion.profit_rate)
        #     profit = abs(postion.profit)
        #     if self._stop_lost_rate > 0 and is_lost and self._stop_lost_rate > profit_rate:
        #         continue
        #
        #     if self._stop_lost > 0 and is_lost and self._stop_lost > profit:
        #         continue
        #
        #     if self._stop_profit_rate > 0 and not is_lost and self._stop_profit_rate > profit_rate:
        #         continue
        #
        #     if self._stop_profit and not is_lost and self._stop_lost > profit:
        #         continue
        #
        #     if self._stop_time > 0:
        #         pass

        return True
