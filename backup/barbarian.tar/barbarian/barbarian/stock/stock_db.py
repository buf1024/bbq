from collections import OrderedDict
from barbarian.mongodb import MongoDB


class StockDB(MongoDB):
    _common_db = 'common_db'  # 通用数据库
    _code_info_col = 'code_info_col'  # 股票信息
    _index_info_col = 'index_info_col'  # 指数信息
    _trade_cal_col = 'trade_cal_col'  # 交日日历

    _code_kdata_db = 'code_kdata_db'  # 股票日K数据库
    _code_index_db = 'code_index_db'  # 股票日指标数据库

    _index_kdata_db = 'index_kdata_db'  # 指数日K数据库

    def __init__(self, uri='mongodb://localhost:27017/', pool=5):
        super().__init__(uri, pool)

    @property
    def common_db(self):
        return self._common_db

    @property
    def code_kdata_db(self):
        return self._code_kdata_db

    @property
    def code_index_db(self):
        return self._code_index_db

    @property
    def index_kdata_db(self):
        return self._index_kdata_db

    @property
    def code_info_col(self):
        return self._code_info_col

    @property
    def index_info_col(self):
        return self._index_info_col

    @property
    def trade_cal_col(self):
        return self._trade_cal_col

    def get_coll(self, db, col):
        client = self.get_client()
        return client[db][col]

    async def build_stock_index(self):
        self.log.info('创建索引: db={}, col={}'.format(self._common_db, self._trade_cal_col))
        await self.build_index(self._common_db, self._trade_cal_col, index=[('cal_date', -1)])

        self.log.info('创建索引: db={}, col={}'.format(self._common_db, self._code_info_col))
        await self.build_index(self._common_db, self._code_info_col, index=[('code', 1)])

        self.log.info('创建索引: db={}, col={}'.format(self._common_db, self._index_info_col))
        await self.build_index(self._common_db, self._index_info_col, index=[('code', -1)])

        indexes = await self.load_index_list(projection=['code'])
        if indexes is None:
            self.log.warn('指数列表为空，无法对指数索引')
        else:
            for index in indexes.to_dict('records'):
                self.log.info('创建索引: db={}, col={}'.format(self._code_index_db, index['code']))
                await self.build_index(self._code_index_db, index['code'], index=[('trade_date', -1)])

        codes = await self.load_code_list(projection=['code'])
        if codes is None:
            self.log.warn('股票列表为空，无法对指数索引')
        else:
            for code in codes.to_dict('records'):
                self.log.info('创建索引: db={}, col={}'.format(self._code_index_db, code['code']))
                await self.build_index(self._index_kdata_db, code['code'], index=[('trade_date', -1)])

        self.log.info('创建索引完成')

    async def _do_batch_load(self, codes, col_func, **kwargs):
        codes = [code.upper() for code in codes]
        d = OrderedDict()
        for code in codes:
            coll = col_func(self.get_client(), code)
            df = await self.do_load(coll, **kwargs)
            d[code] = df
        return None if len(d) == 0 else d

    async def _do_batch_update(self, coll_func, data_frames, filter_func=None, index=None, index_uniq=True):
        id_list = []
        for item in data_frames.to_dict('records'):
            coll = coll_func(self.get_client(), item['code'].upper() if 'code' in item else None)
            # if index is not None:
            #     try:
            #         coll.create_index(index, unique=index_uniq)
            #     except Exception as e:
            #         self.log.error('创建index异常{}\n item={} call stack: {}'.format(e, item, traceback.format_exc()))

            filter = None if filter_func is None else filter_func(item)
            ids = await self.do_update(coll, filter=filter, update=item)
            if ids is None:
                continue
            if isinstance(ids, list):
                id_list = id_list + ids
            else:
                id_list.append(ids)
        return id_list if len(id_list) > 0 else None

    async def load_code_list(self, **kwargs):
        """
        :param kwargs: filter=None, projection=None, skip=0, limit=0, sort=None
        :return: DataFrame[_id, code name area industry market exchange]
        """
        self.log.info('加载股票列表, kwargs={}'.format(kwargs))
        client = self.get_client()
        coll = client[self._common_db][self._code_info_col]
        return await self.do_load(coll, **kwargs)

    async def save_code_list(self, codes):
        """
        :param codes: DataFrame[_id, code name area industry market exchange]
        :return: None/list[_id]
        """
        self.log.info('保存股票列表, count = {}'.format(codes.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._code_info_col],
                                           data_frames=codes, filter_func=lambda item: {'code': item['code']},
                                           index=[('code', 1)])

    async def load_trade_cal(self, **kwargs):
        """
        :param kwargs:  filter=None, projection=None, skip=0, limit=0, sort=None
        :return: DataFrame[_id, cal_date,is_open]
        """
        self.log.info('加载交易日历, kwargs={}'.format(kwargs))
        client = self.get_client()
        coll = client[self._common_db][self._trade_cal_col]
        return await self.do_load(coll, **kwargs)

    async def save_trade_cal(self, cals):
        """
        :param cals: DataFrame[cal_date,is_open]
        :return: None/list[_id]
        """
        self.log.info('保存交易日历, count = {} ...'.format(cals.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._trade_cal_col],
                                           data_frames=cals, filter_func=lambda item: item,
                                           index=[('cal_date', -1)])

    async def load_code_adj_kdata(self, codes=None, **kwargs):
        self.log.info('加载复权因子, kwargs={}'.format(kwargs))
        filter = None if 'filter' not in kwargs else kwargs['filter']
        factors = await self.load_code_kdata(codes=codes, filter=filter, projection=['adj_factor'],
                                             sort=[('trade_date', -1)])
        if factors is None:
            return None

        data = await self.load_code_kdata(codes=codes, **kwargs)
        if data is None:
            return None

        for code, kdata in data.items():
            if kdata is None or factors['code'] is None:
                continue
            factor = factors['code']['adj_factor'][0]

            kdata['open'] = kdata['open'] * kdata['adj_factor'] / factor
            kdata['high'] = kdata['high'] * kdata['adj_factor'] / factor
            kdata['low'] = kdata['low'] * kdata['adj_factor'] / factor
            kdata['close'] = kdata['close'] * kdata['adj_factor'] / factor
            kdata['vol'] = kdata['vol'] * kdata['adj_factor'] / factor

        return data

    async def load_code_kdata(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None/DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('加载日K数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = await self.load_code_list(projection=['code'])
            if codes is None:
                return None
            codes = codes['code'].values
        return await self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._code_kdata_db][code],
                                         **kwargs)

    async def save_code_kdata(self, data):
        """

        :param code:
        :param data: DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        :return: None/list[_id]
        """
        self.log.info('保存日K数据, count = {} ...'.format(data.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, code: client[self._code_kdata_db][code],
                                           data_frames=data,
                                           filter_func=lambda item: {'trade_date': item['trade_date']},
                                           index=[('trade_date', -1)])

    async def load_code_daily_index(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None,DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （）
            total_amt	float	总市值 （元）
            circ_mv float	流通市值（元）])
        """
        self.log.info('加载股票每日指标, kwargs={}'.format(kwargs))
        if codes is None:
            codes = await self.load_code_list(projection=['code'])
            if codes is None:
                return None
            codes = codes['code'].values
        return await self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._code_index_db][code],
                                         **kwargs)

    async def save_code_daily_index(self, data):
        """

        :param data:
        :param kdata: DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （）
            total_amt	float	总市值 （元）
            circ_mv float	流通市值（元）])
        :return:
        """
        self.log.info('保存股票每日指标, count={}...'.format(data.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, code: client[self._code_index_db][code],
                                           data_frames=data,
                                           filter_func=lambda item: {'trade_date': item['trade_date']},
                                           index=[('trade_date', -1)])

    async def load_code_adj_trans(self, codes=None, **kwargs):

        filter = None if 'filter' not in kwargs else kwargs['filter']
        factors = await self.load_code_kdata(codes=codes, filter=filter, projection=['trade_date', 'adj_factor'],
                                             sort=[('trade_date', -1)])
        if factors is None:
            return None

        data = await self.load_code_trans(codes=codes, **kwargs)
        if data is None:
            return None

        for code, trans in data.items():
            if trans is None or factors['code'] is None:
                continue
            trade_dates = trans['trade'].drop_duplicates().tolist()
            factor = factors['code']['adj_factor'][0]
            for trade_date in trade_dates:
                factor_df = factors['code']
                filter_factors = factor_df[factor_df['trade_date'] == trade_date]
                trans[trans['trade_date'] == trade_date]['adj_factor'] = filter_factors['adj_factor'][0]

                trans['price'] = trans['price'] * trans['adj_factor'] / factor
                trans['vol'] = trans['vol'] * trans['adj_factor'] / factor

        return data

    async def load_index_list(self, **kwargs):
        """
        指数基本信息
        :return: None/DataFrame([code,name,market,category,index_type,exp_date])
        """
        self.log.info('加载大盘指数列表, kwargs={}'.format(kwargs))
        client = self.get_client()
        coll = client[self._common_db][self._index_info_col]
        return await self.do_load(coll, **kwargs)

    async def save_index_list(self, indexes):
        """
        :param indexes: DataFrame([code,name,market,category,index_type,exp_date])
        :return: None/list[_id]
        """
        self.log.info('保存大盘指数列表, count = {}...'.format(indexes.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._index_info_col],
                                           data_frames=indexes, filter_func=lambda item: {'code': item['code']},
                                           index=[('code', -1)])

    async def load_index_kdata(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None/DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('加载大盘日k数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = await self.load_code_list(projection=['code'])
            if codes is None:
                return None
            codes = codes['code'].values
        return await self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._index_kdata_db][code],
                                         **kwargs)

    async def save_index_kdata(self, data):
        """

        :param data:
        :param index:  DataFrame([code,trade_date,open,high,low,close,vol,amt])
        :return:
        """
        self.log.info('保存大盘日K线数据, count = {} ...'.format(data.shape[0]))
        return await self._do_batch_update(coll_func=lambda client, code: client[self._index_kdata_db][code],
                                           data_frames=data,
                                           filter_func=lambda item: {'trade_date': item['trade_date']},
                                           index=[('trade_date', -1)])


if __name__ == '__main__':
    from barbarian.stock.stock_tushare_pro import TusharePro
    from barbarian.util import run_until_complete
    from datetime import datetime

    async def test_trade_cal(db, tu):
        # cals = tu.get_trade_cal()
        # print('tu cal:\n')
        # print(cals.head())
        # await db.save_trade_cal(cals=cals)
        end_date = datetime(year=2020, month=8, day=5)
        start_date = datetime(year=2020, month=8, day=4)

        cals = await db.load_trade_cal(filter={'cal_date': {'$lte': end_date, '$gte': start_date}, 'is_open': 1},
                                       sort=[('cal_date', -1)])
        print('mongo cal:\n')
        print(cals.head())

    async def test_code_list(db, tu):
        codes = tu.get_code_list()
        print('tu codes:\n')
        print(codes.head())
        await db.save_code_list(codes=codes)
        codes = await db.load_code_list()
        print('codes:\n')
        print(codes.head())

    async def test_code_kdata(db, tu):
        kdata = tu.get_code_kdata(trade_date='20200727')
        print('tu kdata:\n')
        print(kdata.head())
        await db.save_code_kdata(kdata)
        kdata = await db.load_code_kdata(codes=['603116.sh'])
        print('mongo kdata:\n')
        for k, frame in kdata.items():
            print('code:{code}\n'.format(code=k))
            print(frame.head())

    async def test_code_daily_index(db, tu):
        indexes = tu.get_code_daily_index(code='601099.sh', trade_date='20200727')
        print('tu code_indexes:\n')
        print(indexes.head())
        await db.save_code_daily_index(indexes)
        indexes = await db.load_code_daily_index(codes=['601099.sh'],
                                                 filter={'trade_date': datetime(year=2020, month=7, day=27)})
        print('mongo index:\n')
        for k, frame in indexes.items():
            print('code:{code}\n'.format(code=k))
            print(frame.head())

    async def test_index_list(db, tu):
        indexes = tu.get_index_list()
        print('tu code_index:\n')
        print(indexes.head())
        await db.save_index_list(indexes=indexes)
        indexes = await db.load_index_list()
        print('indexes:\n')
        print(indexes.head())

    async def test_index_kdata(db, tu):
        kdata = tu.get_index_kdata(code='000001.SH', start_date='20200727', end_date='20200727')
        print('tu index kdata:\n')
        print(kdata.head())
        await db.save_index_kdata(kdata)
        kdata = await db.load_index_kdata(codes=['000001.SH'],
                                          filter={'trade_date': datetime.strptime('20200727', '%Y%m%d')})
        print('mongo index kdata:\n')
        for k, frame in kdata.items():
            print('code:{code}'.format(code=k))
            print(frame.head())


    mongo = StockDB()
    mongo.init({'uri': 'mongodb://localhost:57017/'})

    stock = TusharePro(token='408481e156da6a5facd695e58add4d0bf705649fe0f460d03d4d6908')

    run_until_complete(
        test_trade_cal(mongo, stock),
        # test_code_list(mongo, stock),
        # test_code_kdata(mongo, stock),
        # test_code_daily_index(mongo, stock),
        # test_index_list(mongo, stock),
        # test_index_kdata(mongo, stock),
    )
