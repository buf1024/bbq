from barbarian import log
import traceback
from datetime import datetime, timedelta
import asyncio
import pandas as pd


class StockSync:
    concurrent_count = 30

    def __init__(self, db, stock):
        self.log = log.get_logger(self.__class__.__name__)
        self.db = db
        self.stock = stock
        self.code_sync_date = None

    async def sync(self, is_full=False, build_index=False,
                   start_date=None, end_date=None,
                   sync_basic=True, filter_index=True):
        try:
            self.log.info('同步参数: is_full={}, build_index={}, start_date={}, end_date={}'.format(
                is_full, build_index, start_date, end_date))
            now = datetime.now()
            now = datetime(year=now.year, month=now.month, day=now.day)
            stock_codes, stock_indexes, cal_dates, is_trade_day = await self._sync_basic_data(now, start_date, end_date, sync_basic)
            if stock_codes is None or stock_codes is None:
                self.log.error('保存/加载基础数据失败')
                return

            queue = asyncio.Queue(self.concurrent_count)
            loop = asyncio.get_event_loop()

            for _, cal_date in cal_dates.iterrows():
                # if self.code_sync_date is not None:
                #     self.log.info('最近日期完成: date={}'.format(self.code_sync_date))
                #     break
                # trade_date = (np.datetime_as_string(cal_date, 'D')).replace('-', '')
                trade_date = cal_date['cal_date']
                await queue.put(trade_date)
                coro = self.sync_code_full(trade_date=trade_date, queue=queue, is_full=is_full)
                loop.create_task(coro)

            await queue.put(stock_indexes)
            coro = self.sync_index_full(codes=stock_indexes, queue=queue, filter_index=filter_index, now=now, is_trade_day=is_trade_day)
            loop.create_task(coro)

            await queue.join()

            if build_index:
                await self.db.build_stock_index()
            self.log.info('股票信息同步完成')
        except Exception as e:
            self.log.error('同步股票失败: ex={}, stack={}'.format(e, traceback.format_exc()))

    # async def check_done(self, func, down_size):
    #     is_done = False
    #     data = await func()
    #
    #     if data is not None:
    #         data = [x for x in data.values() if x is not None]
    #         db_size = len(data)
    #         self.log.info('data 下载数量:{}, 数据库数量: {}'.format(down_size, db_size))
    #         if down_size == db_size:
    #             is_done = True
    #
    #     return is_done

    async def sync_code_full(self, trade_date, queue, is_full=False):
        try:
            trade_date = trade_date.strftime('%Y%m%d')
            self.log.info('开始同步股票数据, trade_date={}'.format(trade_date))
            kdata = self.stock.get_code_kdata(trade_date=trade_date)
            if kdata is not None and not kdata.empty:
                await self.db.save_code_kdata(data=kdata)

            # is_done = False
            # if not is_full:
            #     func = partial(self.db.load_code_kdata, codes=kdata['code'].values,
            #                    filter={'trade_date': datetime.strptime(trade_date, '%Y%m%d')})
            #     is_done = await self.check_done(func, kdata.shape[0])
            #
            # if not is_done:
            #     await self.db.save_code_kdata(data=kdata)

            daily_data = self.stock.get_code_daily_index(trade_date=trade_date)
            if daily_data is not None and not daily_data.empty:
                await self.db.save_code_daily_index(data=daily_data)

            # is_done = False
            # if not is_full:
            #     func = partial(self.db.load_code_daily_index, codes=kdata['code'].values,
            #                    filter={'trade_date': datetime.strptime(trade_date, '%Y%m%d')})
            #     is_done = await self.check_done(func, kdata.shape[0])
            # if not is_done:
            #     await self.db.save_code_daily_index(data=daily_data)

        except Exception as e:
            self.log.error('同步股票失败: trade_date={} ex={} stack={}'.format(trade_date, e, traceback.format_exc()))
        finally:
            await queue.get()
            queue.task_done()

    def _accept_filter(self, code):
        accept_list = ['000001.SH',  # 上证综指
                       '399001.SZ',  # 深证成指
                       '399006.SZ',  # 创业板指
                       '399005.SZ',  # 中小板指
                       '000300.SH',  # 沪深300
                       '000688.SH',  # 科创50
                       '399673.SZ',  # 创业板50
                       '399550.SZ',  # 央视50
                       '399678.SZ',  # 深次新股
                       '399007.SZ',  # 深证300
                       '399008.SZ',  # 中小300
        ]
        return code in accept_list

    async def sync_index_full(self, now, codes, filter_index,  is_trade_day, queue):
        try:
            for _, indexes in codes.iterrows():
                code = indexes['code']
                if filter_index:
                    if not self._accept_filter(code):
                        continue

                self.log.info('开始同步指数数据, code={}'.format(code))

                start_date = None
                end_date = now
                latest_date = await self.db.load_index_kdata(codes=[code], projection=['trade_date'],
                                                             sort=[('trade_date', -1)], limit=1)
                if latest_date[code.upper()] is not None:
                    start_date = latest_date[code].iloc[0, 0]
                    test_date = start_date
                    if is_trade_day:
                        # 交易日
                        dnow = datetime.now()
                        cnow = now + timedelta(hours=15, minutes=15)
                        if dnow < cnow:
                            test_date = test_date + timedelta(days=1)

                    if test_date >= end_date:
                        self.log.info('code={}, test_date={}, 已经同步完毕'.format(code, test_date))
                        continue

                if start_date is not None:
                    start_date = start_date.strftime('%Y%m%d')
                if end_date is not None:
                    end_date = end_date.strftime('%Y%m%d')

                kdata = self.stock.get_index_kdata(code=code, start_date=start_date, end_date=end_date)
                if kdata is not None and not kdata.empty:
                    kdata.sort_values(by=['trade_date'], inplace=True)
                    await self.db.save_index_kdata(data=kdata)

        except Exception as e:
            self.log.error('同步数据失败: trade_date={} ex={} stack={}'.format(code, e, traceback.format_exc()))
        finally:
            await queue.get()
            queue.task_done()

    async def _sync_basic_data(self, now, start_date, end_date, sync_basic, is_full=False):
        self.log.info('开始同步基础数据...')

        self.log.info('获取股票列表...')
        codes = self.stock.get_code_list()
        if codes is None:
            self.log.error('获取股票列表错误')
            return None, None, None

        self.log.info('获取股票指数数据...')
        indexes = self.stock.get_index_list()
        if indexes is None:
            self.log.error('获取股票指数数据')
            return None, None, None

        if sync_basic:
            self.log.info('保存股票列表, count = {} ...'.format(codes.shape[0]))
            if codes is not None and not codes.empty:
                await self.db.save_code_list(codes=codes)

            if await self.db.load_trade_cal(filter={'cal_date': now}) is None:
                self.log.info('获取股票交易日...')
                trad_cals = self.stock.get_trade_cal()
                if trad_cals is None:
                    self.log.error('获取交易日错误')
                    return None, None, None

                self.log.info('保存股票交易日...')
                if trad_cals is not None and not trad_cals.empty:
                    await self.db.save_trade_cal(cals=trad_cals)

                self.log.info('保存股票指数数据...')
                if indexes is not None and not indexes.empty:
                    await self.db.save_index_list(indexes=indexes)

        is_trade_day = False
        df = await self.db.load_trade_cal(filter={'cal_date': {'$lte': now, '$gte': now}, 'is_open': 1})
        if df is not None and not df.empty:
            is_trade_day = True

        flter = {'cal_date': {'$lte': now}, 'is_open': 1}
        cal_dates = None
        if is_full:
            if start_date is not None and end_date is not None:
                if end_date > now:
                    end_date = now
                flter = {'cal_date': {'$lte': end_date, '$gte': start_date}, 'is_open': 1}
            else:
                if start_date is not None:
                    flter = {'cal_date': {'$lte': now, '$gte': start_date}, 'is_open': 1}

                if end_date is not None:
                    if end_date > now:
                        end_date = now
                    flter = {'cal_date': {'$lte': end_date}, 'is_open': 1}
        else:
            self.log.info('计算增量同步开始时间')
            kdatas = await self.db.load_code_kdata(codes=codes['code'].values, projection=['trade_date'], sort=[('trade_date', -1)], limit=1)
            trade_date = None
            sup_codes = set()
            for code, kdata in kdatas.items():
                trade_date_t = codes[codes['code'] == code]['list_date'].iloc[0]
                if kdata is not None:
                    trade_date_t = kdata.loc[0, 'trade_date']

                if trade_date is None or trade_date > trade_date_t and code not in sup_codes:
                    # 是否停牌
                    next_cal_dates = await self.db.load_trade_cal(filter={'cal_date': {'$gt': trade_date_t}, 'is_open': 1},
                                                                  projection=['cal_date'], limit=1)
                    cal_date = next_cal_dates['cal_date'].iloc[0]
                    df = self.stock.get_code_suspend(code=code, trade_date=cal_date.strftime('%Y%m%d'))
                    if df is None or df.empty:
                        trade_date = trade_date_t
                    else:
                        self.log.info('停牌股，忽略计算，code={}, trade_date={}'.format(code, cal_date))
                        sup_codes.add(code)

            self.log.info('增量同步开始时间: {}'.format(trade_date))

            if start_date is not None:
                if trade_date is not None:
                    if trade_date > start_date:
                        start_date = trade_date
            else:
                start_date = trade_date

            if end_date is not None:
                if end_date > now:
                    end_date = now
            else:
                end_date = now

            if is_trade_day and trade_date is not None:
                # 交易日
                dnow = datetime.now()
                cnow = now + timedelta(hours=15, minutes=15)
                if dnow < cnow:
                    start_date = trade_date + timedelta(days=1)

            if start_date != now:
                flter = {'cal_date': {'$lte': end_date, '$gt': start_date}, 'is_open': 1}
            else:
                if start_date is not None:
                    self.log.info('日k数据已经更新完毕')
                    cal_dates = pd.DataFrame()

        if cal_dates is None:
            cal_dates = await self.db.load_trade_cal(filter=flter,
                                                     projection=['cal_date'], sort=[('cal_date', 1)])

        return codes, indexes, cal_dates, is_trade_day


if __name__ == '__main__':
    from barbarian.util import run_until_complete
    from barbarian.stock.stock_db import StockDB
    from barbarian.stock.stock_tushare_pro import TusharePro
    import sys
    import os
    import argparse

    args = None
    try:
        parser = argparse.ArgumentParser(description='barbarian fund data sync process')
        parser.add_argument('-u', '--uri', type=str, nargs='?', default='mongodb://localhost:57017/',
                            help='mongodb uri address')
        parser.add_argument('-p', '--pool', type=int, default=5, help='mongodb pool size')
        parser.add_argument('-f', '--sync_full', type=bool, nargs='?', const=True, default=False, help='full sync tag')
        parser.add_argument('-i', '--build_index', type=bool, nargs='?', const=True, default=False,
                            help='build index tag')
        parser.add_argument('-s', '--start_date', type=str, nargs='?', default='20000101', help='sync start date, yyyymmdd')
        parser.add_argument('-e', '--end_date', type=str, nargs='?', default=None, help='sync end date, yyyymmdd')
        parser.add_argument('-n', '--not_basic', type=bool, nargs='?', const=True, default=False, help='not basic data')
        parser.add_argument('-t', '--not_filter_index', type=bool, nargs='?', const=True, default=False, help='filter_index tag')


        args = parser.parse_args()
    except SystemExit as e:
        os._exit(0)

    mongo = StockDB()
    js = {'uri': args.uri, 'pool': args.pool}
    if not mongo.init(js):
        print('连接数据库失败: js={}'.format(js))
        sys.exit(-1)

    stock = TusharePro(token='408481e156da6a5facd695e58add4d0bf705649fe0f460d03d4d6908')

    start_date = None
    end_date = None
    try:
        if args.start_date is not None:
            start_date = datetime.strptime(args.start_date, '%Y%m%d')
        if args.end_date is not None:
            end_date = datetime.strptime(args.end_date, '%Y%m%d')
    except Exception as e:
        print('日期格式不正确，格式: yyyymmdd')
        sys.exit(-1)

    stock_sync = StockSync(mongo, stock)
    run_until_complete(stock_sync.sync(is_full=args.sync_full,
                                       build_index=args.build_index,
                                       start_date=start_date,
                                       end_date=end_date,
                                       sync_basic=not args.not_basic,
                                       filter_index=not args.not_filter_index))
