from barbarian.util import load_file
from os.path import dirname

__file_path = dirname(__file__)

quotes = load_file(__file_path, 'quot', ('quot.py', 'quot_barbar.py'))
