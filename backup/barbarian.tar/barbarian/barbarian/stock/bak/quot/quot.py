from barbarian import log


class Quot:
    name = None
    desc = None

    def __init__(self, db):
        self.log = log.get_logger(self.__class__.__name__)
        self.db = db

    def init(self, js):
        return True

    def stop(self):
        return True

    def is_sequence(self):
        return False

    def get_trade_cal(self, **kwargs):
        """
        交易日历
        :param kwargs: start='yyyymmdd', end='yyyymmdd'
        :return: None / DataFrame[cal_date,is_open]
        """
        raise Exception('{} not implement'.format(self.get_trade_cal.__qualname__))

    def get_code_list(self):
        """
        股票列表
        :return: None / DataFrame[code name area industry market] market->市场类型 （主板/中小板/创业板/科创板）
        """
        raise Exception('{} not implement'.format(self.get_code_list.__qualname__))

    def get_code_kdata(self, **kwargs):
        """
        日K线行情
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        raise Exception('{} not implement'.format(self.get_code_kdata.__qualname__))

    def get_code_adj_factor(self, **kwargs):
        """
        复权因子
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code, trade_date, adj_factor])
        """
        raise Exception('{} not implement'.format(self.get_code_adj_factor.__qualname__))

    def get_code_daily_index(self, **kwargs):
        """
        每日指标
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （万股）
            float_share	float	流通股本 （万股）
            free_share	float	自由流通股本 （万）
            total_amt	float	总市值 （万元）
            circ_mv float	流通市值（万元）])
        """
        raise Exception('{} not implement'.format(self.get_code_daily_index.__qualname__))

    def get_code_trans(self, **kwargs):
        """
        每日成交数据
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code, trade_date,
            time	成交时间
            price	成交价格
            vol 	成交量(手)
            amt  成交额(元)
            type    性质 -> 买盘 卖盘 中性盘
        """
        raise Exception('{} not implement'.format(self.get_code_trans.__qualname__))

    def get_index_list(self):
        """
        指数基本信息
        :return: None/DataFrame([code,name,market,category,index_type,exp_date])
        """
        raise Exception('{} not implement'.format(self.get_index_list.__qualname__))

    def get_index_kdata(self, **kwargs):
        """
        指数日线行情
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt])
        """
        raise Exception('{} not implement'.format(self.get_index_kdata.__qualname__))

    def get_rt_quot(self, codes=None):
        """

        :param codes:
        :param kwargs:
        :return:
        [code: {
            name=xxx,
            open=xx,pre_close=xx,now=xx,high=xx,low=xx,buy=xx,sell=xx,
            vol=xx, amount=xx, # 累计成交量、成交额
            bid=[(bid1_vol, bid1_price), ...], ask=[(ask1_vol, ask1_price), ...],
            date=yyyymmdd,time=hh:mm:ss}, ...]/None,
        """
        raise Exception('{} not implement'.format(self.get_rt_quot.__qualname__))
