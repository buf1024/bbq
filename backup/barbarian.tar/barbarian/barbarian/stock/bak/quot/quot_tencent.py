from .quot import Quot
import aiohttp
import asyncio
import time
from io import StringIO
import pandas as pd
import traceback


class QuotTencent(Quot):
    name = 'tencent'
    desc = 'tencent quotation'

    def __init__(self, db):
        super().__init__(db)

    def _transfer_code(self, code):
        code = code.lower()
        part = code.split('.')
        return part[1] + part[0]

    async def _get_code_trans(self, **kwargs):
        code = kwargs['code']
        trade_date = kwargs['trade_date']
        session = aiohttp.ClientSession()
        for i in range(3):
            try:
                async with session.get(
                        'http://stock.gtimg.cn/data/index.php?appn=detail&action=download&c={0}&d={1}'.format(
                            self._transfer_code(code), trade_date), headers={
                            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, '
                                          'like Gecko) Chrome/73.0.3683.86 Safari/537.36'
                        }) as req:

                    lines = await req.text(encoding='gbk')
                    # lines = lines.encode('GBK')
                    frame = pd.read_table(StringIO(lines), names=['time', 'price', 'change', 'vol', 'amount', 'type'],
                                          skiprows=[0])
                    frame['code'] = code.upper()
                    frame['trade_date'] = trade_date
                    frame['trade_date'] = pd.to_datetime(frame['trade_date'], format='%Y%m%d')
                    frame['time'] = trade_date + frame['time']
                    frame['time'] = pd.to_datetime(frame['time'], format='%Y%m%d%H:%M:%S')

                    frame.rename(columns={'amount': 'amt'}, inplace=True)
                    df = frame[['code', 'trade_date', 'time', 'price', 'vol', 'amt', 'type']]

                    self.log.info('get_code_trans应答 size={}'.format(df.shape[0] if df is not None else 0))
                    await session.close()
                    return None if df.shape[0] == 0 else df
            except Exception as e:
                msg = traceback.format_exc()
                self.log.error('request tencent %s tushare pro exception: \n%s, retries 10s later',
                               self.get_code_trans.__name__, msg)
                time.sleep(10)
        await session.close()
        self.log.info('get_code_trans 3次尝试失败，放弃, kwargs={}'.format(kwargs))
        return None

    def get_code_trans(self, **kwargs):
        """
        每日成交数据
        :param kwargs: code=xxx.sh trade_date=xxxx
        :return: None / DataFrame([code, trade_date,
             time	成交时间
             price	成交价格
             vol 	成交量(手)
             amt  成交额(元)
             type    性质 -> 买盘 卖盘 中性盘
        """
        self.log.info('get_code_trans请求, kwargs={}'.format(kwargs))
        code = kwargs['code'] if 'code' in kwargs else None
        trade_date = kwargs['trade_date'] if 'trade_date' in kwargs else None
        if code is None or trade_date is None:
            self.log.error('code or trade_date 参数为空')
            return None

        evt_loop = None
        try:
            evt_loop = asyncio.get_event_loop()
        except RuntimeError:
            evt_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(evt_loop)

        tasks = [self._get_code_trans(**kwargs)]
        quots = evt_loop.run_until_complete(asyncio.gather(*tasks))
        return quots[0]


if __name__ == '__main__':
    quot = QuotTencent(None)

    df = quot.get_code_trans(code='601099.sh', trade_date='20191127')
    print(df)
