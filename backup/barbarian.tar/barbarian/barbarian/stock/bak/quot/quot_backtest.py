from .quot import Quot
from collections import OrderedDict
import random
import pandas as pd


class QuotBacktest(Quot):
    name = 'backtest'
    desc = 'backtest quotation'

    def __init__(self, db):
        super().__init__(db)
        self.quot = OrderedDict()  # {code : [quot]}
        self.iter = {}

        self.start_date = None
        self.end_date = None
        self.iter_start_date = None

        self.quot_source = 'kdata'

        self.codes = []

    def _setup_quot(self, codes, start_date, end_date):
        self.quot = OrderedDict()
        self.codes = codes
        self.iter = {}
        pre_trade_date = self.db.load_trade_cal(filter={'cal_date': {'$lt': start_date}, 'is_open': 1},
                                                projection=['cal_date'], sort=[('cal_date', -1)], limit=1)
        if pre_trade_date is None:
            self.log.error('data lack: pre_trade_date={} {}~{}'.format(pre_trade_date, start_date, end_date))
            return False

        pre_trade_date = pre_trade_date['cal_date'].tolist()[0]
        quots = None
        if 'kdata' != self.quot_source:
            quots = self.db.load_code_trans(codes=codes,
                                            filter={'trade_date': {'$gte': pre_trade_date, '$lte': end_date}},
                                            projection=['price', 'vol', 'amt', 'trade_date', 'time'],
                                            sort=[('time', 1)])
        else:
            quots = self.db.load_code_kdata(codes=codes,
                                            filter={'trade_date': {'$gte': pre_trade_date, '$lte': end_date}},
                                            projection=['open', 'close', 'high', 'low', 'vol', 'amt', 'trade_date'],
                                            sort=[('trade_date', 1)])

        for code, quot in quots.items():
            if quot is None:
                self.log.error('data lack: code={} {}~{}'.format(code, start_date, end_date))
                return False

            if code not in self.quot:
                self.quot[code] = []

            name = self.db.load_code_list(filter={'code': code}, projection=['name'], limit=1)
            if name is not None:
                name = name.loc[0, 'name']
            quot['name'] = name

            trade_dates = quot['trade_date'].drop_duplicates().tolist()
            for i, trade_date in enumerate(trade_dates):
                if i == 0:
                    continue
                if 'kdata' != self.quot_source:
                    pre_close = quot[quot['trade_date'] == trade_dates[i - 1]]['price'].iloc[-1]
                    quot_trade_date = quot[quot['trade_date'] == trade_date][:]
                    quot_trade_date = quot_trade_date.reset_index(drop=True)
                    quot_trade_date['pre_close'] = pre_close
                    quot_trade_date['open'] = quot_trade_date.iloc[0]['price']

                    quot_trade_date['trade_date'] = quot_trade_date['trade_date'].apply(lambda v: v.strftime('%Y%m%d'))
                    quot_trade_date['time'] = quot_trade_date['time'].apply(lambda v: v.strftime('%Y%m%d  %H:%m:%S'))
                else:
                    pre_close = quot[quot['trade_date'] == trade_dates[i - 1]]['close']
                    pre_close = pre_close.reset_index(drop=True)
                    quot_trade_date = quot[quot['trade_date'] == trade_date][:]
                    quot_trade_date = quot_trade_date.reset_index(drop=True)
                    quot_trade_date['pre_close'] = pre_close[0]
                    quot_trade_date['open'] = quot_trade_date.iloc[0]['open']
                    quot_trade_date['price'] = quot_trade_date['open']
                    quot_trade_date['time'] = trade_date

                    quot_trade_date['trade_date'] = quot_trade_date['trade_date'].apply(lambda v: v.strftime('%Y%m%d'))
                    quot_trade_date['time'] = quot_trade_date['time'].apply(lambda v: v.strftime('%Y%m%d  %H:%M:%S'))

                    low, high, close = quot_trade_date.iloc[0]['low'], quot_trade_date.iloc[0]['high'], \
                                       quot_trade_date.iloc[0]['close']
                    diff = high - low
                    prices = [low, round(low + random.random() * diff, 2), high, close]

                    quot_trade_date_org = quot_trade_date[:]
                    for price in prices:
                        quot_trade_date_sim = quot_trade_date_org[:]
                        quot_trade_date_sim['price'] = price
                        quot_trade_date = pd.concat([quot_trade_date, quot_trade_date_sim])

                    quot_trade_date = quot_trade_date.reset_index(drop=True)

                self.quot[code].append(quot_trade_date)
                if code not in self.iter:
                    self.iter[code] = [0, 0]

        return True if len(self.quot) > 0 else False

    def init(self, js):
        self.start_date = None if 'start_date' not in js else js['start_date']
        self.end_date = None if 'end_date' not in js else js['end_date']

        if self.start_date is None or self.end_date is None:
            self.log.error('start_date or end_date is None')
            return False

        if not isinstance(self.start_date, datetime):
            self.start_date = datetime.strptime(self.start_date, '%Y%m%d')

        if not isinstance(self.end_date, datetime):
            self.end_date = datetime.strptime(self.end_date, '%Y%m%d')

        self.iter_start_date = self.start_date

        self.quot_source = 'kdata' if 'quot' not in js else js['quot']

        return True

    def get_rt_quot(self, codes=None):
        if codes is None:
            return None

        diff = set(codes).difference(self.codes)
        if len(diff) != 0:
            if not self._setup_quot(codes, self.iter_start_date, self.end_date):
                return None

        quot_dict = OrderedDict()
        for code in codes:
            if code not in self.quot:
                return None

            date_index, row_index = self.iter[code][0], self.iter[code][1]
            quot_trade_date = self.quot[code][date_index]
            if row_index >= quot_trade_date.shape[0]:
                self.iter[code][0] = date_index + 1
                self.iter[code][1] = 0
                date_index, row_index = self.iter[code][0], self.iter[code][1]
                if date_index >= len(self.quot[code]):
                    continue

                quot_trade_date = self.quot[code][date_index]

            d = {}
            d['code'] = code
            d['name'] = quot_trade_date.iloc[row_index]['name']
            d['open'] = quot_trade_date.iloc[row_index]['open']
            d['pre_close'] = quot_trade_date.iloc[row_index]['pre_close']
            d['now'] = quot_trade_date.iloc[row_index]['price']
            d['buy'] = quot_trade_date.iloc[row_index]['price']
            d['sell'] = quot_trade_date.iloc[row_index]['price']
            if row_index == 0:
                quot_trade_date['high'] = 0.0
                quot_trade_date['low'] = 999999.00
                quot_trade_date['total_vol'] = 0.0
                quot_trade_date['total_amt'] = 0.0

                quot_trade_date.loc[row_index, 'high'] = quot_trade_date.iloc[row_index]['price']
                quot_trade_date.loc[row_index, 'low'] = quot_trade_date.iloc[row_index]['price']
                quot_trade_date.loc[row_index, 'total_vol'] = quot_trade_date.iloc[row_index]['vol']
                quot_trade_date.loc[row_index, 'total_amt'] = quot_trade_date.iloc[row_index]['amt']
            else:
                quot_trade_date.loc[row_index, 'high'] = max(quot_trade_date.iloc[row_index]['price'],
                                                             quot_trade_date.iloc[row_index - 1]['high'])
                quot_trade_date.loc[row_index, 'low'] = min(quot_trade_date.iloc[row_index]['price'],
                                                            quot_trade_date.iloc[row_index - 1]['low'])
                quot_trade_date.loc[row_index, 'total_amt'] = quot_trade_date.iloc[row_index - 1]['total_amt'] + \
                                                              quot_trade_date.iloc[row_index]['amt']
                quot_trade_date.loc[row_index, 'total_vol'] = quot_trade_date.iloc[row_index - 1]['total_vol'] + \
                                                              quot_trade_date.iloc[row_index - 1]['vol']

            d['high'] = quot_trade_date.loc[row_index]['high']
            d['low'] = quot_trade_date.loc[row_index]['low']
            d['amt'] = quot_trade_date.loc[row_index]['total_amt']
            d['vol'] = quot_trade_date.loc[row_index]['total_vol']

            d['bid'] = []
            d['ask'] = []
            for i in range(5, 0, -1):
                d['bid'].append(
                    (quot_trade_date.loc[row_index]['vol'], quot_trade_date.loc[row_index]['price'] - 0.01 * (i - 5)))
                d['ask'].append(
                    (quot_trade_date.loc[row_index]['vol'], quot_trade_date.loc[row_index]['price'] + 0.01 * (i - 5)))

            d['date'] = quot_trade_date.loc[row_index]['trade_date']
            d['time'] = quot_trade_date.loc[row_index]['time']

            self.iter[code][1] = row_index + 1
            self.iter_start_date = d['date']

            quot_dict[code] = d

        return None if len(quot_dict) == 0 else quot_dict


if __name__ == '__main__':
    from barbarian.stock import SourceMongo
    from datetime import datetime

    mongo = SourceMongo()
    mongo.init({'uri': 'mongodb://localhost:37017/', 'pool': 5})
    q = QuotBacktest(mongo)
    q.init(
        js=dict(
            start_date=datetime.strptime('20191225', '%Y%m%d'),
            end_date=datetime.strptime('20200102', '%Y%m%d'),
            quot='kdata'
        ))
    quots = q.get_rt_quot(['000681.SZ'])
    print(quots)
    quots = q.get_rt_quot(['000681.SZ', '000001.SZ'])
    print(quots)
    quots = q.get_rt_quot(['000681.SZ'])
    print(quots)
