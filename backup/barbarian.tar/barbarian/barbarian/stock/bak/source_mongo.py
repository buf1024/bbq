from functools import wraps
from collections import namedtuple
from threading import Lock
import pymongo
from pymongo.errors import ConnectionFailure
import time
import traceback
import pandas as pd
from collections import OrderedDict
from barbarian import log


class SourceMongo:
    _MongoStat = namedtuple('_MongoStat', ['client', 'count', 'last'])

    _common_db = 'common_db'  # 通用数据库
    _code_info_col = 'code_info_col'  # 股票信息
    _index_info_col = 'index_info_col'  # 指数信息
    _trade_cal_col = 'trade_cal_col'  # 交日日历

    _code_kdata_db = 'code_kdata_db'  # 股票日K数据库
    _code_index_db = 'code_index_db'  # 股票日指标数据库
    _code_trans_db = 'code_trans_db'  # 股票日成交数据库

    _index_kdata_db = 'index_kdata_db'  # 指数日K数据库

    def __init__(self, args):
        self.log = log.get_logger(self.__class__.__name__)
        self.lock = Lock()
        self.clients = []
        self.uri, self.pool = args['uri'], args['pool']

    def _best_client(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            stat_client = None
            with self.lock:
                self.clients = sorted(self.clients, key=lambda stat: (stat.count, -stat.last))
                stat_client = self.clients[0]
                self.clients[0] = stat_client._replace(count=stat_client.count + 1, last=time.time())

            kwargs['__client'] = stat_client.client
            return func(self, *args, **kwargs)

        return wrapper

    @property
    def common_db(self):
        return self._common_db

    @property
    def code_kdata_db(self):
        return self._code_kdata_db

    @property
    def code_index_db(self):
        return self._code_index_db

    @property
    def code_trans_db(self):
        return self._code_trans_db

    @property
    def index_kdata_db(self):
        return self._index_kdata_db

    @property
    def code_info_col(self):
        return self._code_info_col

    @property
    def index_info_col(self):
        return self._index_info_col

    @property
    def trade_cal_col(self):
        return self._trade_cal_col

    def get_coll(self, db, col):
        client = self._get_client()
        return client[db][col]

    def init(self):
        self.pool = self.pool if self.pool > 0 else 1
        try:
            for _ in range(self.pool):
                client = pymongo.MongoClient(self.uri, connect=False)
                client.admin.command('ismaster')
                self.clients.append(self._MongoStat(client=client, count=0, last=time.time()))
        except ConnectionFailure as e:
            self.log.error('mongo db 无法连接: uri={}, ex={}'.format(self.uri, e))
            return False

        return True

    def source(self):
        return 'mongo'

    @_best_client
    def _get_client(self, **kwargs):
        return kwargs['__client'] if '__client' in kwargs else None

    def _do_load(self, coll, filter=None, projection=None, skip=0, limit=0, sort=None):
        try:
            cursor = coll.find(filter=filter, projection=projection, skip=skip, limit=limit, sort=sort)
            if cursor is not None:
                df = pd.DataFrame(data=[item for item in cursor], columns=projection)
                cursor.close()
                return None if df.empty else df
            return None
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self._do_load.__name__, traceback.format_exc())

    def _do_batch_load(self, codes, col_func, **kwargs):
        codes = [code.upper() for code in codes]
        d = OrderedDict()
        for code in codes:
            coll = col_func(self._get_client(), code)
            df = self._do_load(coll, **kwargs)
            d[code] = df
        return None if len(d) == 0 else d

    def _do_update(self, coll, filter=None, update=None):
        try:
            if update is None:
                return None
            res = coll.update_one(filter, {'$set': update}, upsert=True)
            return res.upserted_id
        except:
            self.log.error('mongodb 调用 %s 异常:\n%s\n', self._do_update.__name__, traceback.format_exc())

    def _do_batch_update(self, coll_func, data_frames, filter_func=None, index=None, index_uniq=True):
        id_list = []
        for item in data_frames.to_dict('records'):
            coll = coll_func(self._get_client(), item['code'].upper() if 'code' in item else None)
            if index is not None:
                try:
                    coll.create_index(index, unique=index_uniq)
                except Exception as e:
                    self.log.error('创建index异常{}\n item={} call stack: {}'.format(e, item, traceback.format_exc()))

            filter = None if filter_func is None else filter_func(item)
            ids = self._do_update(coll, filter=filter, update=item)
            if ids is None:
                continue
            if isinstance(ids, list):
                id_list = id_list + ids
            else:
                id_list.append(ids)
        return id_list if len(id_list) > 0 else None

    def load_code_list(self, **kwargs):
        """
        :param kwargs: filter=None, projection=None, skip=0, limit=0, sort=None
        :return: DataFrame[_id, code name area industry market exchange]
        """
        self.log.info('加载股票列表, kwargs={}'.format(kwargs))
        client = self._get_client()
        coll = client[self._common_db][self._code_info_col]
        return self._do_load(coll, **kwargs)

    def save_code_list(self, codes):
        """
        :param codes: DataFrame[_id, code name area industry market exchange]
        :return: None/list[_id]
        """
        self.log.info('保存股票列表, count = {}'.format(codes.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._code_info_col],
                                     data_frames=codes, filter_func=lambda item: {'code': item['code']},
                                     index=[('code', 1)])

    def load_trade_cal(self, **kwargs):
        """
        :param kwargs:  filter=None, projection=None, skip=0, limit=0, sort=None
        :return: DataFrame[_id, cal_date,is_open]
        """
        self.log.info('加载交易日历, kwargs={}'.format(kwargs))
        client = self._get_client()
        coll = client[self._common_db][self._trade_cal_col]
        return self._do_load(coll, **kwargs)

    def save_trade_cal(self, cals):
        """
        :param cals: DataFrame[cal_date,is_open]
        :return: None/list[_id]
        """
        self.log.info('保存交易日历, count = {} ...'.format(cals.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._trade_cal_col],
                                     data_frames=cals, filter_func=lambda item: item,
                                     index=[('cal_date', -1)])

    def load_code_adj_k_data(self, codes=None, **kwargs):
        self.log.info('加载复权因子, kwargs={}'.format(kwargs))
        filter = None if 'filter' not in kwargs else kwargs['filter']
        factors = self.load_code_k_data(codes=codes, filter=filter, projection=['adj_factor'],
                                        sort=[('trade_date', -1)])
        if factors is None:
            return None

        data = self.load_code_k_data(codes=codes, **kwargs)
        if data is None:
            return None

        for code, kdata in data.items():
            if kdata is None or factors['code'] is None:
                continue
            factor = factors['code']['adj_factor'][0]

            kdata['open'] = kdata['open'] * kdata['adj_factor'] / factor
            kdata['high'] = kdata['high'] * kdata['adj_factor'] / factor
            kdata['low'] = kdata['low'] * kdata['adj_factor'] / factor
            kdata['close'] = kdata['close'] * kdata['adj_factor'] / factor
            kdata['vol'] = kdata['vol'] * kdata['adj_factor'] / factor

        return data

    def load_code_k_data(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None/DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('加载日K数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])
        return self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._code_kdata_db][code],
                                   **kwargs)

    def save_code_k_data(self, data):
        """

        :param code:
        :param data: DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        :return: None/list[_id]
        """
        self.log.info('保存日K数据, count = {} ...'.format(data.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._code_kdata_db][code],
                                     data_frames=data,
                                     filter_func=lambda item: {'trade_date': item['trade_date']},
                                     index=[('trade_date', -1)])

    def load_code_daily_index(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None,DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （）
            total_amt	float	总市值 （元）
            circ_mv float	流通市值（元）])
        """
        self.log.info('加载股票每日指标, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])
        return self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._code_index_db][code],
                                   **kwargs)

    def save_code_daily_index(self, data):
        """

        :param data:
        :param kdata: DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （）
            total_amt	float	总市值 （元）
            circ_mv float	流通市值（元）])
        :return:
        """
        self.log.info('保存股票每日指标, count={}...'.format(data.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._code_index_db][code],
                                     data_frames=data,
                                     filter_func=lambda item: {'trade_date': item['trade_date']},
                                     index=[('trade_date', -1)])

    def load_code_adj_trans(self, codes=None, **kwargs):

        filter = None if 'filter' not in kwargs else kwargs['filter']
        factors = self.load_code_k_data(codes=codes, filter=filter, projection=['trade_date', 'adj_factor'],
                                        sort=[('trade_date', -1)])
        if factors is None:
            return None

        data = self.load_code_trans(codes=codes, **kwargs)
        if data is None:
            return None

        for code, trans in data.items():
            if trans is None or factors['code'] is None:
                continue
            trade_dates = trans['trade'].drop_duplicates().tolist()
            factor = factors['code']['adj_factor'][0]
            for trade_date in trade_dates:
                factor_df = factors['code']
                filter_factors = factor_df[factor_df['trade_date'] == trade_date]
                trans[trans['trade_date'] == trade_date]['adj_factor'] = filter_factors['adj_factor'][0]

                trans['price'] = trans['price'] * trans['adj_factor'] / factor
                trans['vol'] = trans['vol'] * trans['adj_factor'] / factor

        return data

    def load_code_trans(self, codes=None, **kwargs):
        """


        :return [{code: DataFrame}] / None

        DataFrame, DataFrame字段：
            code 股票代码
            trade_date 交易日
            time 成交时间
            price 成交价格
            vol	成交量(手)
            amount 成交额(元)
            type 性质(-1 卖盘 0 中性盘 1 买盘)
        """
        self.log.info('加载股票成交数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])
            if codes is None:
                self.log.error('codes is None')
                return None
            codes = codes['code'].tolist()

        cal_filter = None
        start_date = None if 'start_date' not in kwargs else kwargs['start_date']
        end_date = None if 'end_date' not in kwargs else kwargs['end_date']
        trade_dates = None if 'trade_dates' not in kwargs else kwargs['trade_dates']
        if start_date is not None:
            del kwargs['start_date']
        if end_date is not None:
            del kwargs['end_date']
        if trade_dates is not None:
            del kwargs['trade_dates']

        if start_date is None or end_date is None:
            if trade_dates is None:
                self.log.error('请求参数没指定日期')
                return None
            cal_filter = {'is_open': 1, 'cal_date': {'$in': trade_dates}}
        else:
            cal_filter = {'is_open': 1, 'cal_date': {'$gte': start_date, '$lte': end_date}}

        trade_dates = self.load_trade_cal(filter=cal_filter, projection=['cal_date'], sort=[('cal_date', -1)])
        if trade_dates is None:
            self.log.error('trade_dates is {} 无开市日期数据'.format(cal_filter))
            return None
        trade_dates = trade_dates['cal_date'].tolist()
        ret_dict = None
        for trade_date in trade_dates:
            ret = self._do_batch_load(codes=codes,
                                      col_func=lambda client, code: client[self._code_trans_db][
                                          code + trade_date.strftime('%Y%m%d')],
                                      **kwargs)
            if ret_dict is None:
                ret_dict = ret
                continue
            for code in codes:
                if ret_dict[code] is None:
                    ret_dict[code] = ret[code]
                    continue
                if ret[code] is None:
                    continue

                ret_dict[code] = pd.concat([ret_dict[code], ret[code]])
                ret_dict[code] = ret_dict[code].reset_index(drop=True)

        return ret_dict

    def save_code_trans(self, data):
        """

        :param data: DataFrame, DataFrame字段：
            code 股票代码
            trade_date 交易日
            time 成交时间
            price 成交价格
            volume	成交量(手)
            amount 成交额(元)
            type 性质(-1 卖盘 0 中性盘 1 买盘)
        """
        self.log.info('保存股票成交数据, count = {} ...'.format(data.shape[0]))
        trade_dates = data['trade_date'].drop_duplicates().tolist()
        ids = None
        for trade_date in trade_dates:
            new_ids = self._do_batch_update(
                coll_func=lambda client, code: client[self._code_trans_db][code + trade_date.strftime('%Y%m%d')],
                data_frames=data,
                filter_func=lambda item: {'time': item['time'], 'trade_date': item['trade_date']},
                index=[('time', -1), ('trade_date', -1)], index_uniq=False)
            if new_ids is not None:
                if ids is None:
                    ids = new_ids
                else:
                    ids = ids + new_ids
        return ids

    def load_index_list(self, **kwargs):
        """
        指数基本信息
        :return: None/DataFrame([code,name,market,category,index_type,exp_date])
        """
        self.log.info('加载大盘指数列表, kwargs={}'.format(kwargs))
        client = self._get_client()
        coll = client[self._common_db][self._index_info_col]
        return self._do_load(coll, **kwargs)

    def save_index_list(self, indexes):
        """
        :param indexes: DataFrame([code,name,market,category,index_type,exp_date])
        :return: None/list[_id]
        """
        self.log.info('保存大盘指数列表, count = {}...'.format(indexes.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._common_db][self._index_info_col],
                                     data_frames=indexes, filter_func=lambda item: {'code': item['code']},
                                     index=[('code', -1)])

    def load_index_k_data(self, codes=None, **kwargs):
        """

        :param codes:
        :param kwargs:
        :return: None/DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('加载大盘日k数据, kwargs={}'.format(kwargs))
        if codes is None:
            codes = self.load_code_list(projection=['code'])
        return self._do_batch_load(codes=codes, col_func=lambda client, code: client[self._index_kdata_db][code],
                                   **kwargs)

    def save_index_k_data(self, data):
        """

        :param data:
        :param index:  DataFrame([code,trade_date,open,high,low,close,vol,amt])
        :return:
        """
        self.log.info('保存大盘日K线数据, count = {} ...'.format(data.shape[0]))
        return self._do_batch_update(coll_func=lambda client, code: client[self._index_kdata_db][code],
                                     data_frames=data,
                                     filter_func=lambda item: {'trade_date': item['trade_date']},
                                     index=[('trade_date', -1)])


if __name__ == '__main__':
    from barbarian.stock import QuotTushare
    from barbarian.stock import QuotTencent
    import datetime

    tu = QuotTushare('408481e156da6a5facd695e58add4d0bf705649fe0f460d03d4d6908')
    ten = QuotTencent(None)
    mongo = SourceMongo({'uri': 'mongodb://localhost:37017/', 'pool': 5})
    mongo.init()

    # cals = tu.get_trade_cal()
    # print('tu cal:\n')
    # print(cals.head())
    # mongo.save_trade_cal(cals=cals)
    # cals = mongo.load_trade_cal(sort=[('cal_date', -1)])
    # print('mongo cal:\n')
    # print(cals.head())

    # codes = tu.get_code_list()
    # print('tu codes:\n')
    # print(codes.head())
    # mongo.save_code_list(codes=codes)
    # codes = mongo.load_code_list()
    # print('codes:\n')
    # print(codes.head())

    # kdata = tu.get_code_k_data(trade_date='20191127')
    # print('tu kdata:\n')
    # print(kdata.head())
    # mongo.save_code_k_data(kdata)
    # kdata = mongo.load_code_k_data(codes=['603116.sh'])
    # print('mongo kdata:\n')
    # for k, frame in kdata.items():
    #     print('code:%s\n', k)
    #     print(frame.head())

    # indexes = tu.get_code_daily_index(code='601099.sh', trade_date='20191127')
    # print('tu code_indexes:\n')
    # print(indexes.head())
    # mongo.save_code_daily_index(indexes)
    # indexes = mongo.load_code_daily_index(codes=['601099.sh'])
    # print('mongo index:\n')
    # for k, frame in indexes.items():
    #     print('code:%s\n', k)
    #     print(frame.head())

    trans = ten.get_code_trans(code='601099.SH', trade_date='20191127')
    print('ten trans data:\n')
    print(trans.head())
    mongo.save_code_trans(data=trans)

    trans = ten.get_code_trans(code='601099.SH', trade_date='20191224')
    print('ten trans data:\n')
    print(trans.head())
    mongo.save_code_trans(data=trans)

    trans = mongo.load_code_trans(codes=['601099.SH'],
                                  trade_dates=[datetime.datetime.strptime('20191127', '%Y%m%d'),
                                               datetime.datetime.strptime('20191224', '%Y%m%d')])
    print('mongo trans data:\n')
    for code, frame in trans.items():
        print('code:{}\n'.format(code))
        print(frame.head())

    # indexes = tu.get_index_list()
    # print('tu code_index:\n')
    # print(indexes.head())
    # mongo.save_index_list(indexes=indexes)
    # indexes = mongo.load_index_list()
    # print('indexes:\n')
    # print(indexes.head())

    # kdata = tu.get_index_kdata(code='000001.SH', trade_date='20191127')
    # print('tu index kdata:\n')
    # print(kdata.head())
    # mongo.save_index_k_data(kdata=kdata)
    # kdata = mongo.load_index_k_data(codes=['000001.SH'])
    # print('mongo index kdata:\n')
    # for k, frame in kdata.items():
    #     print('code:\n', k)
    #     print(frame.head())

    # now = datetime.now()
    # trad_date = datetime(year=now.year, month=now.month, day=now.day)
    # df = mongo.load_trade_cal(
    #     filter={
    #         'cal_date': {'$in': [trad_date, trad_date]},
    #         'is_open': 1
    #     },
    #     projection=['cal_date'],
    #     sort=[('cal_date', -1)],
    #     limit=1
    # )
    # print(df)
