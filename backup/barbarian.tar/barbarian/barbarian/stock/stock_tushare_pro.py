from functools import wraps
import pandas as pd
import time
import tushare as ts
import traceback
from barbarian import log
from datetime import datetime


class TusharePro:
    def __init__(self, token=None):
        self.token = token
        self.api = None

        if self.token is not None:
            self.api = ts.pro_api(token)

        self.log = log.get_logger(self.__class__.__name__)

    def _retry_client(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            for i in range(3):
                try:
                    res = func(self, *args, **kwargs)
                    return res
                except Exception as e:
                    msg = traceback.format_exc()
                    self.log.error('请求 %s tushare pro 异常: \n%s', func.__name__, msg)
                    self.log.debug('请求 %s tushare pro 1s后重试.', func.__name__)
                    time.sleep((i + 1) * 5)
            self.api = ts.pro_api(self.token)
            return None

        return wrapper

    def init(self, js):
        self.token = None if 'token' not in js else js['token']
        if self.token is None:
            return False
        self.api = ts.pro_api(self.token)

        return True

    @_retry_client
    def get_trade_cal(self, start_date=None, end_date=None, fields=None):
        """
        交易日历
        :param fields:  cal_date,is_open
        :param end_date: 'yyyymmdd'
        :param start_date: 'yyyymmdd'
        :return: None / DataFrame[cal_date,is_open]
        """
        self.log.info('get_trade_cal交易日历请求, start_date={start_date}, end_date={end_date}, fields={fields}'.
                      format(start_date=start_date, end_date=end_date, fields=fields))

        df = self.api.trade_cal(exchange='', start_date=start_date, end_date=end_date, fields='cal_date,is_open')
        df['cal_date'] = pd.to_datetime(df['cal_date'], format='%Y%m%d')
        self.log.info('get_trade_cal交易日历应答 size={}'.format(df.shape[0]))

        if df is not None and not df.emptyand and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_code_list(self, fields=None):
        """
        股票列表
        :type fields: code,name,area,industry,market
        :return: None / DataFrame[code,name,area,industry,market,list_date] market->市场类型 （主板/中小板/创业板/科创板）
        """
        self.log.info('get_code_list股票列表请求')
        df = self.api.stock_basic(list_status='L', exchange='', fields='ts_code,name,area,industry,market,list_date')
        if df is not None:
            df['list_date'] = pd.to_datetime(df['list_date'], format='%Y%m%d')
            df.rename(columns={'ts_code': 'code'}, inplace=True)
        self.log.info('get_code_list股票列表应答 size={}'.format(df.shape[0] if df is not None else 0))
        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_code_kdata(self, code=None, trade_date=None, fields=None):
        """
        日K线行情
        :param fields: code,trade_date,open,high,low,close,vol,amt,adj_factor
        :param trade_date: yyyymmdd
        :param code: code=xxx.sh/sz
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('get_code_kdata日K线行情请求, code={code}, trade_date={trade_date}, fields={fields}'.
                      format(code=code, trade_date=trade_date, fields=fields))

        if code is None and trade_date is None:
            return None

        df = self.api.daily(ts_code=code, trade_date=trade_date, fields='ts_code,trade_date,open,high,low,close,vol,amount')
        if df is not None:
            self.log.info('gget_code_kdata复权因子请求, code={}, trade_date={}'.format(code, trade_date))
            adjdf = self.get_code_adj_factor(code=code, trade_date=trade_date)
            if adjdf is None:
                return None
            self.log.info('get_code_kdata复权因子应答 size={}'.format(adjdf.shape[0] if adjdf is not None else 0))

            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            df.rename(columns={'ts_code': 'code', 'amount': 'amt'}, inplace=True)
            df = df.merge(adjdf, left_on=['code', 'trade_date'], right_on=['code', 'trade_date'])

        self.log.info('get_code_kdata日K线行情应答 size={}'.format(df.shape[0] if df is not None else 0))

        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_code_adj_factor(self, code=None, trade_date=None, fields=None):
        """
        复权因子
        :param fields: code, trade_date, adj_factor
        :param trade_date: yyyymmdd
        :param code: code=xxx.sh/sz
        :return: None / DataFrame([code, trade_date, adj_factor])
        """
        self.log.info('get_code_adj_factor复权因子请求, code={code}, trade_date={trade_date}, fields={fields}'.
                      format(code=code, trade_date=trade_date, fields=fields))

        if code is None and trade_date is None:
            return None

        df = self.api.adj_factor(ts_code=code, trade_date=trade_date, fields='ts_code,trade_date,adj_factor')
        if df is not None:
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            df.rename(columns={'ts_code': 'code'}, inplace=True)

        self.log.info('get_code_adj_factor复权因子应答 size={}'.format(df.shape[0] if df is not None else 0))

        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_code_adj_kdata(self, code=None, trade_date=None, adj=None, fields=None):
        """
        复权日K线行情
        :param fields: code,trade_date,open,high,low,close,vol,amt,adj_factor
        :param adj: None /qfq /hfq -> 前复权 后复权
        :param trade_date: yyyymmdd
        :param code: code=xxx.sh/sz
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt,adj_factor])
        """
        self.log.info('get_code_adj_kdata复权日K线行情请求, code={code}, trade_date={trade_date}, adj={adj}, fields={fields}'.
                      format(code=code, trade_date=trade_date, adj={adj}, fields=fields))

        if code is None and trade_date is None:
            return None

        df = ts.pro_bar(ts_code=code, start_date=trade_date, end_date=trade_date,
                              adj=adj, adjfactor=True)

        if df is not None:
            df.rename(columns={'ts_code': 'code', 'amount': 'amt'}, inplace=True)
            df = df['code,trade_date,open,high,low,close,vol,amt,adj_factor'.split(',')]

        self.log.info('get_code_adj_kdata复权日K线行情应答 size={}'.format(df.shape[0] if df is not None else 0))

        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_code_daily_index(self, code=None, trade_date=None, fields=None):
        """
        每日指标
        :param fields:
        :param trade_date: yyyymmdd
        :param code: code=xxx.sh/sz
        :return: None / DataFrame([code, trade_date,
            turnover_rate	float	换手率（%）
            vol_ratio	float	量比
            pe	float	市盈率（总市值/净利润）
            pb	float	市净率（总市值/净资产）
            total_share	float	总股本 （股）
            float_share	float	流通股本 （股）
            free_share	float	自由流通股本 （股）
            total_amt	float	总市值 （万元）
            circ_amt float	流通市值（万元）])
        """
        self.log.info('get_code_daily_index每日指标请求, code={code}, trade_date={trade_date}, fields={fields}'.
                      format(code=code, trade_date=trade_date, fields=fields))

        if code is None and trade_date is None:
            return None

        df = self.api.daily_basic(ts_code=code, trade_date=trade_date,
                                  fields='ts_code,trade_date,turnover_rate,volume_ratio,pe,pb,total_share,'
                                         'float_share,free_share,total_mv,circ_mv')
        if df is not None:
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            # df['total_share'] = df['total_share'] * 10000
            # df['float_share'] = df['float_share'] * 10000
            # df['free_share'] = df['free_share'] * 10000
            # df['total_mv'] = df['total_mv'] * 10000
            # df['circ_mv'] = df['circ_mv'] * 10000
            df.rename(
                columns={'ts_code': 'code', 'volume_ratio': 'vol_ratio', 'total_mv': 'total_amt',
                         'circ_mv': 'circ_amt'},
                inplace=True)

        self.log.info('get_code_daily_index每日指标应答 size={}'.format(df.shape[0] if df is not None else 0))

        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_index_list(self, fields=None):
        """
        指数基本信息
        :type fields:
        :return: None/DataFrame([code,name,market,category,index_type,exp_date])
        """
        self.log.info('get_index_list指数基本信息请求, fields={fields}'.
                      format(fields=fields))

        frames = []
        markets = ['SSE', 'SZSE']
        for market in markets:
            df = self.api.index_basic(market=market, fields='ts_code,name,market,category,index_type,exp_date')
            if df is not None:
                df = df[df['exp_date'].isnull()]
                df['market'] = df['market'].str.replace('SSE', 'SH')
                df['market'] = df['market'].str.replace('SZSE', 'SZ')
                del df['exp_date']
                df.rename(columns={'ts_code': 'code'}, inplace=True)
                frames.append(df)

        df = None if len(frames) == 0 else pd.concat(frames)

        self.log.info('get_code_daily_index指数基本信息应答 size={}'.format(df.shape[0] if df is not None else 0))

        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_index_kdata(self, code=None, start_date=None, end_date=None, fields=None):
        """
        指数日线行情
        :param fields:
        :param start_date: yyyymmdd
        :param end_date: yyyymmdd
        :param code: code=xxx.sh/sz
        :return: None / DataFrame([code,trade_date,open,high,low,close,vol,amt])
        """
        self.log.info(
            'get_index_kdata指数日线行情请求, , code={code}, start_date={start_date}, end_date={end_date}, fields={fields}'.
            format(code=code, start_date=start_date, end_date=end_date, fields=fields))

        if code is None and end_date is None:
            self.log.error('get_index_kdata指数日线行情请求, code or end_date is None')
            return None

        df = self.api.index_daily(ts_code=code, start_date=start_date, end_date=end_date,
                                  fields='ts_code,trade_date,open,high,low,close,vol,amount')
        if df is not None:
            df.dropna(inplace=True)
            df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
            df['amount'] = df['amount']
            df.rename(columns={'ts_code': 'code', 'amount': 'amt'}, inplace=True)

        self.log.info('get_index_kdata指数日线行情应答 size={}'.format(df.shape[0] if df is not None else 0))

        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df

    @_retry_client
    def get_code_suspend(self, code, trade_date, suspend_type='S', fields=None):
        """
        停牌复牌
        :param suspend_type: R复牌，S停牌
        :param start_date: yyyymmdd
        :param code: code=xxx.sh/sz
                :return: None / DataFrame([code,trade_date,ts_code, suspend_timing,suspend_type])
        """
        self.log.info(
            'get_code_suspend停牌信息请求, code={code}, trade_date={trade_date}, suspend_type={suspend_type}, fields={fields}'.
            format(code=code, trade_date=trade_date, suspend_type=suspend_type, fields=fields))
        df = self.api.suspend_d(ts_code=code, trade_date=trade_date, suspend_type=suspend_type)

        self.log.info(
            'get_code_suspend停牌信息应答, size={}'.format(df.shape[0] if df is not None else 0))
        if df is not None and not df.empty:
            df.rename(columns={'ts_code': 'code'}, inplace=True)

        if df is not None and not df.empty and fields is not None:
            df = df[[x.strip() for x in fields.split(',')]]
        return df


if __name__ == '__main__':
    tu = TusharePro()
    tu.init({'token': '408481e156da6a5facd695e58add4d0bf705649fe0f460d03d4d6908'})
    # df = tu.get_trade_cal()
    # print(df)
    # df1 = tu.get_code_kdata(code='=000001.SZ', trade_date='20200211')
    # print(df1.empty)

    # df1 = tu.get_code_suspend(code='=000001.SZ', trade_date='20200211')
    # print(df1)

    # df = tu.get_code_daily_index(code='601099.sh', trade_date='20191126')
    # print(df)
    # df2 = tu.get_code_adj_factor(code='601099.sh', trade_date='20191126')
    # print(df2)
    # df = tu.get_index_list()
    # print(df.tail())
    # df = tu.get_index_k_data(code='000001.sh', trade_date='20191126')
    # print(df)
    # print(df)

    # df3 = tu.get_code_adj_kdata(code='601099.sh', trade_date='20191126', adj='qfq')
    # print(df3)
