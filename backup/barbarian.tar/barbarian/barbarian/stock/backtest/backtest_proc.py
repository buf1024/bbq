# import sys
# import json
# import traceback
# import uuid
# from async_nats import AsyncNats
#
# from data.source_mongo import SourceMongo
#
# from trader.strategy import strategies as trade_strategies
# from trader.broker import brokers
# from trader.account import Account
#
#
# class Backtest(AsyncNats):
#     def __init__(self, topic, options):
#         super().__init__()
#         self.status = 'created'
#         self.topic = topic
#         self.options = json.loads(options)
#         self.db = None
#
#         self.strategy = None
#         self.account = None
#         self.risk = None
#
#         self.handlers = {
#             'status_query': self.on_status_query,
#             'quot': self.on_quot
#         }
#
#     def init_backtest(self):
#         self.db = SourceMongo(self.options['db'])
#         if not self.db.init():
#             return False
#
#         try:
#             broker_js = self.options['broker']
#             broker = brokers[broker_js['name']](self.db)
#             if not broker.from_json(broker_js):
#                 self.log.error('init broker from_json failed')
#                 return False
#
#             self.risk = broker.risk
#             self.strategy = broker.strategy
#             self.account = broker.account
#
#             if self.strategy is None or self.account is None:
#                 self.log.error('init broker strategy or account is null')
#                 return False
#
#             self.status = 'inited'
#         except Exception as e:
#             self.log.error('init_backtest exception: exception={}, call_stack={}'.format(e, traceback.format_exc()))
#             return False
#         return True
#
#     async def do_update_codes(self):
#         payload = {
#             'id': str(uuid.uuid4()),
#             'cmd': 'update_codes',
#             'options': {
#                 'codes': self.strategy.codes,
#                 'quot': self.options['quot']
#             }
#         }
#         payload = json.dumps(payload)
#         self.log.info('publish subject={}, payload={}'.format(self.topic, payload))
#         await self.nc.publish(self.topic, payload.encode())
#         await self.nc.flush()
#
#     async def do_status_report(self):
#         payload = {
#             'id': str(uuid.uuid4()),
#             'cmd': 'status_report',
#             'options': {
#                 'status': self.status
#             }
#         }
#         payload = json.dumps(payload)
#         self.log.info('publish subject={}, payload={}'.format(self.topic, payload))
#         await self.nc.publish(self.topic, payload.encode())
#         await self.nc.flush()
#
#     async def on_nats_connected(self):
#         self.log.info('nats connected, listen subject: {}'.format(self.topic))
#         await self.subscribe(self.topic)
#         await self.do_status_report()
#         if not self.init_backtest():
#             self.status = 'died'
#             await self.do_status_report()
#             self.on_signal()
#             return
#         await self.do_status_report()
#         if self.strategy is not None and len(self.strategy.codes) > 0:
#             await self.do_update_codes()
#
#     async def on_nats_message(self, msg):
#         subject, reply, data = msg.subject, msg.reply, msg.data.decode()
#         self.log.info("Received a message on '{subject} {reply}': {data}".format(
#             subject=subject, reply=reply, data=data))
#
#         if subject == self.topic:
#             await self.on_command(subject=subject, reply=reply, data=data)
#
#     async def on_command(self, subject, reply, data):
#         resp = dict(id='', cmd='', status='ERR', msg='')
#         try:
#             data_dict = json.loads(data)
#             sid, cmd, options = data_dict['id'], data_dict['cmd'], data_dict[
#                 'options'] if 'options' in data_dict else None
#
#             resp['id'] = sid
#             resp['cmd'] = cmd
#             status, msg, options = await self.handlers[cmd](options)
#             resp['status'] = status
#             resp['msg'] = msg
#             if options is not None:
#                 reply['options'] = options
#         except Exception as e:
#             self.log.error('execute command failed: subject={}, data={} call_stack={}'.format(subject, data,
#                                                                                               traceback.format_exc()))
#             resp['msg'] = 'exception: {}'.format(e)
#         finally:
#             if reply != '':
#                 js_resp = json.dumps(resp)
#                 self.log.info("Response a message on '{reply}': '{data}'".format(reply=reply, data=js_resp))
#                 await self.nc.publish(subject=reply, payload=js_resp.encode())
#
#     async def on_status_query(self, options):
#         return 'OK', '', {'status': self.status}
#
#     async def on_quot(self, options):
#         return 'ERR', '', {'status': self.status}
#
#
# if __name__ == '__main__':
#     if len(sys.argv) != 3:
#         print('usage: python backtest_proc.py subject options')
#         sys.exit(-1)
#     subject, options = sys.argv[1], sys.argv[2]
#
#     # subject = 'abc'
#     # options = {
#     #     'db': {
#     #         "uri": "mongodb://localhost:37017/",
#     #         "pool": 5
#     #     },
#     #     'broker': {
#     #         'name': 'BrokerSimulate',
#     #         'account': {
#     #             'cash_init': 50000.00
#     #         },
#     #         'strategy': {
#     #             'name': 'Dummy'
#     #         },
#     #         'risk': {
#     #             'name': 'SimpleStop'
#     #         }
#     #     },
#     #     'quot': {
#     #         'name': 'QuotBacktest',
#     #         'interval': 1
#     #     }
#     # }
#     # options = json.dumps(options)
#     backtest = Backtest(subject, options)
#     backtest.start()
