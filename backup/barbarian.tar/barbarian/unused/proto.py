import uuid


def request(cat, cmd, payload=None):
    js = dict(
        id=str(uuid.uuid4()),
        cat=cat,
        cmd=cmd
    )
    if payload is not None:
        js['options'] = payload

    return js


def response(sid, cat, cmd, status, msg, payload=None):
    js = dict(
        id=sid,
        cat=cat,
        cmd=cmd,
        status=status,
        msg=msg
    )
    if payload is not None:
        js['options'] = payload

    return js
