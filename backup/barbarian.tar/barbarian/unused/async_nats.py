import asyncio
import traceback
from barbarian import log
import signal
from nats.aio.client import Client as NATS


class AsyncNats:
    def __init__(self):
        self.log = log.get_logger(self.__class__.__name__)

        self.nc = NATS()
        self.loop = asyncio.get_event_loop()

        self._subjects = {}

    async def on_nats_error(self, e):
        self.log.error('Nat error: ', e)

    async def on_nats_closed(self):
        self.log.info("Connection to NATS is closed.")
        await asyncio.sleep(0.1, loop=self.loop)
        self.loop.stop()

    async def on_nats_connected(self):
        pass

    async def on_nats_reconnected(self):
        self.log.info("Connected to NATS at {}...".format(self.nc.connected_url.netloc))

    async def on_nats_message(self, msg):
        subject = msg.subject
        reply = msg.reply
        data = msg.data.decode()
        self.log.info("Received a message on '{subject} {reply}': {data}".format(
            subject=subject, reply=reply, data=data))

    def on_signal(self):
        if self.nc.is_closed:
            return
        self.log.info("Disconnecting...")
        self.loop.create_task(self.nc.close())

    async def _task(self, options=None):
        def_options = {
            'io_loop': self.loop,
            'error_cb': self.on_nats_error,
            'closed_cb': self.on_nats_closed,
            'reconnected_cb': self.on_nats_reconnected,
            'servers': ['nats://127.0.0.1:4222'],
            'no_echo': True
        }
        options = def_options if options is None else options.update(def_options)

        try:
            await self.nc.connect(**options)
        except Exception as e:
            self.log.error('connect to error: exception={}, servers={}, callstack={}'.format(e, options['servers'],
                                                                                             traceback.format_exc()))
            return False
        self.log.info('Connected to NATS at {}...'.format(self.nc.connected_url.netloc))

        for sig in ('SIGINT', 'SIGTERM'):
            self.loop.add_signal_handler(getattr(signal, sig), self.on_signal)

        await self.on_nats_connected()

        return True

    def start(self):
        try:
            if self.loop.run_until_complete(self._task()):
                self.loop.run_forever()
        finally:
            self.loop.close()

    async def subscribe(self, subject):
        if not self.nc.is_closed:
            if subject not in self._subjects:
                ssid = await self.nc.subscribe(subject=subject, cb=self.on_nats_message)
                self._subjects[subject] = ssid

    async def unsubscribe(self, subject):
        if not self.nc.is_closed:
            if subject in self._subjects:
                await self.nc.unsubscribe(ssid=self._subjects[subject])
